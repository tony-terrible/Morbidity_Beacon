<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Cache-control" content="no-cache">
<title><?php echo $config['site']['name']; ?></title>

<link rel="stylesheet" type="text/css" href="css/styles.css" />
<link rel="stylesheet" type="text/css" href="css/pagination.css" />
<link rel="stylesheet" type="text/css" href="css/jquery.Jcrop.css" />
<link rel="stylesheet" type="text/css" href="css/colorbox.css" />
<link rel="stylesheet" type="text/css" href="css/cupertino/jquery-ui-1.8.21.custom.css" />

<!--<link rel="stylesheet" type="text/css" href="css/jHtmlArea.css" />
<script type="text/javascript" src="js/jHtmlArea-0.7.0.min.js"></script>//-->

<script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.8.21.custom.min.js"></script>
<script type="text/javascript" src="js/common.js"></script>
<script type="text/javascript" src="js/jquery.Jcrop.min.js"></script>
<script type="text/javascript" src="js/jquery.colorbox-min.js"></script>

<script src="js/tiny_mce/tiny_mce.js" language="javascript" type="text/javascript"></script>
<script type="text/javascript">
<!--
tinyMCE.init({
	mode : "textareas",
	theme : "advanced",
	editor_selector : "mceEditor",
	editor_deselector : "mceNoEditor",
	//content_css : "../css/styles.css",
	//plugins : "style,advimage,table",
	
	//theme_advanced_layout_manager : "SimpleLayout",
	//theme_advanced_buttons1 : "formatselect,|,bold,italic,underline,separator,justifyleft,justifycenter,justifyright,|,link,unlink,|,bullist,numlist,|,outdent,indent,|,removeformat,code,|,insertimage,|,tablecontrols",
	/*
	theme_advanced_buttons2 : "",
	theme_advanced_buttons3 : "",	
	theme_advanced_blockformats : "p,div,h2,h3,blockquote",
	valid_elements : "h2,h3,ul,li,p,br,ol,strong,em,i,blockquote,u,b,a[href|target],table[cellspacing|cellpadding|border|width],tr,th,td[valign|align|width]",
	theme_advanced_toolbar_location : "bottom",
	theme_advanced_toolbar_align : "left",
	cleanup_on_startup : "true"*/
});
//-->
</script>	


<script type="text/javascript">
$.ajaxSetup ({ cache: false });

function del (msg, url) {
	$("#confirm_delete").html ('<p><span class="ui-icon ui-icon-alert" style="float:left; margin:0 7px 20px 0;"></span>'+msg+'</p><p>This action cannot be reversed.</p>');
	$("#confirm_delete").dialog ({
		width: 300,
		height: 150,
		resizable: false,
		modal: true,
		buttons: {
			Delete: function () { window.location = url; },
			Cancel: function () { $(this).dialog("close"); } 
		}
	});	
	
}

</script>

</head>

<body>
<div id="holder">
	<div id="header">
  	<div class="left"><?php echo $config['site']['name']; ?></div>
    <div class="right"><?php echo date("l, F jS, Y"); ?></div>
    <div class="clear"></div>
  </div>
  <noscript>
    <div class="error"><strong>Warning!</strong><br />You do not have javascript enabled, you will not be prompted to confirm deletion of items and other functionality will be lost!</div>
  </noscript>      
  <div id="menu_bar">
  	<table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><?php require ('includes/_menu.php'); ?></td>
        <td align="right" style="padding-right: 10px;">Logged in as <strong><?php echo $_SESSION['login']['user_name']; ?></strong> | <a href="index.php?logout">Logout</a></td>
      </tr>
    </table>
  </div>
  <div id="confirm_delete"></div>
  <div id="content">
		

		
		
		