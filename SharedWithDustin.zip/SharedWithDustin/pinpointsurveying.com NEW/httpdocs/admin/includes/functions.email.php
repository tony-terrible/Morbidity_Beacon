<?php

function add_to_outgoing_email_db ($to_email, $to_name, $from_email, $from_name, $headers, $subject, $body) {

	$db_outgoing = @mysql_connect("localhost","outgoingemail","Yfv7!nBt");
	if (!$db_outgoing) { echo("unable to connect"); exit(); }
	if (!@mysql_select_db ("outgoingemail")) { echo("unable to locate database"); exit(); }

	$sql = "INSERT INTO `outgoingemail` VALUES ('', '$to_email', '$to_name', '$from_email', '$from_name', '$headers', '$subject', '$body')";

	if (mysql_query ($sql)) {
		$return['status'] = 1;
		$return['message'] = '';
	} else {
		$return['status'] = 0;
		$return['message'] = 'An error occurred: ' . mysql_error();
	}
	
	return $return;

}

function format_email ($body) {

	$tags_to_replace = array (
		'<p>' 	=> '<p style="font: 11px Verdana, Arial, Helvetica, sans-serif; color: #333;">',
		'<hr>'	=> '<hr style="border: 0; border-bottom: 1px solid #efefef;">',
		'<td'	=> '<td style="font: 11px Verdana, Arial, Helvetica, sans-serif; color: #333;"',
		'<li'	=> '<li style="font: 11px Verdana, Arial, Helvetica, sans-serif; color: #333;"'
	);	

	foreach ($tags_to_replace as $old => $new) {
		$body = str_replace ($old, $new, $body);
	}
	
	return $body;

}



?>