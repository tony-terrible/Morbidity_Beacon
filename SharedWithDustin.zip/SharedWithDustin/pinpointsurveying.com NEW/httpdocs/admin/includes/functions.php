<?php

################################################################################################################################################
### echo_error ()
################################################################################################################################################
function echo_error ($field) {
	global $errors;
	
	if (isset ($errors[$field])) {
		echo '<tr>' . "\n";
		echo '	<td>&nbsp;</td>' . "\n";
		echo '	<td><div class="form_error">' . $errors[$field] . '</div></td>' . "\n";
		echo '</tr>' . "\n";
	}
}

################################################################################################################################################
### echo_value ()
################################################################################################################################################
function echo_value ($field) {
	global $row;
	
	if (isset ($_POST[$field])) {
		echo $_POST[$field];
	} else if (isset ($row[$field])) {
		echo stripslashes ($row[$field]);
	}
}


################################################################################################################################################
### login ()
################################################################################################################################################
function login ($email_address, $password) {
	global $dbh;
	
	$ip_address = $_SERVER['REMOTE_ADDR'];
	
	if (!isset ($email_address) || empty ($email_address)) {
		user_log ('', '', 'Login', 'Failed', 'Email address not supplied');
		return 'You must supply an email address';
	}
	
	if (!filter_var ($email_address, FILTER_VALIDATE_EMAIL)) {
		user_log ('', $email_address, 'Login', 'Failed', 'Invalid email address supplied');
		return 'The email address you supplied is invalid';
	}
	
	if (!isset ($password) || empty ($password)) {
		user_log ('', $email_address, 'Login', 'Failed', 'Password not supplied');
		return 'You must supply a password';
	}

	// check to see if email_address or ip is banned
	if (is_banned ($email_address, $ip_address)) {
		user_log ('', $email_address, 'Login', 'Failed', 'Email address and/or IP address banned');
		return 'Sorry, your email address and/or IP address is banned.';
	}

	try {
		$sth = $dbh->prepare ('SELECT * FROM users WHERE email_address = :email_address');
		$sth->bindParam (':email_address', $email_address);
		$sth->execute();
	
		if ($sth->rowCount()) {
			
			$row = $sth->fetch (PDO::FETCH_ASSOC);
			$user_id = $row['user_id'];
			$user_name = $row['first_name'] . ' ' . $row['last_name'];
			$current_password = $row['password'];
			$userlevel = $row['userlevel'];
			
		} else {
			user_log ('', $email_address, 'Login', 'Failed', 'Email address not found');
			return 'Email address and/or password error';
		}
		
	} catch (PDOException $e) {
		user_log ('', $email_address, 'Login', 'Failed', 'Error getting current user information');
		return 'An error has occurred (' . $e->getMessage() . ')';
	}

	// have user_id and current_password, now compare.
	$valid_password = false;
	$t_hasher = new PasswordHash(8, FALSE);
	$valid_password = $t_hasher->CheckPassword($_POST['password'], $current_password);
	unset ($t_hasher);

	if ($valid_password) {
		
		### Login Successful - Start Session
		$db = array();
		$db['user_id'] = $user_id;
		$db['php_session_id'] = session_id ();
		$db['login_dt'] = 'NOW()';
		$db['last_activity_dt'] = 'NOW()';
		$db['ip_address'] = $ip_address;
		
		if (db ('insert', 'user_sessions', $db)) {
			
			// session info in database.
			$_SESSION['login'] = array();
			$_SESSION['login']['user_id'] = $user_id;
			$_SESSION['login']['user_name'] = $user_name;
			$_SESSION['login']['userlevel'] = 0;
			$_SESSION['login']['email_address'] = $email_address;
			$_SESSION['login']['php_session_id'] = session_id ();
			$_SESSION['login']['ip_address'] = $_SERVER['REMOTE_ADDR'];
			

		}
		
		
		### Password is correct - go ahead and login user.
		user_log ($user_id, $email_address, 'Login', 'Success', '');
		
	} else {
		user_log ($user_id, $email_address, 'Login', 'Failed', 'Invalid password entered');
		return 'Email address and/or password error';
	}
	
	
}

################################################################################################################################################
### is_banned ()
################################################################################################################################################
function is_banned ($email_address, $ip_address) {
	global $dbh;
	
	try {
		
		if (empty ($email_address) && !empty ($ip_address)) {
			$sth = $dbh->prepare ('SELECT ub_id FROM user_bans WHERE ip_address = :ip_address');
			$sth->bindParam (':ip_address', $ip_address);						
		} else if (!empty ($email_address) && empty ($ip_address)) {
			$sth = $dbh->prepare ('SELECT ub_id FROM user_bans WHERE email_address = :email_address');
			$sth->bindParam (':email_address', $email_address);
		} else {
			$sth = $dbh->prepare ('SELECT ub_id FROM user_bans WHERE email_address = :email_address OR ip_address = :ip_address');
			$sth->bindParam (':email_address', $email_address);
			$sth->bindParam (':ip_address', $ip_address);			
		}

		$sth->execute();
	
		if ($sth->rowCount()) {
			return true;
		} else {
			return false;
		}
		
	} catch (PDOException $e) {
		echo $e->getMessage();
		return true; // return true.  if this is coming up with an error then don't allow anyone in.
	}
	
}

################################################################################################################################################
### logout ()
################################################################################################################################################
function logout () {
	global $dbh;
	$user_id = $_SESSION['login']['user_id'];
	$email_address = $_SESSION['login']['email_address'];
	$php_session_id = session_id ();

	### Remove user_session entries
	try {
		$sth = $dbh->prepare ("DELETE FROM user_sessions WHERE user_id = :user_id && php_session_id = :php_session_id");
		$sth->bindParam (':user_id', $user_id);
		$sth->bindParam (':php_session_id', $php_session_id);
		$sth->execute();
	} catch (PDOException $e) {
		echo '<div class="error">' . $e->getMessage() . ' (' . __LINE__ . ')</div>';
	}
	
	if ($_SESSION = '' && session_destroy ()) {
		user_log ($user_id, $email_address, 'Logout', 'Success', '');
		return true;
	} else {
		user_log ($user_id, $email_address, 'Logout', 'Failed', '');
		return false;
	}
}

################################################################################################################################################
### reset_password ()
################################################################################################################################################
function reset_password ($email_address) {
	global $dbh;
	global $config;
	
	if (!isset ($email_address) || empty ($email_address)) {
		user_log ('', '', 'Password Reset', 'Failed', 'Email address not supplied');
		return ('You must supply an email address');
	}
		
	if (!filter_var ($email_address, FILTER_VALIDATE_EMAIL)) {
		user_log ('', $email_address, 'Password Reset', 'Failed', 'Invalid email address supplied');
		return 'The email address you supplied is invalid';
	}
	
	try {
		$sth = $dbh->prepare ('SELECT user_id, first_name, last_name FROM users WHERE email_address = :email_address');
		$sth->bindParam (':email_address', $email_address);
		$sth->execute();
	
		if ($sth->rowCount()) {
			if ($row = $sth->fetch (PDO::FETCH_ASSOC)) {

				$new_password_plain = generate_password ();
				$t_hasher = new PasswordHash (8, FALSE);
				$new_password_hash = $t_hasher->HashPassword ($new_password_plain);
				unset ($t_hasher);

				// update db with new password.
				$db = array();
				$db['password'] = $new_password_hash;

				if (db ('update', 'users', $db, 'user_id', $row['user_id'])) {

					$user_name = $row['first_name'] . ' ' . $row['last_name'];
					
					$subject = 'Your new password';
					$body  = '<p>Dear ' . $user_name . ',</p>' . "\n";
					$body .= '<p>We have received a request to generate you a new password.  If you did not make this request please notify an administrator.</p>' . "\n";
					$body .= '<p>Your new password: <srong>' . $new_password_plain . '</strong></p>' . "\n";
					$body .= '<p>Thank You,<br>' . $config['site']['name'] . '</p>' . "\n";
					
					if (send_email ($user_name, $email_address, $subject, $body)) {
						user_log ($row['user_id'], $email_address, 'Password Reset', 'Success', '');
						return true;
					} else {
						user_log ($row['user_id'], $email_address, 'Password Reset', 'Success', 'But error sending email');
						return 'A new password was generated, but an error occurred sending the email.';
					}
				} else {
					user_log ($row['user_id'], $email_address, 'Password Reset', 'Failed', 'Error updating database');
					return 'An error occurred updating the database with the new password.';
				}
			}			
		} else {
			user_log ('', $email_address, 'Password Reset', 'Failed', 'Email address not found');
			return 'Email address not found';
		}
		
	} catch (PDOException $e) {
		user_log ('', $email_address, 'Password Reset', 'Failed', 'Error getting current user information');
		return 'An error has occurred (' . $e->getMessage() . ')';
	}
	
}

################################################################################################################################################
### email ()
################################################################################################################################################
function send_email ($to_name, $to_email, $subject, $body) {
	
	global $dbh;
	global $config;

	$htmlbody = '<html>' . "\n";
	$htmlbody.= '<body style="background-color: #fff; font-family: Verdana; font-size: 11px;">' . "\n";
	$htmlbody.= '<img src="' . $config['email']['logo_url'] . '" style="padding: 10px;">' . "\n";
	$htmlbody.= '<div style="border-top: 1px solid #ccc; border-bottom: 1px solid #ccc; padding: 10px;">' . "\n";
	$htmlbody.= $body;
	$htmlbody.= '</div>' . "\n";
	$htmlbody.= '<div style="padding: 5px; font-size: 10px; color: #666;">Copyright &copy ' . $config['email']['from_name'] . '';

	if (isset ($config['email']['unsubscribe_url']) && !empty ($config['email']['unsubscribe_url'])) {
		$htmlbody.= '| <a href="' . $config['email']['unsubscribe_url'] . '">Unsubscribe</a>';
	}

	$htmlbody.= '| Powered by <a href="http://www.catch22media.com">Catch 22 Media</a></div>' . "\n";
	$htmlbody.= '</body>' . "\n";
	$htmlbody.= '</html>' . "\n";

	$mail = new PHPMailer\PHPMailer\PHPMailer;
	$mail->isSendmail		();
	$mail->setFrom			($config['email']['from_email'], $config['email']['from_name']);
	$mail->addAddress		($to_email, $to_name);
	$mail->Subject 			= $subject;
	$mail->msgHTML 			($htmlbody);

	if ($mail->send()) {
		return true;

	} else {
		echo "Mailer Error: " . $mail->ErrorInfo;
		return false;
	}	
}


################################################################################################################################################
### user_log ()
################################################################################################################################################
function user_log ($user_id, $email_address, $action, $result, $reason) {
	global $dbh;
	
	$ip_address = $_SERVER['REMOTE_ADDR'];
	
	$db = array();
	$db['user_id'] = $user_id;
	$db['email_address'] = $email_address;
	$db['log_dt'] = 'NOW()';
	$db['action'] = $action;
	$db['result'] = $result;
	$db['reason'] = $reason;
	$db['ip_address'] = $ip_address;
	
	if (!db ('insert', 'user_log', $db, '', '')) {
		echo '<div class="error">Error inserting user log information.</div>';
	}
	
	$ban = false;
	### Check to see if we need to ban this user
	try {
		
		$sql = "SELECT result FROM user_log WHERE (action = 'Login') && (log_dt > DATE_SUB(NOW(), INTERVAL 24 HOUR)) && (email_address = :email_address OR ip_address = :ip_address) ORDER BY `ul_id` DESC";
		
		$sth = $dbh->prepare ($sql);
		$sth->bindParam (':email_address', $email_address);
		$sth->bindParam (':ip_address', $ip_address);
		$sth->execute();
	
		$failed_in_row_count = 0;	
		$last_result = '';

		if ($sth->rowCount() > 0) {
			while ($row = $sth->fetch (PDO::FETCH_ASSOC)) {

				if ($row['result'] == 'Failed') { 
					$failed_in_row_count++;
				} else {
					break;
				}
				
				if ($failed_in_row_count == 10) {
					$ban = true;
					break;
				}
				
			}
		}
	} catch (PDOException $e) {
		echo '<div class="error">' . $e->getMessage() . '</div>';
	}
	
	if ($ban) {
		$db = array();
		$db['email_address'] = $email_address;
		$db['ip_address'] = $ip_address;
		$db['datetime'] = 'NOW()';
		$db['reason'] = 'More than 10 failed attempts in 24 hours';
		
		if (!db ('insert', 'user_bans', $db)) {
			echo '<div class="error">Error banning user</div>';
		}
	}
	
}


################################################################################################################################################
### is_logged_in ()
################################################################################################################################################
function is_logged_in () {
	global $dbh;

	$required_session_fields = array ('user_id', 'user_name', 'email_address', 'php_session_id', 'ip_address');
	
	// check to make sure all required $_SESSION fields are set
	foreach ($required_session_fields as $x => $field) {
		if (!isset ($_SESSION['login'][$field])) {
			return false;
		}
	}
	
	// check to make sure login IP matches current IP
	if ($_SESSION['login']['ip_address'] != $_SERVER['REMOTE_ADDR']) {
		return false;
	}
	
	// gather session information from database, make sure it all matches
	try {
		$sth = $dbh->prepare ("SELECT us_id FROM user_sessions WHERE user_id = :user_id && php_session_id = :php_session_id && ip_address = :ip_address");
		$sth->bindParam (':user_id', $_SESSION['login']['user_id']);
		$sth->bindParam (':php_session_id', $_SESSION['login']['php_session_id']);
		$sth->bindParam (':ip_address', $_SESSION['login']['ip_address']);
		$sth->execute();
	
		if ($sth->rowCount()) {
			// exists - update last_activity_dt & last_activity_url
			try {
				$sth = $dbh->prepare ("UPDATE user_sessions SET last_activity_dt = NOW(), last_activity_url = :last_activity_url WHERE user_id = :user_id && php_session_id = :php_session_id");
				$sth->bindParam (':last_activity_url', $_SERVER['REQUEST_URI']);
				$sth->bindParam (':user_id', $_SESSION['login']['user_id']);
				$sth->bindParam (':php_session_id', $_SESSION['login']['php_session_id']);
				$sth->execute();
			} catch (PDOException $e) {
				echo '<div class="error">' . $e->getMessage() . ' (' . __LINE__ . ')</div>';
			}
			
		} else {
			// does not exist, not logged in.
			return false;
		}
	} catch (PDOException $e) {
		echo '<div class="error">' . $e->getMessage() . '</div>';
		return false;
	}
	
	return true;
	
}



################################################################################################################################################
### db()
################################################################################################################################################
function db ($action, $table, $array, $id_column = NULL, $id_value = NULL, $echo_sql = NULL) {
	
	global $dbh;
	
	if (!is_array ($array)) {
		echo 'An array must be passed!';
		return FALSE;
	}
	
	//$count = count ($array);
	
	####################################################################################### Format SQL Statement
	reset ($array);
	$sql = '';
	
	if ($action == "insert") {					### INSERT
	
		$sql .= "INSERT INTO `$table` (";
		foreach ($array as $key => $value) { $sql .= "`$key`,"; }
		$sql = substr ($sql, 0, -1);
		$sql .= ") VALUES (";
		reset ($array);	
		foreach ($array as $key => $value) {
			if ($value === 'NOW()') {
				$sql .= "NOW(),";
			} else {
				$sql .= ":$key,";
			}
		}
		$sql = substr ($sql, 0, -1);
		$sql .= ")";	
				
	} else if ($action == "update") {			### UPDATE
	
		$sql .= "UPDATE `$table` SET ";
		foreach ($array as $key => $value) {
			if ($value === 'NOW()') {
				$sql .= "`$key` = NOW(),";
			} else {
				$sql .= "`$key` = :$key,";
			}
		}
		$sql = substr ($sql, 0, -1);
		$sql .= " WHERE `$id_column` = :id_value";
		
	} else if ($action == "delete") {			### DELETE
	
		$sql = "DELETE FROM `$table` WHERE `$id_column` = :id_value";
		
	}
	
	if ($echo_sql == true) {
		echo '<div style="border: 1px solid #ccc; padding: 4px; margin: 4px;">' . $sql . '</div>';
	}

	####################################################################################### Execute Query
	try {
		
		// prepare sql query for bind and exececution
		$sth = $dbh->prepare ($sql);
		
		// bind parameters
		if ($action == 'insert' || $action == 'update') {
			reset ($array);
			foreach ($array as $key => &$value) {
				if ($value !== 'NOW()') {
					$sth->bindParam (':' . $key, $value);
				}
			}
		}
		
		if ($action == 'update' || $action == 'delete') {
			$sth->bindParam (":id_value", $id_value);
		}
		
		// execute query
		$sth->execute();

		return true;
		
	} catch (PDOException $e) {
		echo '<div class="error">' . $e->getMessage() . '</div>';
		return false;
	}
	
}

################################################################################################################################################
### getFileSize
################################################################################################################################################
function getFileSize ($file) {

	$filesize = filesize($file);

	if ($filesize >= 1073741824) {
		$size = number_format(($filesize / 1073741824),2) . " GB";
	} elseif ($filesize >= 1048576) {
		$size = number_format(($filesize / 1048576),2) . " MB";
	} elseif ($filesize >= 1024) {
		$size = number_format(($filesize / 1024),2) . " KB";
	} elseif ($filesize >= 0) {
		$size = $filesize . " bytes";
	} else {
		$size = "0 bytes";
	}

return $size;
}

################################################################################################################################################
### generate_password
################################################################################################################################################
function generate_password ($length = NULL) {
	
	if (!isset ($length) || !is_numeric ($length)) {
		$length = 10;																					// set the random id length
	}
	
	$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*';
	$charactersLength = strlen($characters);
	$randomString = '';
	for ($i = 0; $i < $length; $i++) {
			$randomString .= $characters[rand(0, $charactersLength - 1)];
	}
	
	return $randomString;
	
}
?>