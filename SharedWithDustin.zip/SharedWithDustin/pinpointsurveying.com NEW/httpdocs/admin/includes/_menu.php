<?php
if (isset ($_menu) && is_array ($_menu) && !empty ($_menu)) {
  
  echo '<ul id="menu">' . "\n";
  
  foreach ($_menu as $x => $i) {
    
    if ($_SESSION['login']['userlevel'] <= $i['userlevel']) {
    
      if (isset ($i['submenu']) && is_array ($i['submenu']) && !empty ($i['submenu'])) {

        echo '<li><a href="' . $i['url'] . '" class="drop">' . $i['name'] . '<!--[if gte IE 7]><!--></a><!--<![endif]-->' . "\n";
        echo '  <!--[if lte IE 6]><table><tr><td><![endif]-->' . "\n";
        echo '  <ul>' . "\n";

        foreach ($i['submenu'] as $y => $ii) {
          
          if ($_SESSION['login']['userlevel'] <= $ii['userlevel']) {
            echo '<li><a href="' . $ii['url'] . '">' . $ii['name'] . '</a></li>' . "\n";
          }

        }

        echo '  </ul>' . "\n";
        echo '  <!--[if lte IE 6]></td></tr></table></a><![endif]-->' . "\n";
        echo '</li>' . "\n";

      } else {

        echo '<li><a href="' . $i['url'] . '">' . $i['name'] . '</a></li>' . "\n";

      }
    
    }
  }
  
  echo '</ul>' . "\n";

} else {

  echo '<div class="error"><strong>Error:</strong> No Menu Defined!</div>' . "\n";
  
}
?>