<?php
if (isset	($_SESSION["$site_session_prefix"]['user_email']) && isset ($_SESSION["$site_session_prefix"]['user_name'])) {

	//$session_user_email = $_SESSION["$site_session_prefix"]['user_email'];
	//$session_user_password = $_SESSION["$site_session_prefix"]['user_password'];

	//$result = mysql_query ("SELECT * FROM `users` WHERE `user_email_address` = '$session_user_email' && `user_password` = '$session_user_password'");
	//if (!$result) {	echo("error performing query: " . mysql_error() . ""); exit(); }
	
	//if (mysql_num_rows ($result)) {
		
		$is_logged_in = true;
		$is_logged_in_admin = true;
		
	//}
}
?>