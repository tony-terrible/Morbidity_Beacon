<?php
$config['site']['name'] = 'PinPoint Surveying';
$config['site']['logo'] = "images/logo.gif";
$config['site']['logowidth'] = "150";
$config['site']['logoheight'] = "72";

$config['email']['logo_url'] = 'http://www.pinpointsurveying.com/admin/images/logo.gif';
$config['email']['from_name'] = $config['site']['name'];
$config['email']['from_email'] = 'donotreply@pinpointsurveying.com';
//$config['email']['unsubscribe_url'] = 'http://www.domain.com/unsubscribe.php';

$_menu = array();
$_menu[0] = array ('name' => 'Clients', 'url' => 'index.php?m=clients', 'userlevel' => '0', 'submenu' => array());
//$_menu[0]['submenu'][] = array ('name' => 'Articles', 'url' => 'index.php?m=home_articles', 'userlevel' => '0');

$_menu[1] = array ('name' => 'Jobs', 'url' => 'index.php?m=jobs', 'userlevel' => '0', 'submenu' => array());

$_menu[2] = array ('name' => 'Timesheets', 'url' => 'index.php?m=timesheets', 'userlevel' => '0', 'submenu' => array());
$_menu[2]['submenu'][] = array ('name' => 'Time Record Search', 'url' => 'index.php?m=timeRecordSearch', 'userlevel' => '0');

$_menu[3] = array ('name' => 'Invoices', 'url' => 'index.php?m=invoices', 'userlevel' => '0', 'submenu' => array());



$_menu[5] = array ('name' => 'Users', 'url' => 'index.php?m=users', 'userlevel' => '0', 'submenu' => array());
$_menu[5]['submenu'][] = array ('name' => 'User Reports', 'url' => 'index.php?m=userReports', 'userlevel' => '0');
$_menu[5]['submenu'][] = array ('name' => 'Email/IP Bans', 'url' => 'index.php?m=user_bans', 'userlevel' => '0');
$_menu[5]['submenu'][] = array ('name' => 'User Login History', 'url' => 'index.php?m=user_login_history', 'userlevel' => '0');

$_menu[8] = array ('name' => 'Other', 'url' => '#', 'userlevel' => '0', 'submenu' => array());
$_menu[8]['submenu'][] = array ('name' => 'Settings', 'url' => 'index.php?m=settings', 'userlevel' => '0');
$_menu[8]['submenu'][] = array ('name' => 'Site Images', 'url' => 'index.php?m=siteImages', 'userlevel' => '0');
?>