<?php
/*
function cleanmysql($arr,$arr2) {
	foreach ($arr as $gt1=>$gt2) {
		if (is_array($arr[$gt1])) {
			list($arr[$gt1],$arr2[$gt1]) = cleanmysql($arr[$gt1],$arr2[$gt1]);
		} else {
			$gt2 = htmlentities($gt2);
			$arr[$gt1]=$arr2[$gt1]=$gt2;
		}
	}
	
	return array($arr,$arr2);
}

list($_GET,$GLOBALS) = cleanmysql($_GET,$GLOBALS);
list($_POST,$GLOBALS) = cleanmysql($_POST,$GLOBALS);
list($_COOKIE,$GLOBALS) = cleanmysql($_COOKIE,$GLOBALS);
*/
?>