<?php
$config['db']['host'] 		= 'localhost';
$config['db']['username'] = 'pinpoint';
$config['db']['password'] = 'dpam3pdAsd943na';
$config['db']['database'] = 'pinpoint';	


if ($_SERVER['HTTP_HOST'] == 'localhost') {

	$config['db']['host'] 		= 'localhost';
	$config['db']['username'] = 'root';
	$config['db']['password'] = '';
	$config['db']['database'] = 'pinpoint';	

}

$_root = '/var/www/vhosts/pinpointsurveying.com/';

### Connect to Database
try {
	$dbh = new PDO('mysql:host=' . $config['db']['host'] . ';dbname=' . $config['db']['database'], $config['db']['username'], $config['db']['password']);
	$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
	echo $e->getMessage();
	exit();
}
?>