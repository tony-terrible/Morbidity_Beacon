	</div>
  <div id="footer">
	<?php 
	$page_end_time = microtime_float();
	$page_load_time = $page_end_time - $page_start_time;
	echo 'Page Generated in ' . number_format ($page_load_time, 5) . ' Seconds';
	?> | Powered by Catch 22 Media</div>



<?php
echo '<pre>'; print_r ($_SESSION); echo '</pre>';
?>





</div>
</body>
</html>