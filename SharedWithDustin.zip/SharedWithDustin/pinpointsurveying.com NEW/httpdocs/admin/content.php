<?php
// $m = module - managed in this file
// $p = page - generally home or form
// $a = action - generally "add", "edit" or "del"
// $id = generic ID we are working with (user_id, account_id, book_id, etc...)

if (isset ($_REQUEST['m'])) 	{	$m = $_REQUEST['m'];		} else { $m = ''; }
if (isset ($_REQUEST['p'])) 	{	$p = $_REQUEST['p'];		} else { $p = ''; }
if (isset ($_REQUEST['a'])) 	{ $a = $_REQUEST['a'];		} else { $a = ''; }
if (isset ($_REQUEST['id'])) 	{ $id = $_REQUEST['id'];	} else { $id = ''; }
		
switch ($m) {
	case 'clients':									include ('phplib/clients/index.php');								break;
	case 'jobs':										include ('phplib/jobs/index.php');									break;
	case 'timesheets':							include ('phplib/timesheets/index.php');						break;
		
		
		
		
	
	case 'products':								include ('phplib/products/index.php');							break;
	case 'categories':							include ('phplib/categories/index.php');						break;
	case 'product_fields':					include ('phplib/product_fields/index.php');				break;
	case 'product_brands':					include ('phplib/product_brands/index.php');				break;
	case 'product_types':						include ('phplib/product_types/index.php');					break;
	
	case 'settings':								include ('phplib/settings/index.php');							break;
	case 'headers':									include ('phplib/headers/index.php');								break;
	case 'sites':										include ('phplib/sites/index.php');									break;
	
	case 'users':										include ('phplib/users/index.php');									break;
	case 'user_bans':								include ('phplib/user_bans/index.php');							break;
	case 'user_login_history':			include ('phplib/user_login_history/index.php');		break;
	default:												include ('phplib/dashboard.php');										break;

}

?>