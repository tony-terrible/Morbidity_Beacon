<script>
$(function() {
	$('#startDate').datepicker({ dateFormat: "yy-mm-dd" });
});
</script>

<form method="post" action="index.php" name="form">
<input type="hidden" name="m" value="<?php echo $m; ?>">
<input type="hidden" name="p" value="jobs">
<input type="hidden" name="a" value="<?php echo $a; ?>">

<?php
if ($a == 'edit') { 
	try {
		
		$sth = $dbh->prepare ('SELECT * FROM jobs WHERE job_id = :job_id');
		$sth->bindParam (':job_id', $id);
		$sth->execute ();
	
		if ($sth->rowCount()) {	
			$row = $sth->fetch (PDO::FETCH_ASSOC);
			echo '<input type="hidden" name="id" value="' . $row['job_id'] . '">' . "\n";
		} else {
			echo '<div class="error">Error: ' . $module['message_name'] . ' ID not recognized.</div>';
		}
	
	} catch (PDOException $e) {
		echo '<div class="error">' . $e->getMessage() . '</div>';
	}

}
?>

<h2>General Information</h2>
<table width="100%" border="0" cellspacing="1" cellpadding="2" id="table_form">
  <tr>
    <th>Title <span class="required">*</span></th>
    <td><input name="title" type="text" class="form" id="title" size="64" maxlength="255" value="<?php echo_value ('title'); ?>"></td>
  </tr>
  <?php echo_error ('title'); ?>
	
  <tr>
    <th>Number <span class="required">*</span></th>
    <td><input name="number" type="text" class="form" id="number" size="11" maxlength="11" value="<?php echo_value ('number'); ?>"></td>
  </tr>
  <?php echo_error ('number'); ?>
	
  <tr>
    <th>Start Date <span class="required">*</span></th>
    <td><input name="startDate" type="text" class="form" id="startDate" size="12" maxlength="12" value="<?php echo_value ('startDate'); ?>"> (yyyy-mm-dd)</td>
  </tr>
  <?php echo_error ('startDate'); ?>
	
  <tr>
    <th>Client</th>
    <td><select name="client_id" id="client_id" class="form">
			<option value=""></option>
				<?php
				$sth2 = $dbh->prepare ('SELECT client_id, company FROM clients ORDER BY company ASC');
				$sth2->execute ();
			
				if ($sth2->rowCount()) {
					while ($row2 = $sth2->fetch (PDO::FETCH_ASSOC)) {
						if (isset ($row['client_id']) && $row['client_id'] == $row2['client_id']) { $selected = 'selected="selected"'; } else { $selected = ''; }
						echo '<option value="' . $row2['client_id'] . '" ' . $selected . '>' . $row2['company'] . '</option>';
					}
				}
				?>
			</select>
		</td>
  </tr>
  <?php echo_error ('client_id'); ?>
	
	<tr>
  	<th>Description</th>
    <td><textarea name="description" cols="80" rows="3" class="form" id="description"><?php echo $row['description']; ?></textarea></td>
  </tr>
	<?php echo_error ('description'); ?>
	
	<tr>
  	<th>Billing Details</th>
    <td><textarea name="billingDetails" cols="80" rows="3" class="form" id="billingDetails"><?php echo $row['billingDetails']; ?></textarea></td>
  </tr>
	<?php echo_error ('billingDetails'); ?>	
	
  <tr>
    <th>Complete</th>
    <td><select name="complete" id="complete" class="form">
			<option value="0" <?php if (isset ($row['complete']) && $row['complete'] == 0) { echo 'selected="selected"'; } ?>>No</option>
			<option value="1" <?php if (isset ($row['complete']) && $row['complete'] == 1) { echo 'selected="selected"'; } ?>>Yes</option>
			</select>
		</td>
  </tr>
  <?php echo_error ('number'); ?>
	
</table>



<table width="100%" border="0" cellspacing="1" cellpadding="2">  
  <tr>
    <td class="required">* Required Fields</td>
    <td align="right"><button type="button" name="Cancel" id="btn_cancel" onClick="window.location='index.php?m=<?php echo $m; ?>'" class="btn_cancel" />Cancel</button> <button type="submit" id="btn_submit" name="Submit" class="btn_submit">Submit</button></td>
  </tr>
</table>
</form>