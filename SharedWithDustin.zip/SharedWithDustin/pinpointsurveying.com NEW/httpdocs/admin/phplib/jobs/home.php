<script>
$(function() {
	$('#fromDate').datepicker({ dateFormat: "yy-mm-dd" });
	$('#toDate').datepicker({ dateFormat: "yy-mm-dd" });
});
</script>

<?php

if (isset ($_GET['fromDate']) && isset ($_GET['toDate'])) {
	$_SESSION['fromDate'] = $_GET['fromDate'];
	$_SESSION['toDate'] = $_GET['toDate'];
}

					 
if (!isset ($_SESSION['fromDate']) || !isset ($_SESSION['toDate'])) {
	$_SESSION['fromDate'] = date ("Y-m-d", strtotime ("NOW -90 DAY"));
	$_SESSION['toDate'] = date ("Y-m-d");
}


if (isset ($_GET['completed'])) {
	$completed = 1;
} else {
	$completed = 0;
}

?>


<div class="submenu"><?php echo '<a href="index.php?m=jobs&p=form&a=add" class="btn_add">Add Job</a>'; ?></div>



<h2>Filter</h2>
<form name="search" action="index.php" method="get">
<input type="hidden" name="m" value="jobs">
<table width="100%" border="0" cellspacing="1" cellpadding="4" id="table_search" style="margin-bottom: 10px;">
  <tr>
  	<td>Start Date From <input name="fromDate" type="text" class="form" id="fromDate" size="12" maxlength="12" value="<?php echo $_SESSION['fromDate']; ?>"> to 
			<input name="toDate" type="text" class="form" id="toDate" size="12" maxlength="12" value="<?php echo $_SESSION['toDate']; ?>"></td>
		<td><label><input type="checkbox" name="completed" value="1" <?php if ($completed == 1) { echo 'checked="checked"'; }?> >Show Completed</label></td>
		<td><input type="submit" class="form" value="Go"></td>
	</tr>
</table>
</form>


<table width="100%" border="0" cellspacing="1" cellpadding="4" id="table_list">
  <tr>
    <th width="16">&nbsp;</th>
		<th width="16">&nbsp;</th>
    <th>Start Date</th>
    <th>Title</th>
		<th>Number</th>
		<th>Client</th>
    <th width="16">&nbsp;</th>
  </tr>
  <tbody>
	<?php
  try {
		
		$sql = 'SELECT 		j.job_id, 
											j.startDate, 
											j.title, 
											j.number, 
											j.client_id, 
											c.company 
						FROM 			jobs j 
						LEFT JOIN clients c ON j.client_id = c.client_id 
						WHERE			j.startDate BETWEEN :fromDate AND :toDate
						ORDER BY job_id DESC';
    
    $sth = $dbh->prepare ($sql);
		$sth->bindParam (':fromDate', $_SESSION['fromDate']);
		$sth->bindParam (':toDate', $_SESSION['toDate']);
    $sth->execute ();
  
    if ($sth->rowCount()) {	
      while ($row = $sth->fetch (PDO::FETCH_ASSOC)) {
				       
        echo '<tr>' . "\n";
        echo '	<td width="16"><a href="index.php?m=jobs&p=view&id=' . $row['job_id'] . '"><img src="images/icons/zoom.png" border="0" alt="View"></a></td>' . "\n";
				echo '	<td width="16"><a href="index.php?m=jobs&p=form&a=edit&id=' . $row['job_id'] . '"><img src="images/icons/edit.png" border="0" alt="Edit"></a></td>' . "\n";
				echo '	<td>' . $row['startDate'] . '</td>' . "\n";
      	echo '	<td>' . $row['title'] . '</td>' . "\n";
				echo '	<td>' . $row['number'] . '</td>' . "\n";
				echo '	<td>' . $row['company'] . '</td>' . "\n";
        echo '	<td width="16"><a href="javascript:del(\'Are you sure you wish to delete this Job?\', \'index.php?m=jobs&p=home&a=del&id=' . $row['job_id'] . '\')"><img src="images/icons/delete.png" border="0" alt="Delete"></a></td>' . "\n";
        echo '</tr>' . "\n";
        
      }
    } else {
      echo '<tr>' . "\n";
      echo '	<td colspan="14"><b>No jobs found in this time frame</b></td>' . "\n";
      echo '</tr>' . "\n";
    }
		
  } catch (PDOException $e) {
    echo '<div class="error">' . $e->getMessage() . '</div>';
  }     
  ?>
	</tbody>
</table>