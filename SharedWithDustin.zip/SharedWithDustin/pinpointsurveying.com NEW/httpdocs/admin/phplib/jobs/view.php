<?php
if ($row['complete'] == 0) {
	$complete = 'No'; 
} else if ($row['complete'] == 1) { 
	$complete = 'Yes'; 
} else { 
	$complete = ''; 
}


### Gather Total Times

$totalFieldTime = 0;
$totalFieldGPSTime = 0;
$totalTravelTime = 0;
$totalOfficeTime = 0;
$totalTime = 0;

$sth2 = $dbh->prepare ("SELECT SUM(totaltime) as totaltime FROM timerecords WHERE job_id = :job_id && `type` = 'Field'");
$sth2->bindParam (':job_id', $id);
$sth2->execute ();

if ($sth2->rowCount() && $row2 = $sth2->fetch (PDO::FETCH_ASSOC)) {
	$totalFieldTime = $row2['totaltime'];
}

$sth2 = $dbh->prepare ("SELECT SUM(totaltime) as totaltime FROM timerecords WHERE job_id = :job_id && `type` = 'Field GPS'");
$sth2->bindParam (':job_id', $id);
$sth2->execute ();

if ($sth2->rowCount() && $row2 = $sth2->fetch (PDO::FETCH_ASSOC)) {
	$totalFieldGPSTime = $row2['totaltime'];
}

$sth2 = $dbh->prepare ("SELECT SUM(totaltime) as totaltime FROM timerecords WHERE job_id = :job_id && `type` = 'Travel'");
$sth2->bindParam (':job_id', $id);
$sth2->execute ();

if ($sth2->rowCount() && $row2 = $sth2->fetch (PDO::FETCH_ASSOC)) {
	$totalTravelTime = $row2['totaltime'];
}

$sth2 = $dbh->prepare ("SELECT SUM(totaltime) as totaltime FROM timerecords WHERE job_id = :job_id && `type` = 'Office'");
$sth2->bindParam (':job_id', $id);
$sth2->execute ();

if ($sth2->rowCount() && $row2 = $sth2->fetch (PDO::FETCH_ASSOC)) {
	$totalOfficeTime = $row2['totaltime'];
}

$sth2 = $dbh->prepare ("SELECT SUM(totaltime) as totaltime FROM timerecords WHERE job_id = :job_id");
$sth2->bindParam (':job_id', $id);
$sth2->execute ();

if ($sth2->rowCount() && $row2 = $sth2->fetch (PDO::FETCH_ASSOC)) {
	$totalTime = $row2['totaltime'];
}
?>


<table width="100%" border="0" cellspacing="1" cellpadding="2">
	<tr>
		<td valign="top">

			<h2>Job Information</h2>
			<table width="100%" border="0" cellspacing="1" cellpadding="2" id="table_form">
				<tr>
					<th>Title</th>
					<td><?php echo ($row['title']); ?></td>
				</tr>
				<tr>
					<th>Number</th>
					<td><?php echo ($row['number']); ?></td>
				</tr>
				<tr>
					<th>Start Date</th>
					<td><?php echo ($row['startDate']); ?></td>
				</tr>
				<tr>
					<th>Client</th>
					<td><?php echo ($row['client_id']); ?></td>
				</tr>
				<tr>
					<th>Description</th>
					<td><?php echo ($row['description']); ?></td>
				</tr>
				<tr>
					<th>Billing Details</th>
					<td><?php echo ($row['billingDetails']); ?></td>
				</tr>
				<tr>
					<th>Complete</th>
					<td><?php echo $complete; ?></td>
				</tr>
			</table>
			
		</td>
		<td valign="top">
			
			<h2>Job Time</h2>
			<table width="100%" border="0" cellspacing="1" cellpadding="2" id="table_form">
				<tr>
					<th>Total Field Time</th>
					<td align="right"><?php echo number_format ($totalFieldTime, 2); ?></td>
				</tr>
				<tr>
					<th>Total Field Time</th>
					<td align="right"><?php echo number_format ($totalFieldGPSTime, 2); ?></td>
				</tr>
				<tr>
					<th>Total Travel Time</th>
					<td align="right"><?php echo number_format ($totalTravelTime, 2); ?></td>
				</tr>
				<tr>
					<th>Total Office Time</th>
					<td align="right"><?php echo number_format ($totalOfficeTime, 2); ?></td>
				</tr>
				<tr>
					<td colspan="2"><hr></td>
				</tr>
				<tr>
					<th>Total Time</th>
					<td align="right"><?php echo number_format ($totalTime, 2); ?></td>
				</tr>
			</table>
			
		</td>
	</tr>
</table>

<h2 style="margin-top: 20px;">Time Records</h2>
<table width="100%" border="0" cellspacing="1" cellpadding="2" id="table_list">
	<tr>
		<th width="16">&nbsp;</th>
		<th>Date</th>
		<th>Type</th>
		<th align="center">Time In</th>
		<th align="center">Time Out</th>
		<th align="center">Total Hours</th>
		<th>Description</th>
		<th>Employee</th>
		<th>Invoice</th>
		<th>Timesheet</th>
		<th width="16">&nbsp;</th>
	</tr>
	<?php
	$sql = "SELECT 			t.timerecord_id,
											t.timerecord_date,
											t.type,
											t.timeIn,
											t.timeOut,
											t.totalTime,
											t.extDescription,
											t.timesheet_id,
											d.description,
											u.first_name,
											u.last_name,
											t.userType,
											t.invoice_id,
											i.invoiceNum
					FROM 				timerecords t
					LEFT JOIN 	descriptions d 	ON t.description_id = d.description_id
					LEFT JOIN 	users u 				ON t.user_id = u.user_id
					LEFT JOIN 	invoices i 			ON t.invoice_id = i.invoice_id
					WHERE 			t.job_id = :job_id
					ORDER BY 		t.timerecord_date, t.timeIn ASC";
	
	$sth2 = $dbh->prepare ($sql);
	$sth2->bindParam (':job_id', $id);
	$sth2->execute ();

	if ($sth2->rowCount()) {
		while ($row2 = $sth2->fetch (PDO::FETCH_ASSOC)) {

			if ($row2['userType'] == 0) {
				$userType = "Crewchief";
			} else if ($row2['userType'] == 1) {
				$userType = "Rodman";
			}			

			echo '<tr>';

			if ($row2['invoice_id'] == 0) {
				echo '<td width="16"><a href="index.php?m=timerecords&p=form&a=edit&id=' . $row2['timerecord_id'] . '"><img src="images/icons/edit.png" border="0" alt="Edit"></a></td>';
			} else {
				echo '<td width="16">&nbsp;</td>';
			}

			echo '<td>' . $row2['timerecord_date'] . '</td>';
			echo '<td>' . $row2['type'] . '</td>';
			echo '<td align="center">' . $row2['timeIn'] . '</td>';
			echo '<td align="center">' . $row2['timeOut'] . '</td>';
			echo '<td align="center">' . $row2['totalTime'] . '</td>';
			echo '<td>' . $row2['description'] . ' ' . $row2['extDescription'] . '</td>';
			echo '<td>' . $row2['first_name'] . ' ' . $row2['last_name'] . ' (' . $userType . ')</td>';

			echo '<td>';
			
			if ($row2['invoice_id'] == 0) {
				echo 'Not Invoiced';
			} else {

				#TODO - Create viewinvoice.php page and finish this javascript
				echo '<a href="#" onClick="javascript:viewInvoice(\'phplib/invoices/viewinvoice.php?id=' . $row2['invoice_id'] . '\')">#' . $row2['invoiceNum'] . '</a>';
				
			}
			
			echo '</td>';

			#TODO - Update this link
			echo '<td><a href="index.php?idx=timesheets&step=5&id=' . $row2['timesheet_id'] . '">' . $row2['timesheet_id'] . '</a></td>';

			if ($row2['invoice_id'] == 0) {

				#TODO - Test this link
        echo '<td width="16"><a href="javascript:del(\'Are you sure you wish to delete this Time Record?\', \'index.php?m=timerecords&p=home&a=del&id=' . $row['timerecord_id'] . '\')"><img src="images/icons/delete.png" border="0" alt="Delete"></a></td>' . "\n";

			} else {
				echo '<td width="16">&nbsp;</td>';
			}

			echo '</tr>' . "\n";		
		
		}
	} else {
		echo '<tr>';
		echo '<td colspan="14">No time records found for this job.</td>';
		echo '</tr>';
	}
	
	
	
	?>
</table>



