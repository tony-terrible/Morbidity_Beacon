<div style="position: relative;">
<?php

$module = array();
$module['m']													= 'jobs';
$module['directory'] 									= 'phplib/jobs/';
$module['message_name'] 							= 'Job';
$module['db']['table'] 								= 'jobs';
$module['db']['id_column']						= 'job_id';
$module['db']['add']['action'] 				= 'insert';
$module['db']['add']['success_msg'] 	= 'Job successfully added.';
$module['db']['add']['error_msg'] 		= 'Error adding job.';
$module['db']['edit']['action'] 			= 'update';
$module['db']['edit']['success_msg'] 	= 'Job successfully updated.';
$module['db']['edit']['error_msg'] 		= 'Error updating job.';
$module['db']['del']['action'] 				= 'delete';
$module['db']['del']['success_msg'] 	= 'Job successfully deleted.';
$module['db']['del']['error_msg'] 		= 'Error deleting job.';


if ($p == 'form' && $a == 'add') {
	$title = ' &raquo; Add ' . $module['message_name'];
} else if ($p == 'form' && $a == 'edit') {
	$title = ' &raquo; Edit ' . $module['message_name'];
} else if ($p == 'view') {
	
	$title = ' &raquo; View';
	
	$sth = $dbh->prepare ('SELECT * FROM jobs WHERE job_id = :job_id');
	$sth->bindParam (':job_id', $id);
	$sth->execute ();

	if ($sth->rowCount() && $row = $sth->fetch (PDO::FETCH_ASSOC)) {
		$title = ' &raquo; ' . $row['title'];
		
	} else {
		echo '<div class="error">Unable to find a job with that ID.  This should not have happened.</div>';
		$p = 'home';
		$title = '';
	}
	
} else {
	$title = '';
}

echo '<h1>Jobs ' . $title . '</h1>';
	
	
##################################################################################################
### Add/Edit
##################################################################################################
if (isset ($_POST['Submit'])) {
	include ($module['directory'] . 'proc.php');
	
	if (empty ($errors)) {
		$p = 'home';
	} else {
		$p = 'form';
	}
}

##################################################################################################
### Delete
##################################################################################################
if ($a == 'del') {
	include ($module['directory'] . 'proc.php');
}


##################################################################################################
### Display
##################################################################################################
switch ($p) {
	case 'home': default: include ($module['directory'] . 'home.php'); break;
	case 'form':					include ($module['directory'] . 'form.php'); break;
	case 'view':					include ($module['directory'] . 'view.php'); break;
}

?>
</div>