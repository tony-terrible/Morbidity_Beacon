<div class="submenu">&nbsp;</div>

<table width="100%" border="0" cellspacing="1" cellpadding="4" id="table_list">
  <tr>
		<th>Date &amp; Time</th>
    <th>Email</th>
    <th>IP Address</th>
		<th>Action</th>
    <th>Result</th>
    <th>Reason</th>
  </tr>
  <tbody>
	<?php
  try {
    
    $sth = $dbh->prepare ('SELECT * FROM ' . $module['db']['table'] . ' ORDER BY `log_dt` DESC');
    $sth->execute ();
  
    if ($sth->rowCount()) {	
      while ($row = $sth->fetch (PDO::FETCH_ASSOC)) {
        
        echo '<tr>' . "\n";
        echo '	<td>' . $row['log_dt'] . '</td>' . "\n";
        echo '	<td>' . $row['email_address'] . '</td>' . "\n";
        echo '	<td>' . $row['ip_address'] . '</td>' . "\n";
        echo '	<td>' . $row['action'] . '</td>' . "\n";
				echo '	<td>' . $row['result'] . '</td>' . "\n";
				echo '	<td>' . $row['reason'] . '</td>' . "\n";
        echo '</tr>' . "\n";
        
      }
    } else {
      echo '<tr>' . "\n";
      echo '	<td colspan="10"><b>No log entries found</b></td>' . "\n";
      echo '</tr>' . "\n";
    }
		
  } catch (PDOException $e) {
    echo '<div class="error">' . $e->getMessage() . '</div>';
  }     
  ?>
	</tbody>
</table>