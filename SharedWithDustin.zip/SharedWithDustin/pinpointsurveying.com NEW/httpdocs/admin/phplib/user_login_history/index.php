<div style="position: relative;">
<?php

$module = array();
$module['m']													= 'user_login_history';
$module['directory'] 									= 'phplib/user_login_history/';
$module['message_name'] 							= 'Login History';
$module['db']['table'] 								= 'user_log';
/*
$module['db']['id_column']						= 'user_id';
$module['db']['add']['action'] 				= 'insert';
$module['db']['add']['success_msg'] 	= 'User successfully added.';
$module['db']['add']['error_msg'] 		= 'Error adding user.';
$module['db']['edit']['action'] 			= 'update';
$module['db']['edit']['success_msg'] 	= 'User successfully updated.';
$module['db']['edit']['error_msg'] 		= 'Error updating user.';
$module['db']['del']['action'] 				= 'delete';
$module['db']['del']['success_msg'] 	= 'User successfully deleted.';
$module['db']['del']['error_msg'] 		= 'Error deleting user.';
*/


if ($p == 'form' && $a == 'add') {
	$title = ' &raquo; Add ' . $module['message_name'];
} else if ($p == 'form' && $a == 'edit') {
	$title = ' &raquo; Edit ' . $module['message_name'];
} else {
	$title = '';
}

echo '<h1>User Login History ' . $title . '</h1>';

if (isset ($_POST['Submit']) || $a == 'del') {
	include ($module['directory'] . 'proc.php');
	
	if (empty ($errors)) {
		$p = 'home';
	} else {
		$p = 'form';
	}
}

switch ($p) {
	case 'home': default: include ($module['directory'] . 'home.php'); break;
	case 'form':					include ($module['directory'] . "form.php"); break;
}

?>
</div>