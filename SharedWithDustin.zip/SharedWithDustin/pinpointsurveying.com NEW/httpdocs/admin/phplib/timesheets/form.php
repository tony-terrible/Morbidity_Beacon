<script>
$(function() {
	$('#date').datepicker({ dateFormat: "yy-mm-dd" });
});
</script>

<form method="post" action="index.php" name="form">
<input type="hidden" name="m" value="<?php echo $m; ?>">
<input type="hidden" name="p" value="timesheets">
<input type="hidden" name="a" value="<?php echo $a; ?>">

<h2>General Information</h2>
<table width="100%" border="0" cellspacing="1" cellpadding="2" id="table_form">
  <tr>
    <th>Date <span class="required">*</span></th>
    <td><input name="date" type="text" class="form" id="date" size="12" maxlength="12" value="<?php echo_value ('date'); ?>"> (yyyy-mm-dd)</td>
  </tr>
  <?php echo_error ('date'); ?>
	
  <tr>
    <th>User <span class="required">*</span></th>
    <td>	
			<select name="user_id" class="form">
				<option value="<?php echo $_SESSION['login']['user_id']; ?>"><?php echo $_SESSION['login']['user_name']; ?></option>
			</select>
		</td>
  </tr>
  <?php echo_error ('user_id'); ?>
</table>


<table width="100%" border="0" cellspacing="1" cellpadding="2">  
  <tr>
    <td class="required">* Required Fields</td>
    <td align="right"><button type="button" name="Cancel" id="btn_cancel" onClick="window.location='index.php?m=<?php echo $m; ?>'" class="btn_cancel" />Cancel</button> <button type="submit" id="btn_submit" name="Submit" class="btn_submit">Submit</button></td>
  </tr>
</table>
</form>