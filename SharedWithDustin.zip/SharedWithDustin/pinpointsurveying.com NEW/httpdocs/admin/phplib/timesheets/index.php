<div style="position: relative;">
<?php

$module = array();
$module['m']													= 'timesheets';
$module['directory'] 									= 'phplib/timesheets/';
$module['message_name'] 							= 'Timesheet';
$module['db']['table'] 								= 'timesheets';
$module['db']['id_column']						= 'timesheet_id';
$module['db']['add']['action'] 				= 'insert';
$module['db']['add']['success_msg'] 	= 'Timesheet successfully added.';
$module['db']['add']['error_msg'] 		= 'Error adding Timesheet.';
$module['db']['edit']['action'] 			= 'update';
$module['db']['edit']['success_msg'] 	= 'Timesheet successfully updated.';
$module['db']['edit']['error_msg'] 		= 'Error updating Timesheet.';
$module['db']['del']['action'] 				= 'delete';
$module['db']['del']['success_msg'] 	= 'Timesheet successfully deleted.';
$module['db']['del']['error_msg'] 		= 'Error deleting Timesheet.';


if ($p == 'form' && $a == 'add') {
	$title = ' &raquo; Add ' . $module['message_name'];
} else if ($p == 'form' && $a == 'edit') {
	$title = ' &raquo; Edit ' . $module['message_name'];
} else if ($p == 'view') {
	
	$title = ' &raquo; View';
	
	/*
	$sth = $dbh->prepare ('SELECT * FROM timesheets WHERE job_id = :job_id');
	$sth->bindParam (':job_id', $id);
	$sth->execute ();

	if ($sth->rowCount() && $row = $sth->fetch (PDO::FETCH_ASSOC)) {
		$title = ' &raquo; ' . $row['title'];
		
	} else {
		echo '<div class="error">Unable to find a job with that ID.  This should not have happened.</div>';
		$p = 'home';
		$title = '';
	}
	*/
	
} else {
	$title = '';
}

echo '<h1>Timesheets ' . $title . '</h1>';
	
	
##################################################################################################
### Add/Edit
##################################################################################################
if (isset ($_POST['Submit'])) {
	include ($module['directory'] . 'proc.php');
	
	if (empty ($errors)) {
		$p = 'view';
	} else {
		$p = 'form';
	}
}

##################################################################################################
### Delete
##################################################################################################
if ($a == 'del') {
	include ($module['directory'] . 'proc.php');
}


##################################################################################################
### Display
##################################################################################################
switch ($p) {
	case 'home': default: include ($module['directory'] . 'home.php'); break;
	case 'form':					include ($module['directory'] . 'form.php'); break;
	case 'view':					include ($module['directory'] . 'view.php'); break;
}

?>
</div>