<script>

function calctime() {

	timeInHH = document.form.timeInHH.value;
	timeInMM = document.form.timeInMM.value
	timeOutHH = document.form.timeOutHH.value
	timeOutMM = document.form.timeOutMM.value

	totalTime = (timeOutHH-timeInHH) + ((timeOutMM-timeInMM)/60);

	document.form.totalTime.value = totalTime;

	return false;
}



function checkForm() {
	if (document.form.job_id.value != "" ||
		document.form.type.value != "" ||
		document.form.timeInHH.value != "" ||
		document.form.timeOutHH.value != "" ||
		document.form.description_id.value != "" ||
		document.form.crewchief.checked ||
		document.form.rodman.checked) {
		alert ('Please finish adding your time record, or clear the form to continue.');
		return false;
	}
	if (!document.form.complete) { alert ('You cannot submit an empty timesheet.'); return false; }
	if (!document.form.complete.checked) { alert ('You must check complete to submit.'); return false; }

	else { return true; }
}

function checkAddFor () {
	if (document.form.job_id.value == "") { alert ('Please select a job.'); document.form.job_id.focus(); return false; }
	if (document.form.type.value == "") { alert ('Please select a type.'); document.form.type.focus(); return false; }
	if (document.form.timeInHH.value == "") { alert ('Please select your time in.'); document.form.timeInHH.focus(); return false; }
	if (document.form.timeOutHH.value == "") { alert ('Please select your time out.'); document.form.timeOutHH.focus(); return false; }
	if (document.form.description_id.value == "") { alert ('Please select a description.'); document.form.description_id.focus(); return false; }
	if (!document.form.crewchief.checked && !document.form.rodman.checked) {
		alert ('You must select either Crewchief, Rodman or both.');
		return false;
	}
	if (document.form.rodman.checked && document.form.rodman_id.value == "") {
		alert ('Please select a Rodman.');
		return false;
	}
	else { return true; }
}


function list_timerecords () {
	$.ajax ({
		url: 'ajax/timesheets.view.listrecords.php',
		type: 'get',
		dataType: 'html',
		data: { timesheet_id: $('#timesheet_id').val() },
		success: function (data) {
			$('#timerecords_tbody').html(data);
		}
	});
}
	
$(function() {
	
	list_timerecords ();
	
});
	
</script>

<?php
$sth = $dbh->prepare ('SELECT t.*, CONCAT_WS (" ", u.first_name, u.last_name) as username FROM timesheets t LEFT JOIN users u ON t.user_id = u.user_id WHERE timesheet_id = :timesheet_id');
$sth->bindParam (':timesheet_id', $id);
$sth->execute ();

if ($sth->rowCount() && $row = $sth->fetch(PDO::FETCH_ASSOC)) {
	
} else {
	echo '<div class="error">Error: That timesheet ID was not found.</div>';
}





if (isset ($_POST['timeInHH'])) { $timeInHH = $_POST['timeInHH']; } else { $timeInHH = ''; }
if (isset ($_POST['timeInMM'])) { $timeInMM = $_POST['timeInMM']; } else { $timeInMM = ''; }
if (isset ($_POST['timeOutHH'])) { $timeOutHH = $_POST['timeOutHH']; } else { $timeOutHH = ''; }
if (isset ($_POST['timeOutMM'])) { $timeOutMM = $_POST['timeOutMM']; } else { $timeOutMM = ''; }



if (isset ($_POST['addtimerecord'])) {
	echo '<pre>'; print_r ($_POST); echo '</pre>';
	
	
	
	
	
	
	
	
	
	
}
?>






<input type="hidden" name="timesheet_id" id="timesheet_id" value="<?php echo $id; ?>">
<input type="hidden" name="nextTimeInHH" id="nextTimeInHH" value="">

			
<table width="100%" border="0" cellspacing="1" cellpadding="2" id="table_form">
	<tr>
		<th>Date</th>
		<td><?php echo $row['date']; ?></td>
	</tr>
	<tr>
		<th>Created By</th>
		<td><?php echo $row['username']; ?></td>
	</tr>
</table>
			

<h2 style="margin-top: 20px;">Add Time Record</h2>

<form name="form" method="post" action="index.php?m=timesheets&p=view&id=<?php echo $id; ?>">
<input type="hidden" name="user_id" value="<?php echo $row['user_id']; ?>">
<input type="hidden" name="date" value="<?php echo $row['date']; ?>">





<table width="100%" border="0" cellspacing="1" cellpadding="2" id="table_form">
	<tr>
		<th>Date</th>
		<td><?php echo $row['date']; ?></td>
		<th width="150">Job <span class="required">*</span></th>
		<td><select name="job_id" id="job_id" class="form" style="width: 240px;">
			<option value=""></option>
			<?php
			$sth2 = $dbh->prepare ('SELECT * FROM jobs WHERE complete = 0 ORDER BY number ASC');
			$sth2->execute();
			
			if ($sth2->rowCount()) {
				while ($row2 = $sth2->fetch (PDO::FETCH_ASSOC)) {
					echo '<option value="' . $row2['job_id'] . '">' . $row2['number'] . ' - ' . $row2['title'] . '</option>';
				}
			}
			?>
			</select>
		</td>
	</tr>
	
	<tr>
	  <th>Time In <span class="required">*</span></th>
	  <td><select name="timeInHH" id="timeInHH" class="form" onchange="calctime(this);">
			<option value=""></option>
		
			<?php
			
			for ($i = 0; $i <= 23; $i++) {
				if ($timeOutHH <= $i) {
					echo '<option value="' . $i . '">' . date ("h a", strtotime ("2000-01-01 $i:00")) . '</option>';
				}
			}
			
			/*
			?>
						
						
						
			<?php if ($timeOutHH <= "00") { ?><option value="00">12 am</option><?php } ?>
			<?php if ($timeOutHH <= "01") { ?><option value="01">1 am</option><?php } ?>
			<?php if ($timeOutHH <= "02") { ?><option value="02">2 am</option><?php } ?>
			<?php if ($timeOutHH <= "03") { ?><option value="03">3 am</option><?php } ?>
			<?php if ($timeOutHH <= "04") { ?><option value="04">4 am</option><?php } ?>
			<?php if ($timeOutHH <= "05") { ?><option value="05">5 am</option><?php } ?>
			<?php if ($timeOutHH <= "06") { ?><option value="06">6 am</option><?php } ?>
			<?php if ($timeOutHH <= "07") { ?><option value="07">7 am</option><?php } ?>
			<?php if ($timeOutHH <= "08") { ?><option value="08">8 am</option><?php } ?>
			<?php if ($timeOutHH <= "09") { ?><option value="09">9 am</option><?php } ?>
			<?php if ($timeOutHH <= "10") { ?><option value="10">10 am</option><?php } ?>
			<?php if ($timeOutHH <= "11") { ?><option value="11">11 am</option><?php } ?>
			<?php if ($timeOutHH <= "12") { ?><option value="12">12 pm</option><?php } ?>
			<?php if ($timeOutHH <= "13") { ?><option value="13">1 pm</option><?php } ?>
			<?php if ($timeOutHH <= "14") { ?><option value="14">2 pm</option><?php } ?>
			<?php if ($timeOutHH <= "15") { ?><option value="15">3 pm</option><?php } ?>
			<?php if ($timeOutHH <= "16") { ?><option value="16">4 pm</option><?php } ?>
			<?php if ($timeOutHH <= "17") { ?><option value="17">5 pm</option><?php } ?>
			<?php if ($timeOutHH <= "18") { ?><option value="18">6 pm</option><?php } ?>
			<?php if ($timeOutHH <= "19") { ?><option value="19">7 pm</option><?php } ?>
			<?php if ($timeOutHH <= "20") { ?><option value="20">8 pm</option><?php } ?>
			<?php if ($timeOutHH <= "21") { ?><option value="21">9 pm</option><?php } ?>
			<?php if ($timeOutHH <= "22") { ?><option value="22">10 pm</option><?php } ?>
			<?php if ($timeOutHH <= "23") { ?><option value="23">11 pm</option><?php } ?>
			
			*/
			?>

			</select> : 
			<input name="timeInMM" type="text" class="form" id="timeInMM" size="2" maxlength="2" value="<?php if (!isset ($timeOutMM) || $timeOutMM == "") { echo "00"; } else { echo "$timeOutMM"; } ?>" onblur="calctime(this);"> 
		</td>
		<th>Type <span class="required">*</span></th>
		<td>
			<select name="type" id="type" class="form">
				<option value=""></option>
				<option value="Field">Field Time</option>
				<option value="Field GPS">Field GPS Time</option>
				<option value="Travel">Travel Time</option>
				<option value="Office">Office Time</option>
			</select>
		</td>
	</tr>
	<tr>
		<th>Time Out <span class="required">*</span></th>
		<td>
			<select name="timeOutHH" id="timeOutHH" class="form" onchange="calctime(this);">
			<option value=""></option>
			<?php

			for ($i = 0; $i <= 23; $i++) {
				if ($timeOutHH <= $i) {
					echo '<option value="' . $i . '">' . date ("h a", strtotime ("2000-01-01 $i:00")) . '</option>';
				}
			}

			/*
			?>
						
						



			<?php if ($timeOutHH <= "00") { ?><option value="00">12 am</option><?php } ?>
			<?php if ($timeOutHH <= "01") { ?><option value="01">1 am</option><?php } ?>
			<?php if ($timeOutHH <= "02") { ?><option value="02">2 am</option><?php } ?>
			<?php if ($timeOutHH <= "03") { ?><option value="03">3 am</option><?php } ?>
			<?php if ($timeOutHH <= "04") { ?><option value="04">4 am</option><?php } ?>
			<?php if ($timeOutHH <= "05") { ?><option value="05">5 am</option><?php } ?>
			<?php if ($timeOutHH <= "06") { ?><option value="06">6 am</option><?php } ?>
			<?php if ($timeOutHH <= "07") { ?><option value="07">7 am</option><?php } ?>
			<?php if ($timeOutHH <= "08") { ?><option value="08">8 am</option><?php } ?>
			<?php if ($timeOutHH <= "09") { ?><option value="09">9 am</option><?php } ?>
			<?php if ($timeOutHH <= "10") { ?><option value="10">10 am</option><?php } ?>
			<?php if ($timeOutHH <= "11") { ?><option value="11">11 am</option><?php } ?>
			<?php if ($timeOutHH <= "12") { ?><option value="12">12 pm</option><?php } ?>
			<?php if ($timeOutHH <= "13") { ?><option value="13">1 pm</option><?php } ?>
			<?php if ($timeOutHH <= "14") { ?><option value="14">2 pm</option><?php } ?>
			<?php if ($timeOutHH <= "15") { ?><option value="15">3 pm</option><?php } ?>
			<?php if ($timeOutHH <= "16") { ?><option value="16">4 pm</option><?php } ?>
			<?php if ($timeOutHH <= "17") { ?><option value="17">5 pm</option><?php } ?>
			<?php if ($timeOutHH <= "18") { ?><option value="18">6 pm</option><?php } ?>
			<?php if ($timeOutHH <= "19") { ?><option value="19">7 pm</option><?php } ?>
			<?php if ($timeOutHH <= "20") { ?><option value="20">8 pm</option><?php } ?>
			<?php if ($timeOutHH <= "21") { ?><option value="21">9 pm</option><?php } ?>
			<?php if ($timeOutHH <= "22") { ?><option value="22">10 pm</option><?php } ?>
			<?php if ($timeOutHH <= "23") { ?><option value="23">11 pm</option><?php } ?>

			*/
			?>
			</select> : 
			<input name="timeOutMM" type="text" class="form" id="timeOutMM" onblur="calctime(this);" value="00" size="2" maxlength="2"> 
		</td>
		<th>Total Time</th>
		<td><input name="totalTime" type="text" id="totalTime" size="5" maxlength="14" class="form" readonly> Hours</td>
	</tr>
			
			
	<tr>
		<th>Description <span class="required">*</span></th>
		<td><select name="description_id" id="description_id" class="form" style="width: 240px;">
			<option value=""></option>
			<?php
			$sth2 = $dbh->prepare ('SELECT * FROM descriptions ORDER BY description ASC');
			$sth2->execute();
			
			if ($sth2->rowCount()) {
				while ($row2 = $sth2->fetch (PDO::FETCH_ASSOC)) {
					echo '<option value="' . $row2['description_id'] . '">' . $row2['description'] . '</option>';
				}
			}
			?>
			</select>
		</td>
		<th>Extended Description </th>
		<td><input name="extDescription" type="text" id="extDescription" size="40" maxlength="250" class="form"></td>
	</tr>
	<tr>
		<th>Crewchief</th>
		<td><?php echo $_SESSION['login']['user_name']; ?></td>
		<th>Rodman</th>
		<td><select name="rodman_id" id="rodman_id" class="form">
			<option value=""></option>
			<?php
			$sth2 = $dbh->prepare ('SELECT * FROM users WHERE user_id != :user_id && active = "Yes" && rodman = "Yes" ORDER BY first_name, last_name ASC');
			$sth2->bindParam (':user_id', $_SESSION['login']['user_id']);
			$sth2->execute();
			
			if ($sth2->rowCount()) {
				while ($row2 = $sth2->fetch (PDO::FETCH_ASSOC)) {
					echo '<option value="' . $row2['user_id'] . '">' . $row2['first_name'] . ' ' . $row2['last_name'] . '</option>';
				}
			}
			?>
			</select>
		</td>
	</tr>
	<tr>
		<th>Add For <span class="required">*</span></th>
		<td colspan="3">
			<label><input name="crewchief" type="checkbox" class="form" id="crewchief" value="yes" checked>Crewchief</label>
			<label><input name="rodman" type="checkbox" class="form" id="rodman" value="yes" checked>Rodman</label>
		</td>
	</tr>
	<tr>
		<td width="150">&nbsp;</td>
		<td colspan="3"><input type="submit" name="addtimerecord" value="   Add   " class="form" id="addtimerecord" onclick="return checkAddFor(this);"></td>
	</tr>
</table>

</form>




<h2 style="margin-top: 20px;">Time Records</h2>
<table width="100%" border="0" cellspacing="1" cellpadding="2" id="table_list">
	<tr>
		<th>Job Number</th>
		<th>Type</th>
		<th align="center">Time</th>
		<th align="center">Hours</th>
		<th>Description</th>
		<th>Employee</th>
	</tr>
	<tbody id="timerecords_tbody"></tbody>
</table>



