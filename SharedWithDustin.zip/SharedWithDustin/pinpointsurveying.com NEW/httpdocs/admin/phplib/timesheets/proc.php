<?php
$db = array ();
$errors = array();

if ($a == 'add' || $a == 'edit') {
	
	########################################################################################################################################################################
	### Add / Edit
	########################################################################################################################################################################
	
	$fields = array (
		'date' 				=> array ('rules' => 'required|date', 									'filters' => '',												'readable' => 'Date'),
		'user_id'			=> array ('rules' => 'numeric', 												'filters' => '',												'readable' => 'User')
	);


	$gump = new GUMP();
	$_POST = $gump->sanitize ($_POST);

	$_rules = array();
	$_filters = array();
	foreach ($fields as $field => $i) {

		if (isset ($i['rules']) && !empty ($i['rules'])) {
			$_rules[$field] = $i['rules'];
		}

		if (isset ($i['filters']) && !empty ($i['filters'])) {
			$_filters[$field] = $i['filters'];
		}			

		if (isset ($i['readable']) && !empty ($i['readable'])) {
			$gump->set_field_name ($field, $i['readable']);
		}
	}

	$gump->validation_rules ($_rules);
	$gump->filter_rules ($_filters);

	$validated_data = $gump->run($_POST);
	
	if ($validated_data === false) {

		$errors = $gump->get_errors_array();
	
	} else {

		$db = array ();
		foreach ($fields as $field => $x) {
			$db[$field] = $validated_data[$field];
		}

	}
	
} else if ($a == 'del') {
	
	########################################################################################################################################################################
	### Delete
	########################################################################################################################################################################	

	$errors['delete'] = 'Error';
	
	/*
	
	### First check to make sure no invoices or time records for this job
	$sth = $dbh->prepare ("SELECT * FROM invoices WHERE job_id = :job_id LIMIT 1");
	$sth->bindParam (':job_id', $id);
	$sth->execute ();

	if ($sth->rowCount()) {
		$errors['delete'] = 'Unable to delete jobs that have timerecords and/or invoices attached to them';
	}

	$sth = $dbh->prepare ("SELECT * FROM timerecords WHERE job_id = :job_id LIMIT 1");
	$sth->bindParam (':job_id', $id);
	$sth->execute ();

	if ($sth->rowCount()) {
		$errors['delete'] = 'Unable to delete jobs that have timerecords and/or invoices attached to them';
	}
	
	*/
	
}


if (empty ($errors)) {
	if (db ($module['db'][$a]['action'], $module['db']['table'], $db, $module['db']['id_column'], $id)) {
		echo '<div class="success">' . $module['db'][$a]['success_msg']. '</div>' . "\n";	
	} else {
		echo '<div class="error">' . $module['db'][$a]['error_msg']. '</div>' . "\n";
	}
}



?>