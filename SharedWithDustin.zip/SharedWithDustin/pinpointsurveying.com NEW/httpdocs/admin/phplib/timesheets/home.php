<script>
$(function() {
	$('#fromDate').datepicker({ dateFormat: "yy-mm-dd" });
	$('#toDate').datepicker({ dateFormat: "yy-mm-dd" });
});
</script>

<?php

if (isset ($_GET['fromDate']) && isset ($_GET['toDate'])) {
	$_SESSION['fromDate'] = $_GET['fromDate'];
	$_SESSION['toDate'] = $_GET['toDate'];
}

					 
if (!isset ($_SESSION['fromDate']) || !isset ($_SESSION['toDate'])) {
	$_SESSION['fromDate'] = date ("Y-m-d", strtotime ("NOW -90 DAY"));
	$_SESSION['toDate'] = date ("Y-m-d");
}
?>


<div class="submenu"><?php echo '<a href="index.php?m=timesheets&p=form&a=add" class="btn_add">Add Timesheet</a>'; ?></div>



<h2>Filter</h2>
<form name="search" action="index.php" method="get">
<input type="hidden" name="m" value="timesheets">
<table width="100%" border="0" cellspacing="1" cellpadding="4" id="table_search" style="margin-bottom: 10px;">
  <tr>
  	<td>Start Date From <input name="fromDate" type="text" class="form" id="fromDate" size="12" maxlength="12" value="<?php echo $_SESSION['fromDate']; ?>"> to 
			<input name="toDate" type="text" class="form" id="toDate" size="12" maxlength="12" value="<?php echo $_SESSION['toDate']; ?>"></td>
		<td>
			<select name="user_id" class="form">
				<option value="All">All Users</option>
				<?php
				$sth = $dbh->prepare ('SELECT user_id, first_name, last_name FROM users ORDER BY first_name, last_name ASC');
				$sth->execute ();

				if ($sth->rowCount()) {	
					while ($row = $sth->fetch (PDO::FETCH_ASSOC)) {	
						echo '<option value="' . $row['user_id'] . '">' . $row['first_name'] . ' ' . $row['last_name'] . '</option>';
					}
				}
				?>
			</select>
		</td>
		<td><input type="submit" class="form" value="Go"></td>
	</tr>
</table>
</form>


<table width="100%" border="0" cellspacing="1" cellpadding="4" id="table_list">
  <tr>
    <th width="16">&nbsp;</th>
    <th>Date</th>
    <th>Created By</th>
		<th>Complete?</th>
		<th>Records</th>
    <th width="16">&nbsp;</th>
  </tr>
  <tbody>
	<?php
  try {
		
		$sql = "SELECT		t.timesheet_id,
											t.date,
											t.complete,
											u.first_name,
											u.last_name,
											COUNT(tr.timesheet_id) AS time_records
						FROM 			timesheets t
						LEFT JOIN users u ON t.user_id = u.user_id
						LEFT JOIN timerecords tr ON t.timesheet_id = tr.timesheet_id	
						WHERE			t.date BETWEEN :fromDate AND :toDate
						GROUP BY 	t.timesheet_id
						ORDER BY 	t.timesheet_id DESC";
    
    $sth = $dbh->prepare ($sql);
		$sth->bindParam (':fromDate', $_SESSION['fromDate']);
		$sth->bindParam (':toDate', $_SESSION['toDate']);
    $sth->execute ();
  
    if ($sth->rowCount()) {	
      while ($row = $sth->fetch (PDO::FETCH_ASSOC)) {
				
				if ($row['complete']) {
					$complete = 'Yes';
				} else {
					#TODO - Fix this link
					$complete = 'No (<a href="index.php?m=timesheets&step=3&timesheet_id=' . $row['timesheet_id'] . '">Continue</a>)';
				}
				
				
				       
        echo '<tr>' . "\n";
        echo '	<td width="16"><a href="index.php?m=timesheets&p=view&id=' . $row['timesheet_id'] . '"><img src="images/icons/zoom.png" border="0" alt="View"></a></td>' . "\n";
				echo '	<td>' . $row['date'] . '</td>' . "\n";
      	echo '	<td>' . $row['first_name'] . ' ' . $row['last_name'] . '</td>' . "\n";
				echo '	<td>' . $complete . '</td>' . "\n";
				echo '	<td>' . $row['time_records'] . '</td>' . "\n";
        echo '	<td width="16"><a href="javascript:del(\'Are you sure you wish to delete this Timesheet?\', \'index.php?m=timesheets&p=home&a=del&id=' . $row['timesheet_id'] . '\')"><img src="images/icons/delete.png" border="0" alt="Delete"></a></td>' . "\n";
        echo '</tr>' . "\n";
        
      }
    } else {
      echo '<tr>' . "\n";
      echo '	<td colspan="14"><b>No timesheets found in this time frame</b></td>' . "\n";
      echo '</tr>' . "\n";
    }
		
  } catch (PDOException $e) {
    echo '<div class="error">' . $e->getMessage() . '</div>';
  }     
  ?>
	</tbody>
</table>