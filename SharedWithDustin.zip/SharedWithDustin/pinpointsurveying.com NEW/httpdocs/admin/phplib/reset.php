<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Password Reset - <?php echo $config['site']['name']; ?></title>
<link href="css/login.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div id="login_holder">
<form name="login" action="index.php?reset" method="post">
<table width="100%" border="0" cellspacing="0" cellpadding="2">
  <tr>
    <td colspan="2" align="center"><img src="<?php echo $config['site']['logo']; ?>" width="<?php echo $config['site']['logowidth']; ?>" height="<?php echo $config['site']['logoheight']; ?>" border="0" alt="<?php echo $config['site']['name']; ?>"/></td>
  </tr>
  <tr>
    <td colspan="2"><h1>Password Reset</h1></td>
  </tr>
  <?php
	if (isset ($reset_password_error) && $reset_password_error === true) {
		echo '<tr>' . "\n";
		echo '	<td colspan="2"><div class="success">A new password has been generated and emailed to you.</div></td>' . "\n";
		echo '</tr>   ' . "\n";
	} else if (isset ($reset_password_error)) {
		echo '<tr>' . "\n";
		echo '	<td colspan="2"><div class="error">' . $reset_password_error . '</div></td>' . "\n";
		echo '</tr>   ' . "\n"; 
	}
	?>
  <tr>
    <td>Email Address:</td>
    <td><input name="email_address" type="text" size="32" maxlength="64" /></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input name="reset" type="submit" value="Reset Password" class="button" /> or <a href="index.php">return to login</a>?</td>
  </tr>
</table>
</form>
</div>
</body>
</html>