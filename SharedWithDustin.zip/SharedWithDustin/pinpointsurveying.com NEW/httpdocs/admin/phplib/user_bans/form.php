<form method="post" action="index.php" name="form">
<input type="hidden" name="m" value="<?php echo $m; ?>">
<input type="hidden" name="p" value="home">
<input type="hidden" name="a" value="<?php echo $a; ?>">

<?php
if ($a == 'edit') { 
	try {
		
		$sth = $dbh->prepare ('SELECT * FROM ' . $module['db']['table']. ' WHERE ' . $module['db']['id_column'] . ' = :id');
		$sth->bindParam (':id', $id);
		$sth->execute ();
	
		if ($sth->rowCount()) {	
			$row = $sth->fetch (PDO::FETCH_ASSOC);
			echo '<input type="hidden" name="id" value="' . $row[$module['db']['id_column']] . '">' . "\n";
		} else {
			echo '<div class="error">Error: ' . $module['message_name'] . ' ID not recognized.</div>';
		}
	
	} catch (PDOException $e) {
		echo '<div class="error">' . $e->getMessage() . '</div>';
	}

}
?>

<h2>Ban Information</h2>
<table width="100%" border="0" cellspacing="1" cellpadding="2" id="table_form">
  <tr>
    <th>Email Address</th>
    <td><input name="email_address" type="text" class="form" id="email_address" size="64" maxlength="64" value="<?php echo_value ('email_address'); ?>"></td>
  </tr>
  <?php echo_error ('email_address'); ?>
  <tr>
    <th>IP Address</th>
    <td><input name="ip_address" type="text" class="form" id="ip_address" size="15" maxlength="15" value="<?php echo_value ('ip_address'); ?>"></td>
  </tr>
  <?php echo_error ('ip_address'); ?>
  <tr>
    <th>Reason <span class="required">*</span></th>
    <td><input name="reason" type="text" class="form" id="reason" size="64" maxlength="128" value="<?php echo_value ('reason'); ?>"></td>
  </tr>
  <?php echo_error ('reason'); ?>
</table>

<table width="100%" border="0" cellspacing="1" cellpadding="2">  
  <tr>
    <td class="required">* Required Fields</td>
    <td align="right"><button type="button" name="Cancel" id="btn_cancel" onClick="window.location='index.php?m=<?php echo $m; ?>'" class="btn_cancel" />Cancel</button> <button type="submit" id="btn_submit" name="Submit" class="btn_submit">Submit</button></td>
  </tr>
</table>
</form>