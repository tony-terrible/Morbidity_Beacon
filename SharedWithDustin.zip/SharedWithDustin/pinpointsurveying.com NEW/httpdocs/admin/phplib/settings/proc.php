<?php
$db = array ();
$errors = array();

if ($a == 'add' || $a == 'edit') {
	
	########################################################################################################################################################################
	### Add / Edit
	########################################################################################################################################################################
	
	$fields = array ('value');
	$req_fields = array ('value');
	
	### Check that the required fields have values using the above arrays, custom fields go below.
	foreach ($fields as $field) {
		if (in_array ($field, $req_fields)) {
			if (isset ($_POST[$field]) && !empty ($_POST[$field])) {
				$db[$field] = $_POST[$field];
			} else {
				$errors[$field] = 'This is a required field.';
			}
		} else {
			$db[$field] = $_POST[$field];
		}
	}
	
	### Custom Fields 

	
} else if ($a == 'del') {
	
	########################################################################################################################################################################
	### Delete
	########################################################################################################################################################################	
	
}


if (empty ($errors)) {
	if (db ($module['db'][$a]['action'], $module['db']['table'], $db, $module['db']['id_column'], $id)) {
		echo '<div class="success">' . $module['db'][$a]['success_msg']. '</div>' . "\n";
	} else {
		echo '<div class="error">' . $module['db'][$a]['error_msg']. '</div>' . "\n";
	}
}



?>