<div class="submenu">&nbsp;</div>
<table width="100%" border="0" cellspacing="1" cellpadding="4" id="table_list">
  <tr>
    <th width="16">&nbsp;</th>
    <th>Name</th>
    <th>Value</th>
    <!--<th width="16">&nbsp;</th>//-->
  </tr>
  <tbody>
	<?php
  try {
    
    $sth = $dbh->prepare ('SELECT * FROM ' . $module['db']['table'] . ' ORDER BY `name` ASC');
    $sth->execute ();
  
    if ($sth->rowCount()) {	
      while ($row = $sth->fetch (PDO::FETCH_ASSOC)) {
        
        echo '<tr>' . "\n";
        echo '	<td width="16"><a href="index.php?m=' . $m . '&p=form&a=edit&id=' . $row[$module['db']['id_column']] . '"><img src="images/icons/edit.png" border="0" alt="Edit"></a></td>' . "\n";
        echo '	<td>' . $row['friendly_name'] . '</td>' . "\n";
        echo '	<td>' . $row['value'] . '</td>' . "\n";
        //echo '	<td width="16"><a href="javascript:del(\'Are you sure you wish to delete this ' . $module['message_name'] . '?\', \'index.php?m=' . $m . '&p=home&a=del&id=' . $row[$module['db']['id_column']] . '\')"><img src="images/icons/delete.png" border="0" alt="Delete"></a></td>' . "\n";
        echo '</tr>' . "\n";
        
      }
    } else {
      echo '<tr>' . "\n";
      echo '	<td colspan="4"><b>No settings found</b></td>' . "\n";
      echo '</tr>' . "\n";
    }
		
  } catch (PDOException $e) {
    echo '<div class="error">' . $e->getMessage() . '</div>';
  }     
  ?>
	</tbody>
</table>