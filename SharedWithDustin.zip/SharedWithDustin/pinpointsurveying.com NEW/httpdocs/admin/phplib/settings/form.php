<form method="post" action="index.php" name="form">
<input type="hidden" name="m" value="<?php echo $m; ?>">
<input type="hidden" name="p" value="home">
<input type="hidden" name="a" value="<?php echo $a; ?>">

<?php
if ($a == 'edit') { 
	try {
		
		$sth = $dbh->prepare ('SELECT * FROM ' . $module['db']['table']. ' WHERE ' . $module['db']['id_column'] . ' = :id');
		$sth->bindParam (':id', $id);
		$sth->execute ();
	
		if ($sth->rowCount()) {	
			$row = $sth->fetch (PDO::FETCH_ASSOC);
			echo '<input type="hidden" name="id" value="' . $row[$module['db']['id_column']] . '">' . "\n";
		} else {
			echo '<div class="error">Error: ' . $module['message_name'] . ' ID not recognized.</div>';
		}
	
	} catch (PDOException $e) {
		echo '<div class="error">' . $e->getMessage() . '</div>';
	}

}
?>

<h2>Setting</h2>
<table width="100%" border="0" cellspacing="1" cellpadding="2" id="table_form">
  <tr>
    <th>Friendly Name <span class="required">*</span></th>
    <td><input name="friendly_name" type="text" class="form" id="friendly_name" size="64" maxlength="64" readonly="readonly" value="<?php echo_value ('friendly_name'); ?>"></td>
  </tr>
  <tr>
    <th>Value <span class="required">*</span></th>
    <td><input name="value" type="text" class="form" id="value" size="128" maxlength="128" value="<?php echo_value ('value'); ?>"></td>
  </tr>
  <?php echo_error ('value'); ?>
</table>


<table width="100%" border="0" cellspacing="1" cellpadding="2">  
  <tr>
    <td class="required">* Required Fields</td>
    <td align="right"><button type="button" name="Cancel" id="btn_cancel" onClick="window.location='index.php?m=<?php echo $m; ?>'" class="btn_cancel" />Cancel</button> <button type="submit" id="btn_submit" name="Submit" class="btn_submit">Submit</button></td>
  </tr>
</table>
</form>