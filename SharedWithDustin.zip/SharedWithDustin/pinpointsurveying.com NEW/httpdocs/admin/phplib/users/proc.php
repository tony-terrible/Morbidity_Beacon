<?php
$db = array ();
$errors = array();

if ($a == 'add' || $a == 'edit') {
	
	########################################################################################################################################################################
	### Add / Edit
	########################################################################################################################################################################
	
	$fields = array ('first_name', 'last_name', 'email_address', 'hourlyWage', 'vacationRate', 'active', 'rodman', 'userlevel');
	$req_fields = $fields;
	
	### Check that the required fields have values using the above arrays, custom fields go below.
	foreach ($fields as $field) {
		if (in_array ($field, $req_fields)) {
			if (isset ($_POST[$field]) && (!empty ($_POST[$field]) || ($_POST[$field] == 0))) {
				$db[$field] = $_POST[$field];
			} else {
				$errors[$field] = 'This is a required field.';
			}
		} else {
			$db[$field] = $_POST[$field];
		}
	}
	
	### Custom Fields 
	$do_password = false;
	if ($a == 'add') {
		if (isset ($_POST['password']) && !empty ($_POST['password']) && isset ($_POST['confirm_password']) && !empty ($_POST['confirm_password'])) {
			$do_password = true;
		} else {
			$errors['password'] = 'You must enter and confirm the password.';
		}
	} else if ($a == 'edit') {
		if ((isset ($_POST['password']) && !empty ($_POST['password'])) || (isset ($_POST['confirm_password']) && !empty ($_POST['confirm_password']))) {
			if (isset ($_POST['password']) && !empty ($_POST['password']) && isset ($_POST['confirm_password']) && !empty ($_POST['confirm_password'])) {
				$do_password = true;
			} else {
				$errors['password'] = 'You must enter and confirm the password.';
			}
		}
	}
	
	if ($do_password) {
		if ($_POST['password'] == $_POST['confirm_password']) { 
			$t_hasher = new PasswordHash (8, FALSE);
			$db['password'] = $t_hasher->HashPassword ($_POST['password']);
			unset ($t_hasher);
		} else {
			$errors['password'] = 'The passwords you entered did not match.';
		}
	}

	
} else if ($a == 'del') {
	
	########################################################################################################################################################################
	### Delete
	########################################################################################################################################################################	
	
}


if (empty ($errors)) {
	if (db ($module['db'][$a]['action'], $module['db']['table'], $db, $module['db']['id_column'], $id)) {
		echo '<div class="success">' . $module['db'][$a]['success_msg']. '</div>' . "\n";	
	} else {
		echo '<div class="error">' . $module['db'][$a]['error_msg']. '</div>' . "\n";
	}
}



?>