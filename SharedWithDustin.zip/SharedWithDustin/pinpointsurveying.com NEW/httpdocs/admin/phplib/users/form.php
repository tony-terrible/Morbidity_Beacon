<script>
function change_admin () {
	
}
</script>

<form method="post" action="index.php" name="form">
<input type="hidden" name="m" value="<?php echo $m; ?>">
<input type="hidden" name="p" value="home">
<input type="hidden" name="a" value="<?php echo $a; ?>">

<?php
if ($a == 'edit') { 
	try {
		
		$sth = $dbh->prepare ('SELECT * FROM ' . $module['db']['table']. ' WHERE ' . $module['db']['id_column'] . ' = :id');
		$sth->bindParam (':id', $id);
		$sth->execute ();
	
		if ($sth->rowCount()) {	
			$row = $sth->fetch (PDO::FETCH_ASSOC);
			echo '<input type="hidden" name="id" value="' . $row[$module['db']['id_column']] . '">' . "\n";
		} else {
			echo '<div class="error">Error: ' . $module['message_name'] . ' ID not recognized.</div>';
		}
	
	} catch (PDOException $e) {
		echo '<div class="error">' . $e->getMessage() . '</div>';
	}

}
?>

<h2>General Information</h2>
<table width="100%" border="0" cellspacing="1" cellpadding="2" id="table_form">
  <tr>
    <th>First Name <span class="required">*</span></th>
    <td><input name="first_name" type="text" class="form" id="first_name" size="32" maxlength="32" value="<?php echo_value ('first_name'); ?>"></td>
  </tr>
  <?php echo_error ('first_name'); ?>
  <tr>
    <th>Last Name <span class="required">*</span></th>
    <td><input name="last_name" type="text" class="form" id="last_name" size="32" maxlength="32" value="<?php echo_value ('last_name'); ?>"></td>
  </tr>
  <?php echo_error ('last_name'); ?>
  <tr>
    <th>Email Address <span class="required">*</span></th>
    <td><input name="email_address" type="text" class="form" id="email_address" size="64" maxlength="64" value="<?php echo_value ('email_address'); ?>"></td>
  </tr>
  <?php echo_error ('email_address'); ?>
	
  <tr>
    <th>Hourly Wage <span class="required">*</span><span style="float: right;">$</span></th>
    <td><input name="hourlyWage" type="text" class="form" id="hourlyWage" size="6" maxlength="6" value="<?php echo_value ('hourlyWage'); ?>"></td>
  </tr>
  <?php echo_error ('hourlyWage'); ?>
	
  <tr>
    <th>Vacation Rate <span class="required">*</span></th>
    <td><input name="vacationRate" type="text" class="form" id="vacationRate" size="6" maxlength="6" value="<?php echo_value ('vacationRate'); ?>"></td>
  </tr>
  <?php echo_error ('vacationRate'); ?>

	<tr>
		<th>Active <span class="required">*</span></th>
    <td>
			<select name="active" class="form" id="active">
    	<option value="No" <?php if ($a == 'add' || $row['active'] == 'No') { echo 'selected="selected"'; } ?>>No</option>
    	<option value="Yes" <?php if ($row['active'] == 'Yes') { echo 'selected="selected"'; } ?>>Yes</option>
    	</select>
    </td>
  </tr>
	<?php echo_error ('active'); ?>
	
	<tr>
		<th>Rodman <span class="required">*</span></th>
    <td>
			<select name="rodman" class="form" id="rodman">
    	<option value="No" <?php if ($a == 'add' || $row['rodman'] == 'No') { echo 'selected="selected"'; } ?>>No</option>
    	<option value="Yes" <?php if ($row['rodman'] == 'Yes') { echo 'selected="selected"'; } ?>>Yes</option>
    	</select>
    </td>
  </tr>
	<?php echo_error ('rodman'); ?>	
	
	<tr>
		<th>User Level <span class="required">*</span></th>
    <td>
			<select name="userlevel" class="form" id="userlevel">
    	<option value="User" <?php if ($a == 'add' || $row['userlevel'] == 'User') { echo 'selected="selected"'; } ?>>User</option>
    	<option value="Admin" <?php if ($row['userlevel'] == 'Admin') { echo 'selected="selected"'; } ?>>Admin</option>
    	</select>
    </td>
  </tr>
	<?php echo_error ('userlevel'); ?>
	
</table>


<h2>Password <?php if ($a == 'edit') { echo '(Only enter if changing)'; } ?></h2>
<table width="100%" border="0" cellspacing="1" cellpadding="2" id="table_form">
  <tr>
    <th>Password <?php if ($a == 'add') { echo '<span class="required">*</span>'; } ?></th>
    <td><input name="password" id="password" type="password" class="form" size="12" maxlength="12"></td>
  </tr>
  <tr>
    <th>Confirm Password <?php if ($a == 'add') { echo '<span class="required">*</span>'; } ?></th>
    <td><input name="confirm_password" id="confirm_password" type="password" class="form" size="12" maxlength="12"></td>
  </tr>
  <?php echo_error ('password'); ?>
</table>

<table width="100%" border="0" cellspacing="1" cellpadding="2">  
  <tr>
    <td class="required">* Required Fields</td>
    <td align="right"><button type="button" name="Cancel" id="btn_cancel" onClick="window.location='index.php?m=<?php echo $m; ?>'" class="btn_cancel" />Cancel</button> <button type="submit" id="btn_submit" name="Submit" class="btn_submit">Submit</button></td>
  </tr>
</table>
</form>