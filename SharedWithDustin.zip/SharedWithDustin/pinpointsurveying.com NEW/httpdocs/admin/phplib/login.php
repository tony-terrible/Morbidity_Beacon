<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Login - <?php echo $config['site']['name']; ?></title>
<link href="css/login.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div id="login_holder">
<form name="login" action="index.php?login" method="post">
<table width="100%" border="0" cellspacing="0" cellpadding="2">
  <tr>
    <td colspan="2" align="center"><img src="<?php echo $config['site']['logo']; ?>" width="<?php echo $config['site']['logowidth']; ?>" height="<?php echo $config['site']['logoheight']; ?>" border="0" alt="<?php echo $config['site']['name']; ?>"/></td>
  </tr>
  <tr>
    <td colspan="2"><h1>Administration Login</h1></td>
  </tr>
  <?php
	if (isset ($login_error) && !empty ($login_error)) {
		echo '<tr>' . "\n";
		echo '	<td colspan="2"><div class="error">' . $login_error . '</div></td>' . "\n";
		echo '</tr>   ' . "\n"; 
	}
	?>
  <tr>
    <td>Email Address:</td>
    <td><input name="email_address" type="text" size="32" maxlength="64" value="<?php if (isset ($_POST['email_address'])) { echo $_POST['email_address']; } ?>" /></td>
  </tr>
  <tr>
    <td>Password:</td>
    <td><input name="password" type="password" size="32" maxlength="32" value="" /></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input name="login" type="submit" value="Login" class="button" /> or <a href="index.php?reset">forgot password</a>?</td>
  </tr>
</table>
</form>
</div>
</body>
</html>