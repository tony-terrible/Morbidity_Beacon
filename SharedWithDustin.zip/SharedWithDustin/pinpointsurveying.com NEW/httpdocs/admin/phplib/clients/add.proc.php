<?php

$_rules = array(
	'company'    					=> 'required|max_len,255|min_len,6',
	'fieldTimePrice'    	=> 'required|numeric',
	'fieldgpsTimePrice'   => 'required|numeric',
	'travelTimePrice'     => 'required|numeric',
	'officeTimePrice' 		=> 'required|numeric'
);

$_filters = array(
	'company'    					=> 'trim|sanitize_string'
);

$_readable = array(
	'company'    					=> 'Company',
	'fieldTimePrice'    	=> 'Field Time Price',
	'fieldgpsTimePrice'   => 'Field GPS Time Price',
	'travelTimePrice'     => 'Travel Time Price',
	'officeTimePrice' 		=> 'Office Time Price'
);

$gump = new GUMP();
$_POST = $gump->sanitize ($_POST);
$gump->validation_rules ($_rules);
$gump->filter_rules ($_filters);

foreach ($_readable as $field => $readable) {
	$gump->set_field_name ($field, $readable);
}

$validated_data = $gump->run($_POST);

if ($validated_data === false) {
	$errors = $gump->get_errors_array();
} else {
	
	$db = array ();
	foreach ($_rules as $field => $x) {
		$db[$field] = $validated_data[$field];
	}

	if (db ('insert', 'clients', $db)) {
		$_SESSION['add_client_id'] = $dbh->lastInsertId();
	} else {
		$errors['general'] = 'An error has occurred';
	}
	
}

?>