<form method="post" action="index.php" name="form">
<input type="hidden" name="m" value="clients">
<input type="hidden" name="p" value="add">

<h2>Required Information</h2>
<table width="100%" border="0" cellspacing="1" cellpadding="2" id="table_form">
	<?php echo_error ('general'); ?>
  <tr>
    <th>Company <span class="required">*</span></th>
    <td><input name="company" type="text" class="form" id="company" size="64" maxlength="255" value="<?php echo_value ('company'); ?>"></td>
  </tr>
  <?php echo_error ('company'); ?>
	
  <tr>
    <th>Field Time Price <span class="required">*</span><span style="float: right;">$</span></th>
    <td><input name="fieldTimePrice" type="text" class="form" id="fieldTimePrice" size="6" maxlength="6" value="<?php echo_value ('fieldTimePrice'); ?>"></td>
  </tr>
  <?php echo_error ('fieldTimePrice'); ?>
	
  <tr>
    <th>Field GPS Time Price <span class="required">*</span><span style="float: right;">$</span></th>
    <td><input name="fieldgpsTimePrice" type="text" class="form" id="fieldgpsTimePrice" size="6" maxlength="6" value="<?php echo_value ('fieldgpsTimePrice'); ?>"></td>
  </tr>
  <?php echo_error ('fieldgpsTimePrice'); ?>	
	
  <tr>
    <th>Travel Time Price <span class="required">*</span><span style="float: right;">$</span></th>
    <td><input name="travelTimePrice" type="text" class="form" id="travelTimePrice" size="6" maxlength="6" value="<?php echo_value ('travelTimePrice'); ?>"></td>
  </tr>
  <?php echo_error ('travelTimePrice'); ?>
	
  <tr>
    <th>Office Time Price <span class="required">*</span><span style="float: right;">$</span></th>
    <td><input name="officeTimePrice" type="text" class="form" id="officeTimePrice" size="6" maxlength="6" value="<?php echo_value ('officeTimePrice'); ?>"></td>
  </tr>
  <?php echo_error ('officeTimePrice'); ?>
	
</table>

<table width="100%" border="0" cellspacing="1" cellpadding="2">  
  <tr>
    <td class="required">* Required Fields</td>
    <td align="right"><button type="button" name="Cancel" id="btn_cancel" onClick="window.location='index.php?m=<?php echo $m; ?>'" class="btn_cancel" />Cancel</button> <button type="submit" id="btn_submit" name="Submit" class="btn_submit">Submit</button></td>
  </tr>
</table>
</form>