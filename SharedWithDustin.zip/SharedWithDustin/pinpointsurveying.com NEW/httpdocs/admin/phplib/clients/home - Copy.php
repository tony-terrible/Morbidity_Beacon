<?php
$_SESSION['add_client_id'] = '';


#######################################################################################################################################
### Retrieve/Store Job URL Information to maintain search and page throughout session.
#######################################################################################################################################
$jobs_opts = array();

if (isset ($_SESSION['jobs_opts'])) {
	$jobs_opts = $_SESSION['jobs_opts'];
}

if (isset ($_GET['Go'])) {
	$jobs_opts['page'] = '1';
	foreach ($_GET as $key => $val) {
		if ($key != 'm' && $key != 'p' && $key != 'Go' && $key != 'page' && $key != 'perpage' && !empty ($val)) {
			$jobs_opts[$key] = $val;
		}
	}
}

if (isset ($_GET['clear'])) { $jobs_opts = array(); }

if (isset ($_GET['page'])) { $jobs_opts['page'] = $_GET['page']; } 
if (isset ($_GET['perpage'])) { $jobs_opts['perpage'] = $_GET['perpage']; $jobs_opts['page'] = '1'; }
if (isset ($_GET['sortby'])) { $jobs_opts['sortby'] = $_GET['sortby']; } 
if (isset ($_GET['sortorder'])) { $jobs_opts['sortorder'] = $_GET['sortorder']; } 

if (!isset ($jobs_opts['page'])) { $jobs_opts['page'] = '1'; }
if (!isset ($jobs_opts['sortby'])) { $jobs_opts['sortby'] = 'job_number'; }
if (!isset ($jobs_opts['sortorder'])) { $jobs_opts['sortorder'] = 'DESC'; }
if (!isset ($jobs_opts['perpage'])) { $jobs_opts['perpage'] = '25'; }
if (!isset ($jobs_opts['status'])) { $jobs_opts['status'] = 'Active'; }

// store $contacts_opts for session
$_SESSION['jobs_opts'] = $jobs_opts;
#######################################################################################################################################
?>

<script>
function clear_search () {
	window.location.replace('index.php?m=jobs&clear');
}



$(function() {
	
	$(document).tooltip();

	$("#contact").autocomplete({
		source: "ajax/autocomplete.contacts.php", 
		minLength: 2,
		select: function (event, ui) {
			$('#primary_cid').val(ui.item.contact_id);
			$('#contact').val(ui.item.contact);
			return false;
		}
	}).autocomplete("instance")._renderItem = function( ul, item ) {
      return $( "<li style='border-bottom: 1px dotted #666;'>" )
        .append( "<a><strong>" + item.contact + "</strong><br><span class='small'>" + item.email + "</span></a>" )
        .appendTo( ul );
	};
	
});
</script>


<div class="submenu"><a href="index.php?m=clients&p=add" class="btn_add">Add Client</a></div>

<h2>Job Search</h2>
<form name="searchform" id="searchform" method="get" action="index.php">
<input type="hidden" name="m" value="jobs" />
<table width="100%" border="0" cellspacing="1" cellpadding="2" id="table_search" style="margin-bottom: 10px;">
  <tr>
  	<td>
    	<h2>Job Number:</h2>
      <input name="job_number" id="job_number" type="text" size="12" maxlength="12" class="form" value="<?php if (isset ($jobs_opts['job_number'])) { echo $jobs_opts['job_number']; } ?>" onKeyPress="return noEnter(event)" />
    </td>
  	<td>
    	<h2>Contact:</h2>
      <input type="hidden" name="primary_cid" id="primary_cid" value="<?php if (isset ($jobs_opts['primary_cid'])) { echo $jobs_opts['primary_cid']; } ?>" />
			<input name="contact" id="contact" type="text" class="form" size="32" maxlength="64" value="<?php if (isset ($jobs_opts['contact'])) { echo $jobs_opts['contact']; } ?>" onKeyPress="return noEnter(event)" />     
    </td>
    <td>
    	<h2>Job Type:</h2>
    	<select name="type_id" id="type_id" onKeyPress="return noEnter(event)" class="form">
      <option value=""></option>
			<?php
			$sth2 = $dbh->prepare ('SELECT * FROM job_types ORDER BY type ASC');			
			$sth2->execute ();
		
			if ($sth2->rowCount()) {	
				while ($row2 = $sth2->fetch (PDO::FETCH_ASSOC)) {
					if (isset ($jobs_opts['type_id']) && ($jobs_opts['type_id'] == $row2['type_id'])) { $selected = 'selected="selected"'; } else { $selected = ''; }
					echo '<option value="' . $row2['type_id'] . '" ' . $selected . '>' . $row2['type'] . '</option>' . "\n";
				}
			}
			?>
			</select>      
    </td>
    <td width="120" align="center" valign="middle" rowspan="2">
      <input name="Go" class="form" type="submit" value="Search" style="padding: 5px" class="form" />
      <input name="Go" class="form" type="button" value="Clear" onKeyPress="clear_search()" onClick="clear_search()" style="padding: 5px" class="form" />
    </td>
  </tr>
  <tr>
  	<td>
    	<h2>Plan Number:</h2>
      <input name="plan_number" id="plan_number" type="text" size="12" maxlength="12" class="form" value="<?php if (isset ($jobs_opts['plan_number'])) { echo $jobs_opts['plan_number']; } ?>" onKeyPress="return noEnter(event)" />
    </td>
  	<td>
    	<h2>Address:</h2>
			<input name="address" id="address" type="text" class="form" size="32" maxlength="32" value="<?php if (isset ($jobs_opts['address'])) { echo $jobs_opts['address']; } ?>" onKeyPress="return noEnter(event)" />     
    </td>
    <td></td>
  </tr>
</table>
</form>


<?php
function sortable_header ($title, $sortby) {
	global $jobs_opts, $m;
	if ($jobs_opts['sortby'] == $sortby) {
		if ($jobs_opts['sortorder'] == 'ASC') {
			echo '<th class="asc"><a href="index.php?m=' . $m . '&sortorder=DESC">' . $title . '</a></th>';
		} else if ($jobs_opts['sortorder'] == 'DESC') {
			echo '<th class="desc"><a href="index.php?m=' . $m . '&sortorder=ASC">' . $title . '</a></th>';
		} else {
			echo '<th><a href="index.php?m=' . $m . '&sortby=' . $sortby . '&sortorder=ASC">' . $title . '</a></th>';
		}
	} else {
		echo '<th><a href="index.php?m=' . $m . '&sortby=' . $sortby . '&sortorder=ASC">' . $title . '</a></th>';
	}
}


?>

<h2>Jobs</h2>
<table width="100%" border="0" cellspacing="1" cellpadding="4" id="table_list">
  <tr>
    <th width="16">&nbsp;</th>
    <th width="16">&nbsp;</th>
    <?php sortable_header ('Job Num', 'job_number'); ?>
    <?php sortable_header ('Client', 'client'); ?>
    <th>Plan Number(s)</th>
    <th>Lot(s)</th>
    <th>Civic Address(es)</th>
    <?php sortable_header ('Last Update', 'date_last_updated'); ?>
    <th width="16">&nbsp;</th>
  </tr>
	<?php
  try {
		
		$sql = 'SELECT 		j.job_id,
											j.primary_cid,
											j.job_number,
											j.job_number_ext,
											j.date_last_updated,
											c.company_name,
											c.first_name,
											c.last_name,
											c.sort as client
						FROM 			jobs j
						LEFT JOIN	contacts c ON j.primary_cid = c.cid ';

		if (isset ($jobs_opts['address']) && !empty ($jobs_opts['address'])) {	
			$sql.= 'LEFT JOIN job_civic_addresses jca ON j.job_id = jca.job_id ' . "\n";
		}
		
		if (isset ($jobs_opts['plan_number']) && !empty ($jobs_opts['plan_number'])) {	
			$sql.= 'LEFT JOIN job_legal_descriptions jld ON j.job_id = jld.job_id ' . "\n";
			$sql.= 'LEFT JOIN job_plans_created jpc ON j.job_id = jpc.job_id ' . "\n";
			
			$jobs_opts['sortby'] = ' ISNULL(jpc.plan_number), ' . $jobs_opts['sortby'];
			$jobs_opts['sortorder'] = 'ASC';
			
		}
		
		
		if (isset ($jobs_opts['address']) && !empty ($jobs_opts['address'])) {	
			if (strstr ($sql, 'WHERE')) { $sql .= " && "; } else { $sql .= " WHERE "; }
			$sql.= 'CONCAT_WS(\' \', jca.unit, jca.street_number, jca.street_name, jca.type, jca.direction, jca.city, jca.province) LIKE :address ' . "\n";
		}

		if (isset ($jobs_opts['plan_number']) && !empty ($jobs_opts['plan_number'])) {	
			if (strstr ($sql, 'WHERE')) { $sql .= " && "; } else { $sql .= " WHERE "; }
			$sql.= 'jld.plan_number LIKE :plan_number1 || jpc.plan_number LIKE :plan_number2 ' . "\n";
		}

						
		if (isset ($jobs_opts['job_number']) && !empty ($jobs_opts['job_number'])) {	
			if (strstr ($sql, 'WHERE')) { $sql .= " && "; } else { $sql .= " WHERE "; }
			$sql .= 'j.job_number LIKE :job_number ' . "\n";
		}
		
		if (isset ($jobs_opts['primary_cid']) && !empty ($jobs_opts['primary_cid'])) {	
			if (strstr ($sql, 'WHERE')) { $sql .= " && "; } else { $sql .= " WHERE "; }
			$sql .= 'j.primary_cid LIKE :primary_cid ' . "\n";
		}		
		
		if (isset ($jobs_opts['type_id']) && !empty ($jobs_opts['type_id'])) {	
			if (strstr ($sql, 'WHERE')) { $sql .= " && "; } else { $sql .= " WHERE "; }
			$sql .= 'j.job_id IN (SELECT job_id FROM job_types_join WHERE type_id = :type_id)' . "\n";
		}


		
		### Sorting
						
		$sql .= ' ORDER BY ' . $jobs_opts['sortby'] . ' ' . $jobs_opts['sortorder'];
		
		### Get total results at this point
    $sth = $dbh->prepare ($sql);
		
		if (isset ($jobs_opts['address']) 		&& !empty ($jobs_opts['address'])) 			{	$sth->bindValue ('address', '%' . $jobs_opts['address'] . '%'); 				}
		if (isset ($jobs_opts['plan_number']) && !empty ($jobs_opts['plan_number'])) 	{	$sth->bindValue ('plan_number1', '%' . $jobs_opts['plan_number'] . '%'); $sth->bindValue ('plan_number2', '%' . $jobs_opts['plan_number'] . '%'); }
		//if (isset ($jobs_opts['plan_number']) && !empty ($jobs_opts['plan_number'])) 	{	$sth->bindValue ('plan_number1', $jobs_opts['plan_number']); $sth->bindValue ('plan_number2', $jobs_opts['plan_number']); }
		if (isset ($jobs_opts['job_number']) 	&& !empty ($jobs_opts['job_number'])) 	{	$sth->bindValue ('job_number', '%' . $jobs_opts['job_number'] . '%'); 	}
		if (isset ($jobs_opts['primary_cid']) && !empty ($jobs_opts['primary_cid'])) 	{	$sth->bindValue ('primary_cid', $jobs_opts['primary_cid']);							}		
		if (isset ($jobs_opts['type_id']) 		&& !empty ($jobs_opts['type_id'])) 			{	$sth->bindValue ('type_id', $jobs_opts['type_id']);											}

    $sth->execute ();
    $total_results = $sth->rowCount();
		
		
		### Add Pagination
		if ($jobs_opts['page'] == 1) {
			$start = 0;
		} else {
			$start = ($jobs_opts['page']-1) * $jobs_opts['perpage'];
		}
		
		$sql .= ' LIMIT ' . $start . ',' . $jobs_opts['perpage'];		
		
		//echo '<div class="error"><strong>Debug Info:</strong><br><pre>'; echo $sql; echo '</pre></div>';


		
		### Run the main query
    $sth = $dbh->prepare ($sql);
		
		if (isset ($jobs_opts['address']) 		&& !empty ($jobs_opts['address'])) 			{	$sth->bindValue ('address', '%' . $jobs_opts['address'] . '%'); 				}
		if (isset ($jobs_opts['plan_number']) && !empty ($jobs_opts['plan_number'])) 	{	$sth->bindValue ('plan_number1', '%' . $jobs_opts['plan_number'] . '%'); $sth->bindValue ('plan_number2', '%' . $jobs_opts['plan_number'] . '%'); }
		if (isset ($jobs_opts['job_number']) 	&& !empty ($jobs_opts['job_number'])) 	{	$sth->bindValue ('job_number', '%' . $jobs_opts['job_number'] . '%'); 	}
		if (isset ($jobs_opts['primary_cid']) && !empty ($jobs_opts['primary_cid'])) 	{	$sth->bindValue ('primary_cid', $jobs_opts['primary_cid']);							}		
		if (isset ($jobs_opts['type_id']) 		&& !empty ($jobs_opts['type_id'])) 			{	$sth->bindValue ('type_id', $jobs_opts['type_id']);											}

    $sth->execute ();
  
    if ($sth->rowCount()) {	
      while ($row = $sth->fetch (PDO::FETCH_ASSOC)) {
				
				$contact = format_contact ($row);
				$job_number = $row['job_number'];
				
				if ($row['job_number_ext'] != 0) {
					$job_number .= '.' . $row['job_number_ext'];
				}
				        
        echo '<tr>' . "\n";
        echo '	<td width="16"><a href="index.php?m=jobs&p=view&id=' . $row['job_id'] . '"><img src="images/icons/edit.png" border="0" alt="Edit" title="Edit Job"></a></td>' . "\n";
				echo '	<td width="16"><a href="javascript:duplicate(\'index.php?m=jobs&p=home&a=duplicate&id=' . $row['job_id'] . '\')"><img src="images/icons/duplicate.png" border="0" alt="Duplicate" title="Duplicate Job"></a></td>' . "\n";
        echo '	<td>' . $job_number . '</td>' . "\n";
				echo '	<td><a href="index.php?m=contacts&p=form&a=edit&id=' . $row['primary_cid'] . '">' . $contact . '</a></td>' . "\n";
				
				// Plan Numbers & Lots
				$lot_numbers = array();
				$count = 0;
				echo '	<td><span class="small">' . "\n";
				$sth2 = $dbh->prepare ('SELECT plan_number_type, plan_number, lot_number FROM job_legal_descriptions WHERE job_id = :job_id');
				$sth2->bindValue (':job_id', $row['job_id']);
				$sth2->execute ();
			
				if ($sth2->rowCount()) {	
					$total = $sth2->rowCount();
					while ($row2 = $sth2->fetch (PDO::FETCH_ASSOC)) {
						echo $row2['plan_number_type'] . ' ' . $row2['plan_number'];
						$lot_numbers[$row2['lot_number']] = $row2['lot_number'];
						$count++;
						if ($count < $total) { echo ', '; }
					}
				}
				
				$sth2 = $dbh->prepare ('SELECT plan_type, plan_number FROM job_plans_created WHERE job_id = :job_id');
				$sth2->bindValue (':job_id', $row['job_id']);
				$sth2->execute ();
			
				if ($sth2->rowCount()) {
					
					if ($count > 0) {
						echo ', ';
					}
						
					$total = $sth2->rowCount();
					$count = 0;
					echo '<span style="font-weight: bold;">';
					while ($row2 = $sth2->fetch (PDO::FETCH_ASSOC)) {
						echo $row2['plan_type'] . ' ' . $row2['plan_number'];
						$count++;
						if ($count < $total) { echo ', '; }
					}
					echo '</span>';
				}
				
				echo '	</span></td>' . "\n";
				
				// Lot Numbers
				$total = count ($lot_numbers);
				$count = 0;
				echo '	<td><span class="small">' . "\n";
				
				foreach ($lot_numbers as $lot_number) {
					echo $lot_number;
					
					$count++;
					if ($count < $total) { echo ', '; }
				}
				
				echo '	</span></td>' . "\n";
				
				
				// Civic Addresses
				echo '	<td><span class="small" style="white-space: nowrap;">' . "\n";
				$sth2 = $dbh->prepare ('SELECT * FROM job_civic_addresses cja WHERE cja.job_id = :job_id');
				$sth2->bindValue (':job_id', $row['job_id']);
				$sth2->execute ();
			
				if ($sth2->rowCount()) {	
					$total = $sth2->rowCount();
					$count = 0;
					while ($row2 = $sth2->fetch (PDO::FETCH_ASSOC)) {

						echo format_civic_address ($row2);
						
						$count++;
						if ($count < $total) { echo ',<br>'; }
					}
				}
				echo '	</span></td>' . "\n";
				
				 echo '	<td><span class="small" style="white-space: nowrap;">' . $row['date_last_updated'] . '</span></td>' . "\n";
        echo '	<td width="16"><a href="javascript:del(\'Are you sure you wish to delete this Job?\', \'index.php?m=jobs&p=home&a=del&id=' . $row['job_id'] . '\')"><img src="images/icons/delete.png" border="0" alt="Delete" title="Delete Job"></a></td>' . "\n";
        echo '</tr>' . "\n";
        
      }
    } else {
      echo '<tr>' . "\n";
      echo '	<td colspan="12"><b>No jobs found</b></td>' . "\n";
      echo '</tr>' . "\n";
    }
		
  } catch (PDOException $e) {
    echo '<div class="error">' . $e->getMessage() . '</div>';
  }     
  ?>
</table>



<?php
############################################################################################################################################################
### PAGINATION
############################################################################################################################################################

### New URL
$jobs_url = $jobs_opts;
unset ($jobs_url['page']);
unset ($jobs_url['perpage']);
$jobs_url = 'index.php?m=jobs';

echo '<table cellpadding="0" cellspacing="0" width="100%" border="0" style="margin-top: 20px;">' . "\n";
echo '<tr>' . "\n";
echo '	<td width="200"><img src="images/spacer.gif" width="200" height="10"></td>' . "\n";
echo '	<td align="center">' . "\n";

	### Pagination
	$p = new pagination;
	$p->items($total_results);
	$p->limit($jobs_opts['perpage']);
	$p->currentPage($jobs_opts['page']);
	$p->parameterName('page');
	$p->target($jobs_url);
	$p->show();	

echo '	</td>' . "\n";
echo '	<td width="200" align="right">' . "\n";

	echo '<div class="pagination">Per Page: ';
	$per_page_options = array ('25', '50', '100', '250');
	foreach ($per_page_options as $x => $y) {
		if ($y == $jobs_opts['perpage']) {
			echo '<span class="current">' . $y . '</span>';
		} else {
			echo '<a href="' . $jobs_url . '&perpage=' . $y . '">' . $y . '</a>';
		}
	}
	echo '</div>';

echo '  </td>' . "\n";
echo '</tr>' . "\n";
echo '</table>';

?>







