<script>
function list_notes () {
	$.ajax ({
		url: 'ajax/clients.notes.list.php',
		type: 'get',
		dataType: 'json',
		data: { client_id: $('#client_id').val() },
		success: function (data) {
			$('#notes_tbody').html(data.html);
			$('#num_notes').html(data.total);
		}
	});
}

function edit_note (id, note) {
	
	$('#note_id').val(id);
	$('#note').val(note);
	$('#notes_form').find(":submit").attr('value', 'Update');
	
}

function del_note (id) {
	$("#confirm_delete").html ('<p><span class="ui-icon ui-icon-alert" style="float:left; margin:0 7px 20px 0;"></span>Are you sure you wish to delete this note?</p><p>This action cannot be reversed.</p>');
	$("#confirm_delete").dialog ({
		width: 350,
		height: 200,
		resizable: false,
		modal: true,
		buttons: {
			Delete: function () {
				$.ajax ({
					url: 'ajax/clients.notes.delete.php',
					type: 'get',
					data: { id: id, client_id: $('#client_id').val() },
					success: function () {
						list_notes();
						$("#confirm_delete").dialog("close");
					}
				});
			},
			Cancel: function () { $(this).dialog("close"); } 
		}
	});	
}

$(function() {
	
	$('#notes_form').submit (function(e) {
		$.ajax ({
			type: $('#notes_form').attr('method'),
			url: $('#notes_form').attr('action'),
			data: $('#notes_form').serialize(),
			success: function (data) {
				if (data.match (/error/i)) {
					alert (data);
				} else {
					$('#notes_form').trigger("reset");
					$('#note_id').val('');
					$('#notes_form').find(":submit").attr('value', 'Add');
				}
			}
		}).done (function (msg) {
			list_notes();
		});
	
		e.preventDefault();

	});
	
	list_notes();

});
</script>
<h2>Add New Note</h2>
<form id="notes_form" name="notes_form" action="ajax/clients.notes.add.php" method="post">
<input type="hidden" name="client_id" id="client_id" value="<?php echo $client_id; ?>" />
<input type="hidden" name="note_id" id="note_id" value="" />
<table width="100%" border="0" cellspacing="1" cellpadding="4" id="table_list">
	<tr>
  	<th>Note</th>
    <th width="30">&nbsp;</th>
  </tr>
  <tr>
  	<td><input name="note" id="note" type="text" class="form" size="64" maxlength="64" value="" /></td>
    <td width="30"><input name="Add" type="submit" value="Add" class="form" /></td>
  </tr> 
</table>
</form>




<h2 style="margin-top: 16px;">Notes</h2>
<table width="100%" border="0" cellspacing="1" cellpadding="4" id="table_list" style="margin-bottom: 10px;">
<tr>
  	<th width="16">&nbsp;</th>
    <th>&nbsp;</th>
    <th>Note</th>
    <th width="16">&nbsp;</th>
  </tr>
	<tbody id="notes_tbody">
  <tr>
  	<td colspan="8">Loading...</td>
  </tr>
  </tbody>
</table>