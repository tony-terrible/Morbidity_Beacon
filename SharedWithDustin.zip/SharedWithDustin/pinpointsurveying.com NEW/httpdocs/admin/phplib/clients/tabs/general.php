<h2>General Information</h2>

<form id="general_form" name="general_form">
<input type="hidden" name="client_id" id="client_id" value="<?php echo $client_id; ?>">

<table width="100%" border="0" cellspacing="1" cellpadding="0" id="table_form">
  <tr>
    <th>Company <span class="required">*</span></th>
    <td><input name="company" type="text" class="form" id="company" size="64" maxlength="255" value="<?php echo_value ('company'); ?>"></td>
  </tr>
	
  <tr>
    <th>Contact</th>
    <td><input name="contact" type="text" class="form" id="contact" size="64" maxlength="255" value="<?php echo_value ('contact'); ?>"></td>
  </tr>
	
  <tr>
    <th>Email</th>
    <td><input name="email" type="text" class="form" id="email" size="64" maxlength="255" value="<?php echo_value ('email'); ?>"></td>
  </tr>		
</table>
	
	
<h2 style="margin-top: 20px;">Address</h2>
<table width="100%" border="0" cellspacing="1" cellpadding="0" id="table_form">
	<tr>
    <th>Address Line 1</th>
    <td><input name="address1" type="text" class="form" id="address1" size="64" maxlength="255" value="<?php echo_value ('address1'); ?>"></td>
  </tr>	
  <tr>
    <th>Address Line 2</th>
    <td><input name="address2" type="text" class="form" id="address2" size="64" maxlength="255" value="<?php echo_value ('address2'); ?>"></td>
  </tr>		
  <tr>
    <th>City</th>
    <td><input name="city" type="text" class="form" id="city" size="64" maxlength="255" value="<?php echo_value ('city'); ?>"></td>
  </tr>		
  <tr>
    <th>Province/State</th>
    <td><input name="province_state" type="text" class="form" id="province_state" size="2" maxlength="2" value="<?php echo_value ('province_state'); ?>"></td>
  </tr>			
  <tr>
    <th>Postal/Zip Code</th>
    <td><input name="postal_zip" type="text" class="form" id="postal_zip" size="8" maxlength="8" value="<?php echo_value ('postal_zip'); ?>"></td>
  </tr>			
  <tr>
    <th>Country</th>
    <td><input name="country" type="text" class="form" id="country" size="64" maxlength="255" value="<?php echo_value ('country'); ?>"></td>
	</tr>
</table>
	
	
<h2 style="margin-top: 20px;">Phone Numbers</h2>
<table width="100%" border="0" cellspacing="1" cellpadding="0" id="table_form">
	<tr>
    <th>Phone 1</th>
    <td><input name="phone1" type="text" class="form" id="phone1" size="14" maxlength="14" value="<?php echo_value ('phone1'); ?>"> (eg: xxx-xxx-xxxx)</td>
  </tr>			
  <tr>
    <th>Phone 2</th>
    <td><input name="phone2" type="text" class="form" id="phone2" size="14" maxlength="14" value="<?php echo_value ('phone2'); ?>"> (eg: xxx-xxx-xxxx)</td>
  </tr>				
  <tr>
    <th>Fax</th>
    <td><input name="fax" type="text" class="form" id="fax" size="14" maxlength="14" value="<?php echo_value ('fax'); ?>"> (eg: xxx-xxx-xxxx)</td>
  </tr>				
</table>
	
	
<h2 style="margin-top: 20px;">Rates</h2>
<table width="100%" border="0" cellspacing="1" cellpadding="0" id="table_form">
	<tr>
    <th>Field Time Price <span class="required">*</span><span style="float: right;">$</span></th>
    <td><input name="fieldTimePrice" type="text" class="form" id="fieldTimePrice" size="6" maxlength="6" value="<?php echo_value ('fieldTimePrice'); ?>"></td>
  </tr>
	
  <tr>
    <th>Field GPS Time Price <span class="required">*</span><span style="float: right;">$</span></th>
    <td><input name="fieldgpsTimePrice" type="text" class="form" id="fieldgpsTimePrice" size="6" maxlength="6" value="<?php echo_value ('fieldgpsTimePrice'); ?>"></td>
  </tr>
	
  <tr>
    <th>Travel Time Price <span class="required">*</span><span style="float: right;">$</span></th>
    <td><input name="travelTimePrice" type="text" class="form" id="travelTimePrice" size="6" maxlength="6" value="<?php echo_value ('travelTimePrice'); ?>"></td>
  </tr>
	
  <tr>
    <th>Office Time Price <span class="required">*</span><span style="float: right;">$</span></th>
    <td><input name="officeTimePrice" type="text" class="form" id="officeTimePrice" size="6" maxlength="6" value="<?php echo_value ('officeTimePrice'); ?>"></td>
  </tr>
</table>
</form>