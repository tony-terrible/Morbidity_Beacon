<script>
function list_jobs () {
	$.ajax ({
		url: 'ajax/clients.jobs.list.php',
		type: 'get',
		dataType: 'json',
		data: { client_id: $('#client_id').val() },
		success: function (data) {
			$('#jobs_tbody').html(data.html);
			$('#num_jobs').html(data.total);
		}
	});
}
	
$(function() {
	
	list_jobs ();

});
</script>

<h2>Jobs</h2>
<table width="100%" border="0" cellspacing="1" cellpadding="4" id="table_list" style="margin-bottom: 10px;">
	<tr>
  	<th>Start Date</th>
    <th>Title</th>
    <th>Number</th>
		<th>Total Hours</th>
  </tr>
	<tbody id="jobs_tbody">
  <tr>
  	<td colspan="8">Loading...</td>
  </tr>
  </tbody>
</table>