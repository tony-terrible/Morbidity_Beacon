<div style="position: relative;">
<?php

$module = array();
$module['m']													= 'clients';
$module['directory'] 									= 'phplib/clients/';


$titles = array();
$titles[''] = '';
$titles['home'] = '';
$titles['add'] = '&raquo; Add';
$titles['view'] = '&raquo; View';

### Process "Add" form
if ($p == 'add' && isset ($_POST['Submit'])) {
	include ($module['directory'] . 'add.proc.php');
	
	if (empty ($errors)) {
		$p = 'view';
		$id = $_SESSION['add_client_id'];
	} else {
		$p = 'add';
	}
}

if ($p == 'view') {
	
	### Get Company Name For Title
	$sth = $dbh->prepare ('SELECT company FROM clients WHERE client_id = :client_id');
	$sth->bindParam (':client_id', $id);
	$sth->execute ();

	if ($sth->rowCount() && $row = $sth->fetch (PDO::FETCH_ASSOC)) {
		$titles['view'] = ' &raquo; ' . $row['company'];
	}
	

}

echo '<h1>Clients ' . $titles[$p] . '</h1>';

if ($a == 'del') {
	include ($module['directory'] . 'proc.php');
}

switch ($p) {
	case 'home': default: include ($module['directory'] . 'home.php');				break;
	case 'add':						include ($module['directory'] . 'add.php');					break;
	case 'view':					include ($module['directory'] . 'view.php');				break;
}

?>
</div>