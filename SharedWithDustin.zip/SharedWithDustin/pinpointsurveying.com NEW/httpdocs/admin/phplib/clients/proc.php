<?php



#########################################################################################################################################################
### Delete
#########################################################################################################################################################

$continue = true;

### First check to make sure no jobs or invoices exist for this contact

$sth = $dbh->prepare ("SELECT * FROM invoices WHERE client_id = :client_id LIMIT 1");
$sth->bindParam (':client_id', $id);
$sth->execute ();

if ($sth->rowCount()) {
	$continue = false;
}

$sth = $dbh->prepare ("SELECT * FROM jobs WHERE client_id = :client_id LIMIT 1");
$sth->bindParam (':client_id', $id);
$sth->execute ();

if ($sth->rowCount()) {
	$continue = false;
}

if ($continue) {
	
	$sth = $dbh->prepare ("DELETE FROM clients WHERE client_id = :client_id");
	$sth->bindParam (':client_id', $id);
	$sth->execute ();

	if ($sth->rowCount()) {
		echo '<div class="success">Client deleted successfully</div>' . "\n";		
		
	} else {
		echo '<div class="error">Error deleting client.</div>' . "\n";
	}


} else {
	echo '<div class="error"><strong>Error:</strong> Unable to delete this client because it has invoices and/or jobs associated to it.</div>' . "\n";
}

?>