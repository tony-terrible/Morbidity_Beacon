<?php
$_SESSION['add_client_id'] = '';


#######################################################################################################################################
### Retrieve/Store Job URL Information to maintain search and page throughout session.
#######################################################################################################################################
$jobs_opts = array();

if (isset ($_SESSION['jobs_opts'])) {
	$jobs_opts = $_SESSION['jobs_opts'];
}

if (isset ($_GET['Go'])) {
	$jobs_opts['page'] = '1';
	foreach ($_GET as $key => $val) {
		if ($key != 'm' && $key != 'p' && $key != 'Go' && $key != 'page' && $key != 'perpage' && !empty ($val)) {
			$jobs_opts[$key] = $val;
		}
	}
}

if (isset ($_GET['clear'])) { $jobs_opts = array(); }

if (isset ($_GET['page'])) { $jobs_opts['page'] = $_GET['page']; } 
if (isset ($_GET['perpage'])) { $jobs_opts['perpage'] = $_GET['perpage']; $jobs_opts['page'] = '1'; }
if (isset ($_GET['sortby'])) { $jobs_opts['sortby'] = $_GET['sortby']; } 
if (isset ($_GET['sortorder'])) { $jobs_opts['sortorder'] = $_GET['sortorder']; } 

if (!isset ($jobs_opts['page'])) { $jobs_opts['page'] = '1'; }
if (!isset ($jobs_opts['sortby'])) { $jobs_opts['sortby'] = 'job_number'; }
if (!isset ($jobs_opts['sortorder'])) { $jobs_opts['sortorder'] = 'DESC'; }
if (!isset ($jobs_opts['perpage'])) { $jobs_opts['perpage'] = '25'; }
if (!isset ($jobs_opts['status'])) { $jobs_opts['status'] = 'Active'; }

// store $contacts_opts for session
$_SESSION['jobs_opts'] = $jobs_opts;
#######################################################################################################################################
?>

<script>

function list_clients () {
	$.ajax ({
		url: 'ajax/clients.list.php',
		type: 'get',
		dataType: 'html',
		data: { search: $('#search').val() },
		success: function (data) {
			$('#clients_tbody').html(data);
		}
	});
}

$(function() {
	
	$("#search").keyup (function() {
		if ($('#search').val().length >= 2 || $('#search').val().length == 0) {
			list_clients();
		}
	});
	
	list_clients();
	
});
</script>

<style>
.loading {
	background-image: url(images/loading.gif);
	background-repeat: no-repeat;
	background-position: 0 0;
	padding: 0px 0px 4px 30px;
	margin: 10px;
}

</style>


<div class="submenu"><a href="index.php?m=clients&p=add" class="btn_add">Add Client</a></div>

<h2>Search</h2>
<table width="100%" border="0" cellspacing="1" cellpadding="4" id="table_search" style="margin-bottom: 10px;">
  <tr>
  	<td>Keyword: <input name="search" id="search" type="text" size="64" maxlength="64" class="form" value="<?php if (isset ($jobs_opts['job_number'])) { echo $jobs_opts['job_number']; } ?>" /></td>
	</tr>
</table>

<h2>Clients</h2>
<table width="100%" border="0" cellspacing="1" cellpadding="4" id="table_list">
  <tr>
    <th width="16">&nbsp;</th>
    <th>Company</th>
    <th>Contact</th>
    <th>Phone</th>
    <th width="16">&nbsp;</th>
  </tr>
	<tbody id="clients_tbody">
		<tr><td colspan="10" style="background: #efefef;"><div class="loading">Loading...</div></td></tr>
	</tbody>
</table>

