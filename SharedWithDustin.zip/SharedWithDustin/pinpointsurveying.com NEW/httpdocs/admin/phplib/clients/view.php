<script>
$(function() {
	$('#tabs').tabs();		
});

function save () {
	
	if ($('#response').is(':visible')) { $('#response').slideToggle('slow'); }
	
	$('#savestatus').attr('class', 'saving');
	$('#savestatus').html('Saving Client');	
	$('#savestatus').fadeIn('slow');
	
	var forms;
	forms = $('#general_form').serialize();

	$.ajax ({
		url: 'ajax/clients.save.php',
		data: forms,
		type: 'POST',
		success: function (data) {
			if (data.match (/error/i)) {
				$('#response').html(data).slideToggle('slow');
				$('#savestatus').fadeOut('slow');
			} else {
				$('#savestatus').attr('class', 'saved');
				$('#savestatus').html('Client Saved');	
				setTimeout ("$('#savestatus').fadeOut('slow')", 2500);
			}
		}
	});
}
</script>
<?php

$tabs = array (
	'General' => 'general',
	'Jobs (<span id="num_jobs">0</span>)' => 'jobs',
	'Invoices (<span id="num_invoices">0</span>)' => 'invoices',
	'Notes (<span id="num_notes">0</span>)' => 'notes'
);

if (isset ($_GET['id']) && !empty ($_GET['id'])) {
	$client_id = $_GET['id'];
} elseif (isset ($_SESSION['add_client_id']) && !empty ($_SESSION['add_client_id'])) {
	$client_id = $_SESSION['add_client_id'];
} else  {
	echo '<div class="error">Error, no client_id was found.</div>';
	exit();
}

if (isset ($client_id) && !empty ($client_id)) {
	
	$sth = $dbh->prepare ('SELECT * FROM clients WHERE client_id = :client_id');
	$sth->bindParam (':client_id', $client_id);
	$sth->execute ();
	
	if ($sth->rowCount() && $row = $sth->fetch (PDO::FETCH_ASSOC)) {
	
		###################################################################################################################
		### Client ID Passed & Valid - Show Tabs
		###################################################################################################################
		
		echo '<div class="submenu"><span id="savestatus" class="saving" style="display: none;"></span><a href="javascript:save()" class="btn_save">Save</a></div>' . "\n";
		
		echo '<div id="response" style="display: none;"></div>' . "\n";
		
		echo '<div id="tabs">' . "\n";
		
		echo '  <ul>' . "\n";
		foreach ($tabs as $name => $include) {
			echo '<li><a href="#tab-' . $include . '">' . $name . '</a></li>' . "\n";
		}    
		echo '  </ul>' . "\n";
		
		foreach ($tabs as $name => $include) {
			echo '<div id="tab-' . $include . '">' . "\n";
			include ('phplib/clients/tabs/' . $include . '.php');
			echo '</div>' . "\n";
		
		}
		
		echo '</div>';
		###################################################################################################################

	} else {
		echo '<div class="error">Error: Invalid Client ID Passed!</div>';
	}
} else {
	echo '<div class="error">Error: No Client ID Passed!</div>';
}
?>