$(document).ready(function() {
	if (document.getElementById('table_list')) {
		$("#table_list > tbody > tr:even").css("background-color", "#efefef");
		$("#table_list > tbody > tr:odd").css("background-color", "#f7f7f7");	
	}
});