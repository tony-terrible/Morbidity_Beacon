<?php
require ('_include.php');

$return = array ();
$return['total'] = 0;
$return['html'] = '';

if (is_logged_in () && isset ($_GET['job_id'])) {
	
	$job_id = $_GET['job_id'];
	
	$sql = 'SELECT 			c.cid,
											c.company_name,
											c.first_name,
											c.last_name,
											ct.type 
					FROM 				job_contacts jc 
					LEFT JOIN 	contacts c 				ON jc.contact_id 	= c.cid 
					LEFT JOIN 	contact_types ct	ON jc.type_id 		= ct.type_id 
					WHERE 			jc.job_id = :job_id';
	
	$sth = $dbh->prepare ($sql);
	$sth->bindParam (':job_id', $job_id);
	$sth->execute ();
	
	if ($sth->rowCount()) {
		$return['total'] = $sth->rowCount();
		while ($row = $sth->fetch (PDO::FETCH_ASSOC)) {
			
			$contact = format_contact ($row);			
			
			$return['html'] .= '<tr>' . "\n";
			$return['html'] .= '	<td>' . $contact . '</td>' . "\n";
			$return['html'] .= '	<td>' . $row['type'] . '</td>' . "\n";
			$return['html'] .= '	<td><a href="javascript:del_contact(\'' . $row['cid'] . '\')"><img src="images/icons/delete.png" width="16" height="16" border="0" alt="Delete"></a></td>' . "\n";
			$return['html'] .= '</tr>' . "\n";
			
		}
	} else {
		$return['html'] .= '<tr>' . "\n";
		$return['html'] .= '	<td colspan="12">No Contacts Found</td>' . "\n";
		$return['html'] .= '</tr>' . "\n";
	}
	
} else {
	$return['html'] .= '<tr>' . "\n";
	$return['html'] .= '	<td colspan="12">An error has occurred</td>' . "\n";
	$return['html'] .= '</tr>' . "\n";
	
}

echo json_encode ($return);


?>