<?php
require ('_include.php');

if (is_logged_in ()) {
	
	$db = array();
	$db['client_id'] 		= $_POST['client_id'];
	$db['note'] 				= $_POST['note'];
	
	if (!empty ($_POST['note_id'])) {
		
		if (!db ('update', 'client_notes', $db, 'id', $_POST['note_id'])) {
			echo 'Error!';
		}		
		
	} else {

		$db['added_by'] 		= $_SESSION['login']['user_name'];
		$db['added_dt'] 		= 'NOW()';
	
		if (!db ('insert', 'client_notes', $db)) {
			echo 'Error!';
		}
		
	}
	
}
?>