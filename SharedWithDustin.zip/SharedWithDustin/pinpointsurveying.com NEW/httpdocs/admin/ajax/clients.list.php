<?php
require ('_include.php');

if (is_logged_in ()) {
	
	
	
  try {
		
		$sql = 'SELECT client_id, company, contact, phone1 FROM clients ';

		if (isset ($_GET['search'])) {
			$sql .= 'WHERE company LIKE :keyword || contact LIKE :keyword2 ';
		}
		
		$sql .= 'ORDER BY company ASC';
		
    $sth = $dbh->prepare ($sql);
		
		if (isset ($_GET['search'])) {
			$keyword = '%' . $_GET['search'] . '%';
			$sth->bindParam (':keyword', $keyword);
			$sth->bindParam (':keyword2', $keyword);
		}
		
    $sth->execute ();
  
    if ($sth->rowCount()) {	
      while ($row = $sth->fetch (PDO::FETCH_ASSOC)) {
				
        echo '<tr>' . "\n";
        echo '	<td width="16"><a href="index.php?m=clients&p=view&id=' . $row['client_id'] . '"><img src="images/icons/edit.png" border="0" alt="Edit" title="Edit Job"></a></td>' . "\n";
        echo '	<td>' . $row['company'] . '</td>' . "\n";
				echo '	<td>' . $row['contact'] . '</td>' . "\n";
				echo '	<td>' . $row['phone1'] . '</td>' . "\n";
        echo '	<td width="16"><a href="javascript:del(\'Are you sure you wish to delete this entry?\', \'index.php?m=clients&p=home&a=del&id=' . $row['client_id'] . '\')"><img src="images/icons/delete.png" border="0" alt="Delete" title="Delete Job"></a></td>' . "\n";
        echo '</tr>' . "\n";
        
      }
    } else {
      echo '<tr>' . "\n";
      echo '	<td colspan="12"><b>No clients found</b></td>' . "\n";
      echo '</tr>' . "\n";
    }
		
  } catch (PDOException $e) {
    echo '<div class="error">' . $e->getMessage() . '</div>';
  }     

	
	
	
	
}
?>