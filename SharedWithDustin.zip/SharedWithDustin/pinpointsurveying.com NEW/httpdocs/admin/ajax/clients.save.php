<?php
require ('_include.php');

if (is_logged_in ()) {
	
	$errors = array ();
	

	if (isset ($_POST['client_id']) && !empty ($_POST['client_id']) && is_numeric ($_POST['client_id'])) {
		
		$client_id = $_POST['client_id'];
		
		
		$fields = array (
			'company' 					=> array ('rules' => 'required|max_len,255|min_len,6', 	'filters' => 'trim|sanitize_string',					'readable' => 'Company'),
			'contact' 					=> array ('rules' => '', 																'filters' => 'trim|sanitize_string',					'readable' => 'Contact'),
			'email' 						=> array ('rules' => 'valid_email', 										'filters' => 'lower_case|sanitize_email',			'readable' => 'Email'),
			'address1' 					=> array ('rules' => '', 																'filters' => '',															'readable' => 'Address 1'),
			'address2' 					=> array ('rules' => '', 																'filters' => '',															'readable' => 'Address 2'),
			'city' 							=> array ('rules' => '',																'filters' => '',															'readable' => 'City'),			
			'province_state' 		=> array ('rules' => '',																'filters' => '',															'readable' => 'Province/State'),		
			'postal_zip'				=> array ('rules' => '',																'filters' => '',															'readable' => 'Postal/Zip Code'),
			'country'						=> array ('rules' => '',																'filters' => '',															'readable' => 'Country'),			
			'phone1' 						=> array ('rules' => 'phone_number',										'filters' => '',															'readable' => 'Phone 1'),
			'phone2' 						=> array ('rules' => 'phone_number',										'filters' => '',															'readable' => 'Phone 2'),
			'fax' 							=> array ('rules' => 'phone_number',										'filters' => '',															'readable' => 'Fax'),			
			'fieldTimePrice' 		=> array ('rules' => 'required|numeric',								'filters' => '',															'readable' => 'Field Time Price'),			
			'fieldgpsTimePrice' => array ('rules' => 'required|numeric',								'filters' => '',															'readable' => 'Field GPS Time Price'),			
			'travelTimePrice' 	=> array ('rules' => 'required|numeric',								'filters' => '',															'readable' => 'Travel Time Price'),			
			'officeTimePrice' 	=> array ('rules' => 'required|numeric',								'filters' => '',															'readable' => 'Office Time Price')
		);
		
		
		



		$gump = new GUMP();
		$_POST = $gump->sanitize ($_POST);
		
		$_rules = array();
		$_filters = array();
		foreach ($fields as $field => $i) {
			
			if (isset ($i['rules']) && !empty ($i['rules'])) {
				$_rules[$field] = $i['rules'];
			}
			
			if (isset ($i['filters']) && !empty ($i['filters'])) {
				$_filters[$field] = $i['filters'];
			}			
			
			if (isset ($i['readable']) && !empty ($i['readable'])) {
				$gump->set_field_name ($field, $i['readable']);
			}
		}

		$gump->validation_rules ($_rules);
		$gump->filter_rules ($_filters);
			
		$validated_data = $gump->run($_POST);

		if ($validated_data === false) {
			$errors = $gump->get_errors_array();
		} else {

			$db = array ();
			foreach ($fields as $field => $x) {
				$db[$field] = $validated_data[$field];
			}

			if (!db ('update', 'clients', $db, 'client_id', $client_id)) {
				$errors['general'] = 'An error has occurred updating the database, please try again.  If this continues to happen contact an administrator.';
			}

		}
		
		
		###################################################################################################################################################################################
		### Display errors, if any
		###################################################################################################################################################################################
		
		if (isset ($errors) && !empty ($errors)) {
			echo '<div class="error"><strong>Uh Oh!</strong> There appears to be a problem or two.<ul>';
			foreach ($errors as $error) {
				echo '<li>' . $error . '</li>';
			}
			echo '</ul></div>';		
		}


	} else {
		echo '<div class="error">No Client ID Passed<br>(Line ' . __LINE__ . ' in ' . __FILE__ .')</div>';
	}
}
?>