<?php
require ('_include.php');

$return = array ();
$return['total'] = 0;
$return['html'] = '';

if (is_logged_in () && isset ($_GET['job_id'])) {
	
	$job_id = $_GET['job_id'];
	
	$sql = 'SELECT 			jrj.related_job_id, j.job_number
					FROM 				job_related_jobs jrj 
					LEFT JOIN 	jobs j ON jrj.related_job_id = j.job_id
					WHERE 			jrj.job_id = :job_id';
	
	$sth = $dbh->prepare ($sql);
	$sth->bindParam (':job_id', $job_id);
	$sth->execute ();
	
	if ($sth->rowCount()) {
		$return['total'] = $sth->rowCount();
		while ($row = $sth->fetch (PDO::FETCH_ASSOC)) {
						
			$return['html'] .= '<tr>' . "\n";
			$return['html'] .= '	<td><a href="index.php?m=jobs&p=view&id=' . $row['related_job_id'] . '">' . $row['job_number'] . '</a></td>' . "\n";
			$return['html'] .= '	<td width="16"><a href="javascript:del_related_job(\'' . $row['related_job_id'] . '\')"><img src="images/icons/delete.png" width="16" height="16" border="0" alt="Delete"></a></td>' . "\n";
			$return['html'] .= '</tr>' . "\n";
			
		}
	} else {
		$return['html'] .= '<tr>' . "\n";
		$return['html'] .= '	<td colspan="12">No Related Jobs Found</td>' . "\n";
		$return['html'] .= '</tr>' . "\n";
	}
	
} else {
	$return['html'] .= '<tr>' . "\n";
	$return['html'] .= '	<td colspan="12">An error has occurred</td>' . "\n";
	$return['html'] .= '</tr>' . "\n";
	
}

echo json_encode ($return);


?>