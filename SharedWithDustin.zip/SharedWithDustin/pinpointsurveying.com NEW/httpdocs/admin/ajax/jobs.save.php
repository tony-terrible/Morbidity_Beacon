<?php
require ('_include.php');

if (is_logged_in ()) {
	
	//echo '<div class="error">'; print_r ($_POST); echo '</div>';
	
	if (isset ($_POST['job_id']) && !empty ($_POST['job_id'])) {
		
		$job_id = $_POST['job_id'];
		
		$error = array();
		
		####################################################################################################################################################################################
		### General Form
		####################################################################################################################################################################################
		
		$fields = array ( 'primary_cid' => 'Primary Contact', 
											'job_number' => 'Job Number', 
											'job_number_ext' => 'Job Number Extension',
											'employee_id' => 'Employee/Manager', 
											'description' => 'Description', 
											'date_opened' => 'Date Opened');			 
		$req_fields = array ('job_number', 'primary_cid');
		
		### Check that the required fields have values using the above arrays, custom fields go below.
		foreach ($fields as $field => $x) {
			if (array_key_exists ($field, $req_fields)) {
				if (isset ($_POST[$field]) && !empty ($_POST[$field])) {
					$db[$field] = $_POST[$field];
				} else {
					$error[$field] = '<strong>' . $fields[$field] . '</strong>: This is a required field.';
				}
			} else {
				$db[$field] = $_POST[$field];
			}
		}
		
		if (empty ($error)) {
			
			$db['date_last_updated'] = 'NOW()';
		
			### Update cabin record 
			if (db ('update', 'jobs', $db, 'job_id', $job_id)) {
				
				### Types
				// Remove existing job_types first
				$sth = $dbh->prepare ('DELETE FROM `job_types_join` WHERE `job_id` = :job_id');
				$sth->bindParam (':job_id', $job_id);
				$sth->execute ();

				if (isset ($_POST['job_types']) && !empty ($_POST['job_types'])) {
					foreach ($_POST['job_types'] as $type_id => $x) {
									
						$db = array();
						$db['job_id'] = $job_id;
						$db['type_id'] = $type_id;
						
						if (!db ('insert', 'job_types_join', $db)) {
							echo '<div class="error">' . mysql_error() . '</div>';
						}
				
					}
				}
	
			} else {
				echo '<div class="error">' . mysql_error () . '</div>';
			}
		
		} else {
			
			echo '<div class="error"><strong>Error</strong><br>';
			foreach ($error as $field => $msg) {
				echo $msg . '<br>';
			}
			echo '</div>';
			
		}

	} else {
		echo '<div class="error">No Job ID Passed<br>(Line ' . __LINE__ . ' in ' . __FILE__ .')</div>';
	}
}
?>