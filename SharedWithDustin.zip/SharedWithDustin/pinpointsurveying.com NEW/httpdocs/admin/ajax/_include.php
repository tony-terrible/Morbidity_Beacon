<?php
session_start ();

require ('../includes/db.php');
require ('../includes/functions.php');
require ('../includes/gump.class.php');
?>