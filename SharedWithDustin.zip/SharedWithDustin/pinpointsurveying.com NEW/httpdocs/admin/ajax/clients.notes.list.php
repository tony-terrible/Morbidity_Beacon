<?php
require ('_include.php');

if (is_logged_in () && isset ($_GET['client_id'])) {
	
	$return = array ();
	$return['total'] = 0;
	$return['html'] = '';
	
	$sth = $dbh->prepare ('SELECT * FROM client_notes WHERE client_id = :client_id');
	$sth->bindParam (':client_id', $_GET['client_id']);
	$sth->execute ();
	
	if ($sth->rowCount()) {
		$return['total'] = $sth->rowCount();
		while ($row = $sth->fetch (PDO::FETCH_ASSOC)) {
			
			$return['html'] .= '<tr>' . "\n";			
			$return['html'] .= '	<td width="16"><a href="javascript:edit_note(\'' . $row['id'] . '\',\'' . $row['note'] . '\')"><img src="images/icons/edit.png" border="0" alt="Edit"></a></td>' . "\n";
			$return['html'] .= '	<td width="240">' . $row['added_dt'] . ' by ' . $row['added_by'] . '</td>' . "\n";
			$return['html'] .= '	<td>' . $row['note'] . '</td>' . "\n";
			$return['html'] .= '	<td width="16"><a href="javascript:del_note(\'' . $row['id'] . '\')"><img src="images/icons/delete.png" width="16" height="16" border="0" alt="Delete"></td>' . "\n";
			$return['html'] .= '</tr>' . "\n";
			
		}
	} else {
		$return['html'] .= '<tr>' . "\n";
		$return['html'] .= '	<td colspan="12">No Notes Found</td>' . "\n";
		$return['html'] .= '</tr>' . "\n";
	}
	
}

echo json_encode ($return);


?>