<?php
require ('_include.php');

if (is_logged_in () && isset ($_GET['job_id'])) {
	
	$return = array ();
	$return['total'] = 0;
	$return['html'] = '';
	
	$job_id = $_GET['job_id'];
	
	$sth = $dbh->prepare ('SELECT * FROM job_plans_created WHERE job_id = :job_id');
	$sth->bindParam (':job_id', $job_id);
	$sth->execute ();
	
	if ($sth->rowCount()) {
		$return['total'] = $sth->rowCount();
		while ($row = $sth->fetch (PDO::FETCH_ASSOC)) {
					
			$return['html'] .= '<tr>' . "\n";			
			$return['html'] .= '	<td width="16"><a href="javascript:edit_plan_created(\'' . $row['id'] . '\',\'' . $row['plan_type'] . '\',\'' . $row['plan_number'] . '\',\'' . $row['note'] . '\')"><img src="images/icons/edit.png" border="0" alt="Edit"></a></td>' . "\n";
			$return['html'] .= '	<td>' . $row['plan_type'] . ' ' . $row['plan_number'] . '</td>' . "\n";
			$return['html'] .= '	<td>' . $row['note'] . '</td>' . "\n";
			$return['html'] .= '	<td width="16"><a href="javascript:del_plan_created(\'' . $row['id'] . '\')"><img src="images/icons/delete.png" width="16" height="16" border="0" alt="Delete"></td>' . "\n";
			$return['html'] .= '</tr>' . "\n";
			
		}
	} else {
		$return['html'] .= '<tr>' . "\n";
		$return['html'] .= '	<td colspan="12">No Notes Found</td>' . "\n";
		$return['html'] .= '</tr>' . "\n";
	}
	
}

echo json_encode ($return);


?>