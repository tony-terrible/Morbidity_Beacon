<?php
require ('_include.php');

if (is_logged_in () && isset ($_GET['id']) && isset ($_GET['job_id'])) {
	
	$sth = $dbh->prepare ('DELETE FROM job_civic_addresses WHERE job_id = :job_id && id = :id');
	$sth->bindParam ('job_id', $_GET['job_id']);
	$sth->bindParam ('id', $_GET['id']);
	$sth->execute ();

}
?>