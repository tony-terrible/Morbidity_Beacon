<?php
require ('_include.php');

if (is_logged_in ()) {
	
	$db = array();
	$db['job_id'] 						= $_POST['job_id'];
	$db['lot_number'] 				= $_POST['lot_number'];
	$db['block'] 							= $_POST['block'];
	$db['plan_number_type']		= $_POST['plan_number_type'];
	$db['plan_number'] 				= $_POST['plan_number'];
	$db['plan_on_file'] 			= $_POST['plan_on_file'];
	$db['plan_on_file_desc'] 	= $_POST['plan_on_file_desc'];
	$db['pid'] 								= $_POST['pid'];
	
	if (!empty ($_POST['jld_id'])) {
		
		if (!db ('update', 'job_legal_descriptions', $db, 'id', $_POST['jld_id'])) {
			echo 'Error!';
		}		
		
	} else {
	
		if (!db ('insert', 'job_legal_descriptions', $db)) {
			echo 'Error!';
		}
		
	}
	
}
?>