<?php
require ('_include.php');

if (is_logged_in () && isset ($_GET['id']) && isset ($_GET['client_id'])) {
	
	$sth = $dbh->prepare ('DELETE FROM client_notes WHERE client_id = :client_id && id = :id');
	$sth->bindParam ('client_id', $_GET['client_id']);
	$sth->bindParam ('id', $_GET['id']);
	$sth->execute ();

}
?>