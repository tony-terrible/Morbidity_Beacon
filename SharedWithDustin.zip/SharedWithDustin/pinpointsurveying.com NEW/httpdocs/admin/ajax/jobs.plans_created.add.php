<?php
require ('_include.php');

if (is_logged_in ()) {
	
	$db = array();
	$db['job_id'] 						= $_POST['job_id'];
	$db['plan_type']					= $_POST['plan_type'];
	$db['plan_number'] 				= $_POST['plan_number'];
	$db['note'] 							= $_POST['note'];
	
	if (!empty ($_POST['jpc_id'])) {
		
		if (!db ('update', 'job_plans_created', $db, 'id', $_POST['jpc_id'])) {
			echo 'Error!';
		}		
		
	} else {
	
		if (!db ('insert', 'job_plans_created', $db)) {
			echo 'Error!';
		}
		
	}
	
}
?>