<?php
require ('_include.php');

if (is_logged_in () && isset ($_GET['client_id'])) {
	
	$return = array ();
	$return['total'] = 0;
	$return['html'] = '';
	
	$sth = $dbh->prepare ('SELECT * FROM invoices WHERE client_id = :client_id ORDER BY invoiceNum DESC');
	$sth->bindParam (':client_id', $_GET['client_id']);
	$sth->execute ();
	
	if ($sth->rowCount()) {
		$return['total'] = $sth->rowCount();
		while ($row = $sth->fetch (PDO::FETCH_ASSOC)) {
			
			$return['html'] .= '<tr>' . "\n";			
			$return['html'] .= '	<td>' . $row['invoice_date'] . '</td>' . "\n";
			$return['html'] .= '	<td>' . $row['invoiceNum'] . '</td>' . "\n";
			$return['html'] .= '	<td>' . $row['job_id'] . '</td>' . "\n";
			$return['html'] .= '	<td style="text-align: right;">$' . number_format ($row['totalBill'], 2, '.', ',') . '</td>' . "\n";
			$return['html'] .= '</tr>' . "\n";

		}
	} else {
		$return['html'] .= '<tr>' . "\n";
		$return['html'] .= '	<td colspan="12">No Invoices Found</td>' . "\n";
		$return['html'] .= '</tr>' . "\n";
	}
	
}

echo json_encode ($return);

?>