<?php
require ('_include.php');

if (is_logged_in ()) {
	
	$db = array();
	$db['job_id'] 				= $_POST['job_id'];
	$db['unit'] 					= $_POST['unit'];
	$db['street_number'] 	= $_POST['street_number'];
	$db['street_name'] 		= $_POST['street_name'];
	$db['type'] 					= $_POST['type'];
	$db['direction'] 			= $_POST['direction'];
	$db['city'] 					= $_POST['city'];
	$db['province'] 			= $_POST['province'];
	
	$address = format_civic_address ($db);
	
	if ($geocode = geocode ($address)) {
		$db['latitude'] = $geocode[0];
		$db['longitude'] = $geocode[1];
	} else {
		$db['geocode_attempts'] = '1';
	}
	
	if (!empty ($_POST['jca_id'])) {
		if (!db ('update', 'job_civic_addresses', $db, 'id', $_POST['jca_id'])) {
			echo 'Error!';
		}		
	} else {
		if (!db ('insert', 'job_civic_addresses', $db)) {
			echo 'Error!';
		}
	}
}
?>