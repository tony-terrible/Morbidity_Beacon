<?php
require ('_include.php');

if (is_logged_in ()) {
	
	$fields = array ('job_id' => 'Job ID', 'related_job_id' => 'Related Job ID');
	$errors = array ();
	$db = array ();
	
	foreach ($fields as $field => $field_name) {
		if (isset ($_POST[$field]) && !empty ($_POST[$field])) {
			$db[$field] = $_POST[$field];
		} else {
			$errors[] = $field_name . ': This is a required field.';
		}
	}
	
	if (empty ($errors)) {
		if (!db ('insert', 'job_related_jobs', $db)) {
			echo 'Error!';
		}
	} else {
		echo 'Error:' . "\n";
		foreach ($errors as $error) {
			echo ' - ' . $error . "\n";
		}
	}

}
?>