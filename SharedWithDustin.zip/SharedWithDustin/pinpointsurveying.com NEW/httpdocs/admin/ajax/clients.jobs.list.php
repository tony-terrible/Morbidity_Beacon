<?php
require ('_include.php');

if (is_logged_in () && isset ($_GET['client_id'])) {
	
	$return = array ();
	$return['total'] = 0;
	$return['html'] = '';
	
	$sql = 'SELECT 			j.startDate,
											j.title,
											j.number,
											SUM(tr.totalTime) AS totaltime
					FROM 				jobs j
					LEFT JOIN		timerecords tr ON j.job_id = tr.job_id
					WHERE 			j.client_id = :client_id 
					GROUP BY		j.job_id
					ORDER BY 		j.startDate DESC';
	
	$sth = $dbh->prepare ($sql);
	$sth->bindParam (':client_id', $_GET['client_id']);
	$sth->execute ();
	
	if ($sth->rowCount()) {
		$return['total'] = $sth->rowCount();
		while ($row = $sth->fetch (PDO::FETCH_ASSOC)) {
			
			$return['html'] .= '<tr>' . "\n";			
			$return['html'] .= '	<td>' . $row['startDate'] . '</td>' . "\n";
			$return['html'] .= '	<td>' . $row['title'] . '</td>' . "\n";
			$return['html'] .= '	<td>' . $row['number'] . '</td>' . "\n";
			$return['html'] .= '	<td>' . $row['totaltime'] . '</td>' . "\n";
			$return['html'] .= '</tr>' . "\n";

		}
	} else {
		$return['html'] .= '<tr>' . "\n";
		$return['html'] .= '	<td colspan="12">No Jobs Found</td>' . "\n";
		$return['html'] .= '</tr>' . "\n";
	}
	
}

echo json_encode ($return);

?>