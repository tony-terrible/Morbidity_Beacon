<?php
require ('_include.php');

if (is_logged_in () && isset ($_GET['timesheet_id'])) {
	
	$user_types = array ("0" => "Crewchief", "1" => "Rodman");

	$sql = 'SELECT		tr.*,
										d.description,
										CONCAT_WS (" ", u.first_name,	u.last_name) as username,
										j.number AS job_number,
										i.invoiceNum AS invoice_number
					FROM 			timerecords tr
					LEFT JOIN descriptions d 	ON tr.description_id 	= d.description_id
					LEFT JOIN users u 				ON tr.user_id 				= u.user_id
					LEFT JOIN jobs j 					ON tr.job_id 					= j.job_id
					LEFT JOIN invoices i 			ON tr.invoice_id 			= i.invoice_id
					WHERE 		tr.timesheet_id = :timesheet_id
					ORDER BY 	tr.timerecord_date, timeIn ASC';
	
	$sth = $dbh->prepare ($sql);
	$sth->bindParam (':timesheet_id', $_GET['timesheet_id']);
	$sth->execute();
	
	if ($sth->rowCount()) {
		while ($row = $sth->fetch (PDO::FETCH_ASSOC)) {

			$user_type = $user_types[$row['userType']];

			echo '<tr>';
			echo '	<td>' . $row['job_number'] . '</td>';
			echo '	<td>' . $row['type'] . '</td>';
			echo '	<td align="center">' . $row['timeIn'] . ' - ' . $row['timeOut'] . '</td>';
			echo '	<td align="center">' . $row['totalTime'] . '</td>';
			echo '	<td>' . $row['description'] . ' ' . $row['extDescription'] . '</td>';
			echo '	<td>' . $row['username'] . ' (' . $user_type . ')</td>';
			echo '</tr>';
		}
		
		
		//echo "<tr class=\"tableheader\"><td colspan=\"7\">";
		//echo "<input name=\"complete\" type=\"checkbox\" id=\"complete\" value=\"yes\" class=\"form\"> Complete";
		//echo "</td></tr>";
	} else {
		echo '<tr>';
		echo '<td colspan="11">No time records</td>';
		echo '</tr>';
	}

	
	
	
}

?>