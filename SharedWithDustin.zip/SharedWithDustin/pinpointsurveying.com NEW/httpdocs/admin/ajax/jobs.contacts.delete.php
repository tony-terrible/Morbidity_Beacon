<?php
require ('_include.php');

if (is_logged_in () && isset ($_GET['contact_id']) && isset ($_GET['job_id'])) {
	
	$sth = $dbh->prepare ('DELETE FROM job_contacts WHERE job_id = :job_id && contact_id = :contact_id');
	$sth->bindParam ('job_id', $_GET['job_id']);
	$sth->bindParam ('contact_id', $_GET['contact_id']);
	$sth->execute ();

}
?>