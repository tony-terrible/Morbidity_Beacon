<?php
require ('_include.php');

if (is_logged_in () && isset ($_GET['job_id'])) {
	
	$return = array ();
	$return['total'] = 0;
	$return['html'] = '';
	
	$job_id = $_GET['job_id'];
	
	$sth = $dbh->prepare ('SELECT * FROM job_civic_addresses WHERE job_id = :job_id');
	$sth->bindParam (':job_id', $job_id);
	$sth->execute ();
	
	if ($sth->rowCount()) {
		$return['total'] = $sth->rowCount();
		while ($row = $sth->fetch (PDO::FETCH_ASSOC)) {
			
			$return['html'] .= '<tr>' . "\n";
			$return['html'] .= '	<td width="16"><a href="javascript:edit_civic_address(\'' . $row['id'] . '\',\'' . $row['unit'] . '\',\'' . $row['street_number'] . '\',\'' . addslashes ($row['street_name']) . '\',\'' . $row['type'] . '\',\'' . $row['direction'] . '\',\'' . $row['city'] . '\',\'' . $row['province'] . '\',\'' . $row['latitude'] . '\',\'' . $row['longitude'] . '\')"><img src="images/icons/edit.png" border="0" alt="Edit"></a></td>' . "\n";
			$return['html'] .= '	<td>' . $row['unit'] . '</td>' . "\n";
			$return['html'] .= '	<td>' . $row['street_number'] . '</td>' . "\n";
			$return['html'] .= '	<td>' . $row['street_name'] . '</td>' . "\n";
			$return['html'] .= '	<td>' . $row['type'] . '</td>' . "\n";
			$return['html'] .= '	<td>' . $row['direction'] . '</td>' . "\n";
			$return['html'] .= '	<td>' . $row['city'] . '</td>' . "\n";
			$return['html'] .= '	<td>' . $row['province'] . '</td>' . "\n";
			$return['html'] .= '	<td>' . $row['latitude'] . '</td>' . "\n";
			$return['html'] .= '	<td>' . $row['longitude'] . '</td>' . "\n";			
			$return['html'] .= '	<td><a href="javascript:del_civic_address(\'' . $row['id'] . '\')"><img src="images/icons/delete.png" width="16" height="16" border="0" alt="Delete"></a></td>' . "\n";
			$return['html'] .= '</tr>' . "\n";
			
		}
	} else {
		$return['html'] .= '<tr>' . "\n";
		$return['html'] .= '	<td colspan="12">No Civic Addresses Found</td>' . "\n";
		$return['html'] .= '</tr>' . "\n";
	}
	
}

echo json_encode ($return);


?>