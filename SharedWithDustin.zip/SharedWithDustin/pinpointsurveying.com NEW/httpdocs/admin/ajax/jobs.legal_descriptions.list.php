<?php
require ('_include.php');

if (is_logged_in () && isset ($_GET['job_id'])) {
	
	$return = array ();
	$return['total'] = 0;
	$return['html'] = '';
	
	$job_id = $_GET['job_id'];
	
	$sth = $dbh->prepare ('SELECT * FROM job_legal_descriptions WHERE job_id = :job_id');
	$sth->bindParam (':job_id', $job_id);
	$sth->execute ();
	
	if ($sth->rowCount()) {
		$return['total'] = $sth->rowCount();
		while ($row = $sth->fetch (PDO::FETCH_ASSOC)) {
			
			if (!empty ($row['plan_on_file_desc'])) {
				$plan_on_file = $row['plan_on_file'] . ' (' . $row['plan_on_file_desc'] . ')';
			} else {
				$plan_on_file = $row['plan_on_file'];
			}
			
			$return['html'] .= '<tr>' . "\n";			
			$return['html'] .= '	<td width="16"><a href="javascript:edit_legal_description(\'' . $row['id'] . '\',\'' . $row['lot_number'] . '\',\'' . $row['block'] . '\',\'' . $row['plan_number_type'] . '\',\'' . $row['plan_number'] . '\',\'' . $row['plan_on_file'] . '\',\'' . $row['plan_on_file_desc'] . '\',\'' . $row['pid'] . '\')"><img src="images/icons/edit.png" border="0" alt="Edit"></a></td>' . "\n";
			$return['html'] .= '	<td>' . $row['lot_number'] . '</td>' . "\n";
			$return['html'] .= '	<td>' . $row['block'] . '</td>' . "\n";
			$return['html'] .= '	<td>' . $row['plan_number_type'] . ' ' . $row['plan_number'] . '</td>' . "\n";
			$return['html'] .= '	<td>' . $plan_on_file . '</td>' . "\n";
			$return['html'] .= '	<td>' . $row['pid'] . '</td>' . "\n";
			$return['html'] .= '	<td width="16"><a href="javascript:del_legal_description(\'' . $row['id'] . '\')"><img src="images/icons/delete.png" width="16" height="16" border="0" alt="Delete"></td>' . "\n";
			$return['html'] .= '</tr>' . "\n";
			
		}
	} else {
		$return['html'] .= '<tr>' . "\n";
		$return['html'] .= '	<td colspan="12">No Legal Descriptions Found</td>' . "\n";
		$return['html'] .= '</tr>' . "\n";
	}
	
}

echo json_encode ($return);


?>