<?php

//use PHPMailer\PHPMailer\PHPMailer;
//require 'vendor/autoload.php';


######################################################################
function microtime_float() {
	list($usec, $sec) = explode(" ", microtime());
	return ((float)$usec + (float)$sec);
}

$page_start_time = microtime_float();
######################################################################

session_start();
set_include_path (get_include_path() . PATH_SEPARATOR . 'includes/' . PATH_SEPARATOR . 'includes/PEAR' . PATH_SEPARATOR . 'includes/PHPMailer');


require ('config.php');
require ('db.php');
require ('functions.php');

if (is_banned ('', $_SERVER['REMOTE_ADDR'])) {
	die ('Your IP address has been banned from this site.  Sorry.');
}

if (is_logged_in () && is_banned ($_SESSION['login']['email_address'], '')) {
	die ('Your email address has been banned from this site.  Sorry.');
}



require ('validate.php');
require ('functions.email.php');
require ('functions.shared.php');
require ('class.pagination.php');
require ('class.password_hash.php');
require ('class.parsecsv.php');
require ('class.simpleimage.php');
require ('gump.class.php');


// PEAR
require ('PEAR5.php');
require ('Mail.php');
require ('Mail/mime.php');
require ('Validate.php');
require ('Validate/CA.php');

### Process Login
if (isset ($_POST['login'])) { $login_error = login ($_POST['email_address'], $_POST['password']); }

### Process Password Reset
if (isset ($_POST['reset'])) { $reset_password_error = reset_password ($_POST['email_address']); }

### Process Logout
if (isset ($_GET['logout'])) { logout (); }

if (is_logged_in ()) {

	################################################################################################
	### User is Logged In
	################################################################################################
	require ('_header.php');
	require ('content.php'); 	// manage all installed modules here
	require ('_footer.php');	

} else {
	
	################################################################################################
	### NOT Logged In
	################################################################################################
	if (isset ($_GET['reset'])) {
		require ('phplib/reset.php');	
	} else {
		require ('phplib/login.php');	
	}
	
}

### Close Database Connection
$dbh = null;

/*
echo '<pre>';
echo '<strong>DEBUG INFO</strong> (bottom of index.php)<br>';
print_r ($_SESSION);
//echo session_id();
echo '</pre>';
*/

?>