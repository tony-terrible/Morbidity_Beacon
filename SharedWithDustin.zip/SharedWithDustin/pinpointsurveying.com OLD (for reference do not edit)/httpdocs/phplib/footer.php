<script language="JavaScript" type="text/JavaScript">
<!--

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
//-->
</script>

<table width="660" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr valign="top">
    <td align="center" class="footer"><a href="index.php">Profile</a> <span class="footerDividers">|</span> <a href="team_equipment.php">Team &amp; Equipment </a><span class="footerDividers"> | </span><a href="contact.php">Contact</a><span class="footerDividers"> | </span>Copyright &copy; 2005-2007 Pin Point Surveying Ltd.</td>
  </tr>
</table>
