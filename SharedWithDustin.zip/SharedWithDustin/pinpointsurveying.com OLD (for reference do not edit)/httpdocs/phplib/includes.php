<?php
include ("admin/includes/db.php");
include ("admin/includes/functions.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>

<title>Pin Point Surveying</title>

<meta name="description" content="Pinpoint Surveying is a professional, knowledgeable and efficient surveying team. We specialize in construction layout for road works and underground layout of any size.">
<meta name="keywords" content="shuswap, legal surveying, survey, GPS survey, shuswap survey, topographical site information, subdivision, mineral tenure surveys, construction surveys, land, pinpoint, pinpoint surveying, road survey">
<meta name="date" content="October 26, 2004">
<meta name="copyright" content="Pin Point Surveying">
<meta name="author" content="Pin Point Surveying">
<meta name="robots" content="index,follow,all">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<link rel="stylesheet" type="text/css" href="styles.css">
<link rel="stylesheet" type="text/css" href="css/lightbox.css" media="screen" />

<script type="text/javascript" src="js/prototype.js"\></script>
<script type="text/javascript" src="js/scriptaculous.js?load=effects"></script>
<script type="text/javascript" src="js/lightbox.js"\></script>
<script type="text/javascript" src="js/rollovers.js"\></script>

</head>
<body>