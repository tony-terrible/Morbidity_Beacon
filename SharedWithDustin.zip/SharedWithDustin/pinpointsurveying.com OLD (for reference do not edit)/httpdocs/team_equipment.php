<?php include ("phplib/includes.php"); ?>
<table width="690" border="0" cellspacing="0" cellpadding="0" align="center">
    <tr>
      <td width="10">&nbsp;</td>
      <td width="10">&nbsp;</td>
      <td width="312"><div align="left"><img src="images/logo_top.jpg" width="26" height="31" hspace="56"></div></td>
      <td width="348" align="right" valign="bottom" class="logins"><?php include ("phplib/logins.php"); ?></td>
      <td width="10">&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><div align="right"><img src="images/shadow_left_top.jpg" width="6" height="34"></div></td>
      <td bgcolor="#ECF601"><img src="images/logo.jpg" width="312" height="34"></td>
      <td background="images/bgrd_menu.jpg" bgcolor="#ECF601" class="menu" align="right"><?php include ("phplib/menu.php"); ?></td>
      <td><div align="left"><img src="images/shadow_right_top.jpg" width="6" height="34"></div></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><div align="right"><img src="images/shadow_left_middle.jpg" width="6" height="33"></div></td>
      <td colspan="2" bgcolor="#880012"><img src="images/body_top.gif" width="660" height="33"></td>
      <td><img src="images/shadow_right_middle.jpg" width="6" height="33"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td class="shadowLeft">&nbsp;</td>
      <td class="text" align="left"><p><span class="header">THE</span><span class="headerSecondary">team</span></p>
        <p>Our  skilled, motivated, and loyal staff is the foundation of Pin Point  Surveying Ltd. Teamwork is the strength in our ability to strive for  the best.</p>
        <p> <span class="textYellow">Randy Murray, AScT</span><br>
  Civil Engineering Technologist<br>
  <span class="textSecondary">Pin Point employee since 1999</span></p>
        <p> <span class="textYellow">Carolynne Wolfe, AScT</span><br>
          Civil Engineering Technologist<br>
  <span class="textSecondary">Pin Point employee 2005-2011, 2013-Current</span></p>
        <p> <span class="textYellow">Wayne Pierce, AScT</span><br>
  Civil Engineering Technologist<br>
  <span class="textSecondary">Pin Point employee since 2004</span></p>
        <p><span class="textYellow">Steve Gilfillan</span><br>
Crew Chief<br>
<span class="textSecondary">Pin Point employee since 2002</span></p>
                <p class="textItalic"> *Projects may include but are not limited to the above team members.</p>
        <p> <span class="header"><br>
        OUR</span><span class="headerSecondary">equipment</span><strong> </strong></p>
        <p>Our  field crews and office staff are staying current with the ever  changing survey equipment, software and computer systems in the  industry:</p>
        <br>

      </td>
      <td rowspan="2" valign="top" bgcolor="#A10016">
      
        <table width="300" border="0" align="center" cellpadding="0" cellspacing="0">
            <?php
            $result = mysql_query ("SELECT * FROM `site_images` WHERE `page` = 'Team' ORDER BY RAND() LIMIT 0,4");
            if (!$result) {	echo("error performing query: " . mysql_error() . ""); exit(); }
            
            $count = "0";
            
            if (mysql_num_rows ($result)) {
                while ($row = mysql_fetch_assoc ($result)) {
                    if ($count == "0") {
                        echo '<tr>' . "\n";
                        echo '  <td colspan="3" align="center"><a href="images/photos/magick.php/' . $row['safe_filename'] . '" rel="lightbox[]" title="PinPoint Surveying"><img src="images/photos/magick.php/' . $row['safe_filename'] . '?resize(315)" width="315" class="imageBorder"></a></td>' . "\n";
                        echo '</tr>' . "\n";
                    } else if ($count == "1") { 
                        echo '<tr>' . "\n";
                        echo '  <td valign="top" align="left"><a href="images/photos/magick.php/' . $row['safe_filename'] . '" rel="lightbox[]" title="PinPoint Surveying"><img src="images/photos/magick.php/' . $row['safe_filename'] . '?resize(100)" width="100" vspace="8" class="imageBorder"></a></td>' . "\n";
                    } else if ($count == "2") { 
                        echo '  <td valign="top" align="center"><a href="images/photos/magick.php/' . $row['safe_filename'] . '" rel="lightbox[]" title="PinPoint Surveying"><img src="images/photos/magick.php/' . $row['safe_filename'] . '?resize(100)" width="100" vspace="8" class="imageBorder"></a></td>' . "\n";
                    } else if ($count == "3") { 
                        echo '  <td valign="top" align="right"><a href="images/photos/magick.php/' . $row['safe_filename'] . '" rel="lightbox[]" title="PinPoint Surveying"><img src="images/photos/magick.php/' . $row['safe_filename'] . '?resize(100)" width="100" vspace="8" class="imageBorder"></a></td>' . "\n";
                        echo '</tr>' . "\n";
                    }
                    
                    $count++;
                }
            }
            ?>
        </table>

      </td>
      <td rowspan="2" class="shadowRight"><div align="left"></div></td>
    </tr>
    <tr>
      <td colspan="2" valign="bottom" class="shadowLeft" align="right"><img src="images/tool_left.jpg" width="24" height="134"></td>
      <td height="134" align="left" valign="top" class="text3">
      <blockquote>
        <span class="textYellow"> &raquo; </span> Robotic Total Stations<br>
        <span class="textYellow"> &raquo; </span> Trimble RTK and Static GPS<br>
        <span class="textYellow"> &raquo; </span> TSC 2's with Survey Controller and SCS 900 Software<br>
        <span class="textYellow"> &raquo; </span> Office Software Civil 3D 2012<br>
        <span class="textYellow"> &raquo; </span> Full Size Chevy 4x4 Trucks<br>

                </blockquote>
      </td>
    </tr>
    <tr>
      <td colspan="5"><img src="images/body_bottom_full.jpg" width="690" height="32"></td>
    </tr>
    <tr>
      <td colspan="2"><img src="images/spacer.gif" width="24" height="10"></td>
      <td colspan="2" valign="top"><?php include ("phplib/footer.php"); ?></td>
      <td>&nbsp;</td>
    </tr>
</table>
</body>
</html>