<?php include ("phplib/includes.php"); ?>
<table width="690" border="0" cellspacing="0" cellpadding="0" align="center">
    <tr>
      <td width="10">&nbsp;</td>
      <td width="10">&nbsp;</td>
      <td width="312"><div align="left"><img src="images/logo_top.jpg" width="26" height="31" hspace="56"></div></td>
      <td width="348" align="right" valign="bottom" class="logins"><?php include ("phplib/logins.php"); ?></td>
      <td width="10">&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><div align="right"><img src="images/shadow_left_top.jpg" width="6" height="34"></div></td>
      <td bgcolor="#ECF601"><img src="images/logo.jpg" width="312" height="34"></td>
      <td background="images/bgrd_menu.jpg" bgcolor="#ECF601" class="menu" align="right"><?php include ("phplib/menu.php"); ?></td>
      <td><div align="left"><img src="images/shadow_right_top.jpg" width="6" height="34"></div></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><div align="right"><img src="images/shadow_left_middle.jpg" width="6" height="33"></div></td>
      <td colspan="2" bgcolor="#880012"><img src="images/body_top.gif" width="660" height="33"></td>
      <td><img src="images/shadow_right_middle.jpg" width="6" height="33"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td class="shadowLeft">&nbsp;</td>
      <td height="250" align="left" valign="top" class="text"><p><span class="header">PINPOINT</span><span class="headerSecondary">contact</span></p>
        <p><span class="textYellow">Pin Point Surveying Ltd.<br>
        </span><span style="font-style: italic">Established 1999</span> </p>
        <p><span class="textYellow">&raquo;</span> Phone: (250) 832-6220<br>
          <span class="textYellow">&raquo;</span> Fax: (250) 832-0084<br>
        <span class="textYellow">&raquo;</span> Email: <script type="text/javascript">
<!--hivelogic enkoder-->
//<![CDATA[
<!--
var x="function f(x){var i,o=\"\",l=x.length;for(i=0;i<l;i+=2) {if(i+1<l)o+=" +
"x.charAt(i+1);try{o+=x.charAt(i);}catch(e){}}return o;}f(\"ufcnitnof x({)av" +
" r,i=o\\\"\\\"o,=l.xelgnhtl,o=;lhwli(e.xhcraoCedtAl(1/)3=!15{)rt{y+xx=l;=+;" +
"lc}tahce({)}}of(r=i-l;1>i0=i;--{)+ox=c.ahAr(t)i};erutnro s.buts(r,0lo;)f}\\" +
"\"(8),7\\\"\\\\qy6{02\\\\\\\\34\\\\03\\\\00\\\\\\\\4]02\\\\\\\\06\\\\0T\\\\" +
"TW30\\\\0R\\\\ZZTK]F^[EXFCIXUOZdOFmA? w@xsRur6zztk}f^{7,17\\\\\\\\`dWgk&Sm]" +
" 3=03\\\\\\\\21\\\\00\\\\01\\\\\\\\22\\\\06\\\\01\\\\\\\\ZY3+02\\\\\\\\01\\" +
"\\05\\\\03\\\\\\\\00\\\\00\\\\02\\\\\\\\24\\\\07\\\\00\\\\\\\\7O01\\\\\\\\0" +
"4\\\\02\\\\03\\\\\\\\hK{xvmux`(wpr{}za2ido'oia|pust\\\\n3\\\\02\\\\\\\\25\\" +
"\\04\\\\02\\\\\\\\\\\\n7\\\\02\\\\\\\\21\\\\07\\\\00\\\\\\\\4601\\\\\\\\20\\"+
"\\05\\\\03\\\\\\\\23\\\\03\\\\00\\\\\\\\0J00\\\\\\\\32\\\\01\\\\00\\\\\\\\0" +
"5\\\\0n\\\\\\\\\\\\07\\\\0K\\\\Z400\\\\00\\\\00\\\\\\\\26\\\\03\\\\01\\\\\\" +
"\\0B00\\\\\\\\\\\\\\\\\\\\\\\\v}03.>*0x :!?63$* \\\"\\\\f(;} ornture;}))++(" +
"y)^(iAtdeCoarchx.e(odrChamCro.fngriSt+=;o27=1y%i;+=)y78==(iif){++;i<l;i=0(i" +
"or;fthnglex.l=\\\\,\\\\\\\"=\\\",o iar{vy)x,f(n ioctun\\\"f)\")"             ;
while(x=eval(x));
//-->
//]]>
</script>

</p>
        <p>PO Box 38<br>
        Salmon Arm, B.C.<br>
        Canada 
        V1E 4N2</p>
        <p><span class="header"><br>RELATED</span><span class="headerSecondary">links</span></p>
        
        <p>Mountain Systems Ltd. - <a href="http://www.mvs.ca" target="_blank">.mvs.ca</a><br /></p>        
        
	  </td>
      <td rowspan="2" valign="top" bgcolor="#A10016">
      
        <table width="300" border="0" align="center" cellpadding="0" cellspacing="0">
            <?php
            $result = mysql_query ("SELECT * FROM `site_images` WHERE `page` = 'Contact' ORDER BY RAND() LIMIT 0,4");
            if (!$result) {	echo("error performing query: " . mysql_error() . ""); exit(); }
            
            $count = "0";
            
            if (mysql_num_rows ($result)) {
                while ($row = mysql_fetch_assoc ($result)) {
                    if ($count == "0") {
                        echo '<tr>' . "\n";
                        echo '  <td colspan="3" align="center"><a href="images/photos/magick.php/' . $row['safe_filename'] . '" rel="lightbox[]" title="PinPoint Surveying"><img src="images/photos/magick.php/' . $row['safe_filename'] . '?resize(315)" width="315" class="imageBorder"></a></td>' . "\n";
                        echo '</tr>' . "\n";
                    } else if ($count == "1") { 
                        echo '<tr>' . "\n";
                        echo '  <td valign="top" align="left"><a href="images/photos/magick.php/' . $row['safe_filename'] . '" rel="lightbox[]" title="PinPoint Surveying"><img src="images/photos/magick.php/' . $row['safe_filename'] . '?resize(100)" width="100" vspace="8" class="imageBorder"></a></td>' . "\n";
                    } else if ($count == "2") { 
                        echo '  <td valign="top" align="center"><a href="images/photos/magick.php/' . $row['safe_filename'] . '" rel="lightbox[]" title="PinPoint Surveying"><img src="images/photos/magick.php/' . $row['safe_filename'] . '?resize(100)" width="100" vspace="8" class="imageBorder"></a></td>' . "\n";
                    } else if ($count == "3") { 
                        echo '  <td valign="top" align="right"><a href="images/photos/magick.php/' . $row['safe_filename'] . '" rel="lightbox[]" title="PinPoint Surveying"><img src="images/photos/magick.php/' . $row['safe_filename'] . '?resize(100)" width="100" vspace="8" class="imageBorder"></a></td>' . "\n";
                        echo '</tr>' . "\n";
                    }
                    
                    $count++;
                }
            }
            ?>
        </table>

      
      </td>
      <td rowspan="2" class="shadowRight"><div align="left"></div></td>
    </tr>
    <tr>
      <td colspan="2" valign="bottom" class="shadowLeft" align="right"><img src="images/tool_left.jpg" width="24" height="134"></td>
      <td height="134" align="left" valign="top" class="text2">
      

      </td>
    </tr>
    <tr>
      <td colspan="5"><img src="images/body_bottom_full.jpg" width="690" height="32"></td>
    </tr>
    <tr>
      <td colspan="2"><img src="images/spacer.gif" width="24" height="10"></td>
      <td colspan="2" valign="top"><?php include ("phplib/footer.php"); ?></td>
      <td>&nbsp;</td>
    </tr>
</table>
</body>
</html>