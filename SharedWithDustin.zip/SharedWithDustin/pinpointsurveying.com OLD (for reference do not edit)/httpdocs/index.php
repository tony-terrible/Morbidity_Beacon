<?php include ("phplib/includes.php"); ?>
<table width="690" border="0" cellspacing="0" cellpadding="0" align="center">
    <tr>
      <td width="10">&nbsp;</td>
      <td width="10">&nbsp;</td>
      <td width="312"><div align="left"><img src="images/logo_top.jpg" width="26" height="31" hspace="56"></div></td>
      <td width="348" align="right" valign="bottom" class="logins"><?php include ("phplib/logins.php"); ?></td>
      <td width="10">&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><div align="right"><img src="images/shadow_left_top.jpg" width="6" height="34"></div></td>
      <td bgcolor="#ECF601"><img src="images/logo.jpg" width="312" height="34"></td>
      <td background="images/bgrd_menu.jpg" bgcolor="#ECF601" class="menu" align="right"><?php include ("phplib/menu.php"); ?></td>
      <td><div align="left"><img src="images/shadow_right_top.jpg" width="6" height="34"></div></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><div align="right"><img src="images/shadow_left_middle.jpg" width="6" height="33"></div></td>
      <td colspan="2" bgcolor="#880012"><img src="images/body_top.gif" width="660" height="33"></td>
      <td><img src="images/shadow_right_middle.jpg" width="6" height="33"></td>
    </tr>
    <tr>
<td>&nbsp;</td>

            <td class="shadowLeft">&nbsp;</td>
      <td class="text" align="left"><a href="pdfs/PPSL Answer Sheet Provincial Program 2013.pdf">  </a></br></br>
<p><span class="header">COMPANY</span><span class="headerSecondary">profile</span></p>
        <p>Pin  Point Surveying Ltd. is a professional, knowledgeable, and efficient  team of employees that strive for the highest standard of personal  and professional integrity. We specialize in road works and  underground layout. Whether it&rsquo;s a new subdivision or road upgrade,  if it needs to be laid out we can do it. We take pride in our ability  to respond quickly and efficiently to our clients needs, regardless  of project size. Our clients include both private and public sectors.</p>
        <p>Pin  Point&rsquo;s field of expertise includes, but is not limited to:</p>
        <ul>
          <li><a href="pdfs/prelim_sample_2.pdf">Preliminary Surveys</a> (PDF)</li>
          <li>Topographic Surveys</li>
          <li>As-built Surveys</li>
          <li>Road Works Layout</li>
          <li>Utility Layout (above or below ground)</li>
        </ul>
        <p> <span class="header"><br>
        WORK</span><span class="headerSecondary">experience</span></p>
      <p>*Summary:</p>
      <table width="275" border="0" cellspacing="1" cellpadding="2">
        <tr valign="top">
          <td bgcolor="#4C010B" class="textYellow">&raquo;</td>
          <td bgcolor="#61010E" class="textYellow">Fortis Gas North Okanagan / Shuswap Survey Contract (Since 1999)</td>
        </tr>
        <tr valign="top">
          <td bgcolor="#4C010B"><span class="textYellow">&raquo;</span></td>
          <td bgcolor="#69010F"><span class="textSecondary">Pit Surveys and <a href="pdfs/volume_sample_2.pdf" target="_blank">Volumes</a> (.PDF file) &Dagger;</span></td>
        </tr>
        <tr valign="top">
          <td bgcolor="#4C010B"><span class="textYellow">&raquo;</span></td>
          <td bgcolor="#69010F"><span class="textYellow">Bernard Ave upgrade Phase 1 - 3 downtown Kelowna</span><br>
          </td>
        </tr>
        <tr valign="top">
          <td bgcolor="#4C010B"><span class="textYellow">&raquo;</span></td>
          <td bgcolor="#61010E"><span class="textYellow">Kamloops Sewage Treatment Plant</span></td>
        </tr>
        <tr valign="top">
          <td bgcolor="#4C010B"><span class="textYellow">&raquo;</span></td>
          <td bgcolor="#69010F"><span class="textYellow">Glacier National Park Berm Extension</span><br>
          <span class="textSecondary">Construction Layout, VolumeS</span></td>
        </tr>
        <tr valign="top">
          <td bgcolor="#4C010B"><span class="textYellow">&raquo;</span></td>
          <td bgcolor="#61010E"><span class="textYellow">Highway Projects including: HWY 97 Armstrong, TCH Pritchard to Monte Creek, TCH Golden Kicking Horse Canyon Phase 3, TCH Banff</span><br>
          </td>
        </tr>
      </table></td>
      <td rowspan="2" valign="top" bgcolor="#A10016">
      

        <table width="300" border="0" align="center" cellpadding="0" cellspacing="0">
            <?php
            $result = mysql_query ("SELECT * FROM `site_images` WHERE `page` = 'Profile' ORDER BY RAND() LIMIT 0,4");
            if (!$result) {	echo("error performing query: " . mysql_error() . ""); exit(); }
            
            $count = "0";
            
            if (mysql_num_rows ($result)) {
                while ($row = mysql_fetch_assoc ($result)) {
                    if ($count == "0") {
                        echo '<tr>' . "\n";
                        echo '  <td colspan="3" align="center"><a href="images/photos/magick.php/' . $row['safe_filename'] . '" rel="lightbox[]" title="PinPoint Surveying"><img src="images/photos/magick.php/' . $row['safe_filename'] . '?resize(315)" width="315" class="imageBorder"></a></td>' . "\n";
                        echo '</tr>' . "\n";
                    } else if ($count == "1") { 
                        echo '<tr>' . "\n";
                        echo '  <td valign="top" align="left"><a href="images/photos/magick.php/' . $row['safe_filename'] . '" rel="lightbox[]" title="PinPoint Surveying"><img src="images/photos/magick.php/' . $row['safe_filename'] . '?resize(100)" width="100" vspace="8" class="imageBorder"></a></td>' . "\n";
                    } else if ($count == "2") { 
                        echo '  <td valign="top" align="center"><a href="images/photos/magick.php/' . $row['safe_filename'] . '" rel="lightbox[]" title="PinPoint Surveying"><img src="images/photos/magick.php/' . $row['safe_filename'] . '?resize(100)" width="100" vspace="8" class="imageBorder"></a></td>' . "\n";
                    } else if ($count == "3") { 
                        echo '  <td valign="top" align="right"><a href="images/photos/magick.php/' . $row['safe_filename'] . '" rel="lightbox[]" title="PinPoint Surveying"><img src="images/photos/magick.php/' . $row['safe_filename'] . '?resize(100)" width="100" vspace="8" class="imageBorder"></a></td>' . "\n";
                        echo '</tr>' . "\n";
                    }
                    
                    $count++;
                }
            }
            ?>
        </table>

      </td>
      <td rowspan="2" class="shadowRight"><div align="left"></div></td>
    </tr>
    <tr>
      <td colspan="2" valign="bottom" class="shadowLeft" align="right"><img src="images/tool_left.jpg" width="24" height="134"></td>
      <td height="134" align="left" valign="top" class="text2"><p><br>
        &nbsp;&nbsp;&nbsp;*Company references available upon <br>
      &nbsp;&nbsp;request, <a href="contact.php">contact us</a>.</p>
        <p class="textItalic" style="font-style: italic">&nbsp; </p>
        <p class="textItalic" style="font-style: italic"><a href="http://www.adobe.com/products/acrobat/readstep2.html" target="_blank"><img src="images/get_adobe_reader.gif" width="88" height="31" hspace="0" border="0" align="right"></a>&Dagger; Adobe Reader is required to view .PDF files, if you do not have Reader, you can download it for free by <a href="http://www.adobe.com/products/acrobat/readstep2.html" target="_blank">clicking here </a> </p></td>
    </tr>
    <tr>
      <td colspan="5"><img src="images/body_bottom_full.jpg" width="690" height="32"></td>
    </tr>
    <tr>
      <td colspan="2"><img src="images/spacer.gif" width="24" height="10"></td>
      <td colspan="2" valign="top"><?php include ("phplib/footer.php"); ?></td>
      <td>&nbsp;</td>
    </tr>
</table>
</body>
</html>