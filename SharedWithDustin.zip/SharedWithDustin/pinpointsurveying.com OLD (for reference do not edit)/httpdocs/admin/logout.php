<?php

session_start();

include "includes/config.php";
unset ($_SESSION["$site_session_prefix"]);

session_unset();
session_destroy(); // destroy session.


?>
<html>
<head>
<title><?php echo $sitename; ?> - Logged Out</title>
<link href="styles.css" rel="stylesheet" type="text/css">
</head>
<body>

<table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="100%" height="100%" align="center" valign="middle">
		
	<form action="<?=$PHP_SELF?><?if($QUERY_STRING){ echo"?". $QUERY_STRONG;}?>" method="POST">
	<table width="400" border="0" cellspacing="2" cellpadding="2">
        <tr> 
            <td><div align="center"><img src="<?php echo $sitelogo; ?>" width="<?php echo $sitelogowidth; ?>" height="<?php echo $sitelogoheight; ?>"></div></td>
        </tr>
        <tr> 
          <td><hr size="1"></td>
        </tr>
        <tr> 
          <td class="mainlight"><div align="center">
            <p>Successfully Logged Out</p>
            <p>[<a href="index.php">Log Back In</a>]</p>
          </div></td>
          </tr>
        <tr> 
          <td><hr size="1"></td>
          </tr>
      </table>
	  </form>
	  
	  </td>
  </tr>
</table>
</body>
</html>
