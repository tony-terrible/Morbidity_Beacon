<?php

$sitename = "PinPoint Surveying Admin";
$sitelogo = "images/logo.gif";
$sitelogowidth = "150";
$sitelogoheight = "72";
$site_session_prefix = "223fr23f24f34f";
?>