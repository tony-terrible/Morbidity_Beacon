<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title><?=$sitename?></title>
<link href="styles.css" rel="stylesheet" type="text/css">
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}

function viewInvoice(invoiceNum) {
	window.open (invoiceNum,'','toolbar=no,location=no,directories=no,status=no,menubar=yes,resizable=no,scrollbars=yes,width=750,height=500');
}

function confirmDelete (url) {
	if (confirm ("Are you sure you want to delete this entry?")) { 
		location.href = url;
	}
}
//-->
</script>
<script language="JavaScript" src="javascript/calendarDateInput.js"></script>
<script language="JavaScript" src="calendar1.js"></script>
</head>
<body onLoad="MM_preloadImages('images/powered_by_catch22_over.gif')">
<table width="100%" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="75" colspan="2" class="pageheader"><img src="<?=$sitelogo?>" width="<?=$sitelogowidth?>" height="<?=$sitelogoheight?>"></td>
  </tr>
  <tr valign="top">
    <td width="175" height="50%" class="sidebar"><table width="175" border="0" cellspacing="3" cellpadding="3">
	  <?php if ($_SESSION["$site_session_prefix"]['session_user_level'] == "0") { ?>
      <tr>
        <td class="menu" onMouseOver="this.className='menuOver'" onMouseOut="this.className='menu'"><a href="index.php?idx=clients">Clients</a></td>
      </tr>
	  <?php } ?>
	  <?php if ($_SESSION["$site_session_prefix"]['session_user_level'] == "0") { ?>
      <tr>
        <td class="menu" onMouseOver="this.className='menuOver'" onMouseOut="this.className='menu'"><a href="index.php?idx=jobs">Current Jobs</a></td>
      </tr>
	  <?php } ?>
      <tr>
        <td class="menu" onMouseOver="this.className='menuOver'" onMouseOut="this.className='menu'"><a href="index.php?idx=timesheets">Timesheets</a></td>
      </tr>
	  <?php if ($_SESSION["$site_session_prefix"]['session_user_level'] == "0") { ?>
      <tr>
        <td class="menu" onMouseOver="this.className='menuOver'" onMouseOut="this.className='menu'"> &nbsp; &raquo; <a href="index.php?idx=timeRecordSearch">Time Record Search</a></td>
      </tr>
	  <?php } ?>	  
	  <?php if ($_SESSION["$site_session_prefix"]['session_user_level'] == "0") { ?>
      <tr>
        <td class="menu" onMouseOver="this.className='menuOver'" onMouseOut="this.className='menu'"><a href="index.php?idx=invoices">Invoices</a></td>
      </tr>
	  <?php } ?>
	  <?php if ($_SESSION["$site_session_prefix"]['session_user_level'] == "0") { ?>
      <tr>
        <td class="menu" onMouseOver="this.className='menuOver'" onMouseOut="this.className='menu'"><a href="index.php?idx=descriptions">Descriptions</a></td>
      </tr>
	  <?php } ?>
	  <?php if ($_SESSION["$site_session_prefix"]['session_user_level'] == "0") { ?>
      <tr>
        <td class="menu" onMouseOver="this.className='menuOver'" onMouseOut="this.className='menu'"><a href="index.php?idx=settings">Settings</a></td>
      </tr>
	  <?php } ?>
	  <?php if ($_SESSION["$site_session_prefix"]['session_user_level'] == "0") { ?>
      <tr>
        <td class="menu" onMouseOver="this.className='menuOver'" onMouseOut="this.className='menu'"><a href="index.php?idx=site_images">Site Images</a></td>
      </tr>
	  <?php } ?>
	  <?php if ($_SESSION["$site_session_prefix"]['session_user_level'] == "0") { ?>
      <tr>
        <td class="menu" onMouseOver="this.className='menuOver'" onMouseOut="this.className='menu'"><a href="index.php?idx=userReports">User Reports</a></td>
      </tr>
	  <?php } ?>
	  <?php if ($_SESSION["$site_session_prefix"]['session_user_level'] == "0") { ?>
      <tr>
        <td class="menu" onMouseOver="this.className='menuOver'" onMouseOut="this.className='menu'"><a href="index.php?idx=users">Users</a></td>
      </tr>
	  <?php } ?>
      <tr>
        <td class="menu" onMouseOver="this.className='menuOver'" onMouseOut="this.className='menu'"><a href="logout.php">Logout</a></td>
      </tr>
    </table>
	<noscript>
	<br>
	<table width="175" border="0" cellspacing="3" cellpadding="3">
	<tr>
	  <td class="menuOver"><font color="#FF0000">WARNING</font><br>You do not have JavaScript enabled so you will NOT be prompted to delete items!</td>
	</tr>
	</table>
	</noscript>
	<br>
	<table width="175" border="0" cellspacing="3" cellpadding="3">
	<tr>
	  <td class="menuOver">Logged in as:<br><font color="#FF0000"><?php echo $_SESSION["$site_session_prefix"]['session_name'];?></font></td>
	</tr>
	</table>

	</td>
    <td width="100%" height="100%" rowspan="2" valign="top" bgcolor="#F8F8F8">
	<table width="100%" height="100%" cellpadding="10" border="0"><tr><td valign="top" height="100%" width="100%">