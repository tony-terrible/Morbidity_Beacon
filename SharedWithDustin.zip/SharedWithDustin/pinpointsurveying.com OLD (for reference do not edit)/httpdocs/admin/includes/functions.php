<?php
################################################################
### ImageMagick Resize
################################################################

function resize_image ($filepath, $filename, $width, $height) {

	$commands = '';
	$convert_path = 'convert';
	
	$document_root = $_SERVER['DOCUMENT_ROOT'];
	$image = $document_root . '/' . $filepath . $filename;

	if (!empty ($width) && is_numeric ($width)) {
		$commands .= ' -resize "'.$width.'"';
	}
	
	if (!empty ($height) && is_numeric ($height)) {
		$commands .= ' -resize "x'.$height.'"';
	}

	$convert = $convert_path . ' ' . $commands . ' "' . $image . '" "' . $image . '"';

	exec ($convert);
}

function resize_move_image ($input_file, $output_file, $width, $height) {

	$commands = '';
	$convert_path = 'convert';

	if (!empty ($width) && is_numeric ($width)) {
		$commands .= ' -resize "'.$width.'"';
	}
	
	if (!empty ($height) && is_numeric ($height)) {
		$commands .= ' -resize "x'.$height.'"';
	}

	$convert = $convert_path . ' ' . $commands . ' "' . $input_file . '" "' . $output_file . '"';

	exec ($convert);
}



### Catch 22 Media - Functions

### April 27th, 2005 - Added "oldestYear" function

### Sept 1, 2004 - Added "makebrief" function
### MODIFIED ImageCreate FUNCTION for sunwave servers
### Added FutureDATE function

### April 11, 2007 added:
## checkEmail
## update_login_history
## removeBans

##Check for inappropriate characters in Email
function checkEmail($email) {

   if (!preg_match("/^([a-zA-Z0-9_\.]+)@([a-zA-Z0-9\-])+\\.+([a-zA-Z0-9\-\.]{2,})+$/i", $email)) {

      return FALSE;
   }


   list($Username, $Domain) = split("@", $email);
 
 	
   if (getmxrr($Domain, $MXHost)) {
      return TRUE;
   } else  {
   	$result = @fsockopen($Domain, 25, $errno, $errstr, 30);
      if ($result) {
         return TRUE; 
      } else {
         return FALSE; 
      }
   }

}

// Updates login_attemps with appropriate message
function update_login_history($user_email_address, $attempt_error_message) {

	if (empty($user_email_address)) {
		$user_email_address = "Not Supplied";
	}

	$sql = "INSERT INTO `user_login_history` (
				`attempt_user_email`,
				`attempt_ip_address`,
				`attempt_date_time`,
				`attempt_error_message`
			) VALUES (
				'$user_email_address',
				'$_SERVER[REMOTE_ADDR]',
				NOW(),
				'$attempt_error_message'
			)";
		
	if (@mysql_query($sql)) {
	} else {
		echo "Error Updating Error Logs(32):" . mysql_error() . "";
	}
	

	if ($attempt_error_message != "Success") {
	
		################################################################
		###	Check for 25 failed login attempts within 2 hours and ban
		################################################################
		
		$sql = "SELECT * FROM `user_login_history`
					WHERE `attempt_ip_address` = '$_SERVER[REMOTE_ADDR]'
						AND `attempt_error_message` <> 'Success'
					ORDER BY `attempt_date_time` DESC
					LIMIT 0,25";

		$result = mysql_query ($sql);

		if (mysql_num_rows($result) > 24) {
			if (time() - strtotime(mysql_result($result, 24, 'attempt_date_time')) < 7200) {
			
				$unbanned_datetime = date("Y-m-d G:i:s", strtotime("+2 hours"));
			
				$sql = "INSERT INTO `user_bans` (
							`banned_ip_address`,`banned_datetime`,`unbanned_datetime`
						) VALUES (
							'$_SERVER[REMOTE_ADDR]',NOW(),'$unbanned_datetime'
						)";
						
				@mysql_query($sql);
			}
		}
		
		### End 25 login attempt check
		
		if ($attempt_error_message != "Banned Email Address" && $user_email_address != "Not Supplied") {

			################################################################
			###	Check for 5 failed login attempts within 5 minutes and ban
			################################################################
			
			$sql = "SELECT * FROM `user_login_history`
						WHERE `attempt_user_email` = '$user_email_address' 
							AND `attempt_error_message` <> 'Success'
						ORDER BY `attempt_date_time` DESC
						LIMIT 0,5";
	
			$result = mysql_query ($sql);
	
			if (mysql_num_rows($result) > 4) {
				if (time() - strtotime(mysql_result($result, 4, 'attempt_date_time')) < 300) {
				
					$unbanned_datetime = date("Y-m-d G:i:s", strtotime("+5 minutes"));
					
					$sql = "INSERT INTO `user_bans` (
								`banned_email_address`,`banned_datetime`,`unbanned_datetime`
							) VALUES (
								'$user_email_address',NOW(),'$unbanned_datetime'
							)";					
				
					@mysql_query($sql);
				}
			}
			
			### End 5 login attempt check
		}
	}
}

################################################################
###
###	Remove Bans Function
###
################################################################

function removeBans () {	
	$sql = "DELETE FROM `user_bans` WHERE `unbanned_datetime` < NOW()";
	@mysql_query($sql);
}

function getFileSize($file) {

	$filesize = filesize($file);

	if ($filesize >= 1073741824) {
		$size = number_format(($filesize / 1073741824),2) . " GB";
	} elseif ($filesize >= 1048576) {
		$size = number_format(($filesize / 1048576),2) . " MB";
	} elseif ($filesize >= 1024) {
		$size = number_format(($filesize / 1024),2) . " KB";
	} elseif ($filesize >= 0) {
		$size = $filesize . " bytes";
	} else {
		$size = "0 bytes";
	}

return $size;
}

function printMessage($text) {
	print "<table width=\"100%\" height=\"50\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\"><tr>";
	print "<td width=\"100%\" height=\"50\" align=\"center\" valign=\"middle\" class=\"main_color\">$text</td>";
	print "</tr></table>";
}

function safehtml($html) {
	$chars = htmlspecialchars($html, ENT_QUOTES);
	$allowed = "(b|i|u|a|span)";
	$html = preg_replace('/&lt;(\/|\s?)' . $allowed . '(.*)&gt;/Uis', '<\\1\\2\\3>', $chars);
	$text = ereg_replace("\r\n","<br>", $html);
	return $text;
}

##############################################
# Shiege Iseng Resize Class
# 11 March 2003
# shiegege@yahoo.com
# http://kentung.f2o.org/scripts/thumbnail/
################
# Thanks to :
# Dian Suryandari <dianhau@yahoo.com>
/*############################################
Sample :
$thumb=new thumbnail("./shiegege.jpg");			// generate image_file, set filename to resize
$thumb->size_width(100);						// set width for thumbnail, or
$thumb->size_height(300);						// set height for thumbnail, or
$thumb->size_auto(200);							// set the biggest width or height for thumbnail
$thumb->jpeg_quality(75);						// [OPTIONAL] set quality for jpeg only (0 - 100) (worst - best), default = 75
$thumb->show();									// show your thumbnail
$thumb->save("./huhu.jpg");						// save your thumbnail to file
----------------------------------------------
Note :
- GD must Enabled
- Autodetect file extension (.jpg/jpeg, .png, .gif, .wbmp)
  but some server can't generate .gif / .wbmp file types
- If your GD not support 'ImageCreateTrueColor' function,
  change one line from 'ImageCreateTrueColor' to 'ImageCreate'
  (the position in 'show' and 'save' function)
*/############################################


class thumbnail {
	var $img;

	function thumbnail($imgfile)
	{
		//detect image format
		$this->img["format"]=ereg_replace(".*\.(.*)$","\\1",$imgfile);
		$this->img["format"]=strtoupper($this->img["format"]);
		if ($this->img["format"]=="JPG" || $this->img["format"]=="JPEG") {
			//JPEG
			$this->img["format"]="JPEG";
			$this->img["src"] = ImageCreateFromJPEG ($imgfile);
		} elseif ($this->img["format"]=="PNG") {
			//PNG
			$this->img["format"]="PNG";
			$this->img["src"] = ImageCreateFromPNG ($imgfile);
		} elseif ($this->img["format"]=="GIF") {
			//GIF
			$this->img["format"]="GIF";
			$this->img["src"] = ImageCreateFromGIF ($imgfile);
		} elseif ($this->img["format"]=="WBMP") {
			//WBMP
			$this->img["format"]="WBMP";
			$this->img["src"] = ImageCreateFromWBMP ($imgfile);
		} else {
			//DEFAULT
			echo "Not Supported File";
			exit();
		}
		@$this->img["lebar"] = imagesx($this->img["src"]);
		@$this->img["tinggi"] = imagesy($this->img["src"]);
		//default quality jpeg
		$this->img["quality"]=75;
	}

	function size_height($size=100)
	{
		//height
    	$this->img["tinggi_thumb"]=$size;
    	@$this->img["lebar_thumb"] = ($this->img["tinggi_thumb"]/$this->img["tinggi"])*$this->img["lebar"];
	}

	function size_width($size=100)
	{
		//width
		$this->img["lebar_thumb"]=$size;
    	@$this->img["tinggi_thumb"] = ($this->img["lebar_thumb"]/$this->img["lebar"])*$this->img["tinggi"];
	}

	function size_auto($size=100)
	{
		//size
		if ($this->img["lebar"]>=$this->img["tinggi"]) {
    		$this->img["lebar_thumb"]=$size;
    		@$this->img["tinggi_thumb"] = ($this->img["lebar_thumb"]/$this->img["lebar"])*$this->img["tinggi"];
		} else {
	    	$this->img["tinggi_thumb"]=$size;
    		@$this->img["lebar_thumb"] = ($this->img["tinggi_thumb"]/$this->img["tinggi"])*$this->img["lebar"];
 		}
	}

	function jpeg_quality($quality=75)
	{
		//jpeg quality
		$this->img["quality"]=$quality;
	}

	function show()
	{
		//show thumb
		@Header("Content-Type: image/".$this->img["format"]);

		/* change ImageCreate to ImageCreate if your GD not supported ImageCreate function*/
		$this->img["des"] = ImageCreateTrueColor($this->img["lebar_thumb"],$this->img["tinggi_thumb"]);
    		@imagecopyresized ($this->img["des"], $this->img["src"], 0, 0, 0, 0, $this->img["lebar_thumb"], $this->img["tinggi_thumb"], $this->img["lebar"], $this->img["tinggi"]);

		if ($this->img["format"]=="JPG" || $this->img["format"]=="JPEG") {
			//JPEG
			imageJPEG($this->img["des"],"",$this->img["quality"]);
		} elseif ($this->img["format"]=="PNG") {
			//PNG
			imagePNG($this->img["des"]);
		} elseif ($this->img["format"]=="GIF") {
			//GIF
			imageGIF($this->img["des"]);
		} elseif ($this->img["format"]=="WBMP") {
			//WBMP
			imageWBMP($this->img["des"]);
		}
	}

	function save($save="")
	{
		//save thumb
		if (empty($save)) $save=strtolower("./thumb.".$this->img["format"]);
		/* change ImageCreate to ImageCreate if your GD not supported ImageCreate function*/
		$this->img["des"] = ImageCreateTrueColor($this->img["lebar_thumb"],$this->img["tinggi_thumb"]);
    		@imagecopyresized ($this->img["des"], $this->img["src"], 0, 0, 0, 0, $this->img["lebar_thumb"], $this->img["tinggi_thumb"], $this->img["lebar"], $this->img["tinggi"]);

		if ($this->img["format"]=="JPG" || $this->img["format"]=="JPEG") {
			//JPEG
			imageJPEG($this->img["des"],"$save",$this->img["quality"]);
		} elseif ($this->img["format"]=="PNG") {
			//PNG
			imagePNG($this->img["des"],"$save");
		} elseif ($this->img["format"]=="GIF") {
			//GIF
			imageGIF($this->img["des"],"$save");
		} elseif ($this->img["format"]=="WBMP") {
			//WBMP
			imageWBMP($this->img["des"],"$save");
		}
	}
}

 
function makebrief($string,$temp_max_length) { 
	$temp_max_length = $max_length; 
	$string_length=strlen($string); 
	
	// Keep reducing the string until we reach a . or ! or ? hence only leaving a full sentence at the end 
	do { 
		if ((!strcmp(substr($string,$temp_max_length,1),"."))
			|| (!strcmp(substr($string,$temp_max_length,1),"?"))
			|| (!strcmp(substr($string,$temp_max_length,1),"!")))
			break; 
			$temp_max_length--; 
	} while($temp_max_length<$string_length); 
	
	// if this results in a string smaller than zero then perform the same operation down to the nearest space. 
	if ($temp_max_length < 1 ) { 
		$temp_max_length = $max_length; 
		do { 
			if (!strcmp(substr($string,$temp_max_length,1)," "))
			break; 
			$temp_max_length--; 
		} while($temp_max_length<$string_length); 
	} 
	
	// trim the string 
	return 
	trim(substr($string,0,$temp_max_length))."..."; 
}



function futureDate($timestamp) {

	$t = split("/",$timestamp); 
	if (count($t)!=3) $t = split("-",$timestamp); 
	if (count($t)!=3) $t = split(" ",$timestamp); 
	
	if (count($t)!=3) echo 'Date could not be parsed in futureDate()'; 
	
	if (!is_numeric($t[0])) return -1; 
	if (!is_numeric($t[1])) return -2; 
	if (!is_numeric($t[2])) return -3; 
	
	if ($t[0]<1902 || $t[0]>2037) return -3; 
	
	$timeStamp = mktime(0,0,0, $t[1], $t[2], $t[0]); 
	if($timeStamp >= time()) { 
	    return true; 
	} else { 
    	return false; 
	} 
} 

function oldestYear($table,$column,$condition) {

	if ($condition == "") {
		$result = mysql_query ("SELECT YEAR($column) AS oldestYear FROM `$table` ORDER BY `$column` ASC LIMIT 0,1");
	} else {
		$result = mysql_query ("SELECT YEAR($column) AS oldestYear FROM `$table` WHERE $condition ORDER BY `$column` ASC LIMIT 0,1");
	}
	if (!$result) {	echo("Error Performing Query (oldestYear): " . mysql_error() . ""); exit(); }
	
	if (mysql_num_rows($result)) {
		while($row = mysql_fetch_array($result)) {
			extract($row);
		}
	} else {
		$oldestYear = date("Y");
	}
	return $oldestYear;
}

function randomPassword() {
	//set the random id length
	$random_id_length = 10;
	
	//generate a random id encrypt it and store it in $rnd_id
	$rnd_id = crypt(uniqid(rand(),1));
	
	//to remove any slashes that might have come
	$rnd_id = strip_tags(stripslashes($rnd_id));
	
	//Removing any . or / and reversing the string
	$rnd_id = str_replace(".","",$rnd_id);
	$rnd_id = strrev(str_replace("/","",$rnd_id));
	
	//finally I take the first 10 characters from the $rnd_id
	$rnd_id = substr($rnd_id,0,$random_id_length);
	
	return $rnd_id; 
}

function check_email ($email) {

	if (!preg_match("/^([a-zA-Z0-9_\.]+)@([a-zA-Z0-9\-])+\\.+([a-zA-Z0-9\-\.]{2,})+$/i", $email)) {
		return FALSE;
	}
	
	list($Username, $Domain) = split("@", $email);
	
	if (getmxrr($Domain, $MXHost)) {
		return TRUE;
	} else {
		$result = @fsockopen($Domain, 25, $errno, $errstr, 30);
		if ($result) {
			return TRUE; 
		} else {
			return FALSE; 
		}
	}
}



?>