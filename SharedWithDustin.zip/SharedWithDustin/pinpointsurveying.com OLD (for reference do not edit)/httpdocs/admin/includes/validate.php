<?php
//Turns get_magic_quotes_gpc off at run time
//define ("MAGIC_QUOTES", 0);

function cleanmysql($arr,$arr2) {
	foreach ($arr as $gt1=>$gt2) {
		if (is_array($arr[$gt1])) {
			list($arr[$gt1],$arr2[$gt1]) = cleanmysql($arr[$gt1],$arr2[$gt1]);
		} else {
			if (get_magic_quotes_gpc()) {
				
			} else {
				$gt2=mysql_real_escape_string($gt2);
				
			}
			$gt2 = htmlentities($gt2);
			$arr[$gt1]=$arr2[$gt1]=$gt2;
		}
	}
	
	return array($arr,$arr2);
}

list($_GET,$GLOBALS) = cleanmysql($_GET,$GLOBALS);
list($_POST,$GLOBALS) = cleanmysql($_POST,$GLOBALS);
list($_COOKIE,$GLOBALS) = cleanmysql($_COOKIE,$GLOBALS);
?>