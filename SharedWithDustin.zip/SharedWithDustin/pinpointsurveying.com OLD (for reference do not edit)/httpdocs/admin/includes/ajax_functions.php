<?php
###################################
### AJAX Functions
###################################

function change_client ($client_id) {

	if (is_numeric($client_id)) {

		$return = '';
	
		$return .= '<select name="job_id" id="job_id" class="form">';
		
		
		$result = mysql_query ("SELECT * FROM `jobs` WHERE `client_id` = '$client_id' ORDER BY `number` DESC");
		if (!$result) { echo("error performing query: " . mysql_error() . ""); exit(); }
		
		if (mysql_num_rows($result)) {
			
			$return .= '<option value="">All Jobs</option>';
		
			while ($row = mysql_fetch_assoc($result)) {
				$return .= "<option value=\"$row[job_id]\">$row[number] - $row[title]</option>\n";
			}
		} else {
			$return .= "<option value=\"\">No jobs found under this client</option>\n";
		}
		
		$return .= '</select>';
		
		return $return;
	
	} else {
		return "No client selected";
	}
}

### End AJAX Functions
?>