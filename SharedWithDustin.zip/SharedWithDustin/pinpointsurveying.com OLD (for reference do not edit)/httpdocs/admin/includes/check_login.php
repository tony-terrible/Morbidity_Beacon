<?php
if (isset($_SESSION["$site_session_prefix"]['user_email']) && isset($_SESSION["$site_session_prefix"]['user_password'])) {

	$session_user_email = $_SESSION["$site_session_prefix"]['user_email'];
	$session_user_password = $_SESSION["$site_session_prefix"]['user_password'];

	$result = mysql_query ("SELECT * FROM `users` WHERE `email` = '{$_SESSION["$site_session_prefix"]['user_email']}' && `password` = '{$_SESSION["$site_session_prefix"]['user_password']}'");
	if (!$result) {	echo("error performing query: " . mysql_error() . ""); exit(); }
	
	if (!mysql_num_rows($result)) {
	
		unset ($_SESSION["$site_session_prefix"]);
		header ("Location: login.php");
		exit();
	}
} else {
	
	unset ($_SESSION["$site_session_prefix"]);
	header ("Location: login.php");
	exit();

}
?>