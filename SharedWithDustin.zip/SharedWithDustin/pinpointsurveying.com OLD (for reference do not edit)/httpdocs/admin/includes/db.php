<?php

$db = @mysql_connect("localhost","pinpointsurvey","93mca9zZ");
if (!$db) { echo("unable to connect"); exit(); }
if (! @mysql_select_db("pinpointsurveying") ) { echo("unable to locate database"); exit(); }
?>