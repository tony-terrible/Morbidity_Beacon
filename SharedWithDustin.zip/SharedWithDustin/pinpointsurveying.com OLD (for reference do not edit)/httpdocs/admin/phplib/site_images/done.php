<?php

$uploaddir = '../images/photos/';
$serverdir = 'images/photos/';

if ($act == "add" ) {				// ####################### ADD #######################

	$sql = "INSERT INTO `site_images` VALUES ('', '', '', '$page')";
		
	if (@mysql_query($sql)) {
		printMessage("Image Successfully Added");
		
		###########################################
		### Upload Image	
		###########################################
		
		$site_image_id = mysql_insert_id ();
		
		if (!empty ($_FILES['fileName']['name'])) {

			$orig_filename = addslashes($_FILES['fileName']['name']);
			$file_type = $_FILES['fileName']['type'];
		
			// Check that file uploaded is jpeg, gif or png
			if ($file_type == 'image/jpeg' || $file_type == 'image/pjpeg' || $file_type == 'image/gif' || $file_type == 'image/png') {
				
				if ($file_type == 'image/jpeg' || $file_type == 'image/pjpeg') {
					$safe_filename = $site_image_id . '.jpg';
				} else 	if ($file_type == 'image/gif') {
					$safe_filename = $site_image_id . '.gif';
				} else 	if ($file_type == 'image/png') {
					$safe_filename = $site_image_id . '.png';
				}
			
				if (move_uploaded_file ($_FILES['fileName']['tmp_name'], $uploaddir . $safe_filename)) {
				
					// Resize image
					$imagesize = getimagesize ($uploaddir . $safe_filename);
					
					if ($imagesize[0] > $imagesize[1]) {
						resize_image ("$serverdir","$safe_filename",'700','');
					} else {
						resize_image ("$serverdir","$safe_filename",'','500');		
					}
					
					// Update database with file name
					
					if (!@mysql_query ("UPDATE `site_images` SET `orig_filename` = '$orig_filename', `safe_filename` = '$safe_filename' WHERE `site_image_id` = '$site_image_id' LIMIT 1")) {
						echo 'There was an error updating the photo database entry.<br><br>';
					}
				
				} else {
					echo 'Photo not uploaded - error uploading file!<br><br>';
				}
			} else {
				echo 'Photo not uploaded - invalid file type - uploaded photos must be jpg, gif, or png.<br><br>';
			}
			
		} else {
			echo "No photo was selected for upload!<br><br>";
		}
	
		### End Upload photo
		
	} else {
		printMessage("Error Adding Image: " . mysql_error() . "");
	}
}

if ($act == "del" ) {				// ####################### DEL #######################
	
	$result = mysql_query("SELECT * FROM `site_images` WHERE `site_image_id`='$id'");
	$row = mysql_fetch_assoc ($result);
	$filetodelete = $row['safe_filename'];
	
	$sql = "DELETE FROM `site_images` WHERE `site_image_id`='$id'";

	if (@mysql_query($sql)) { 
		printMessage("Image Successfully Deleted");
		
		// Delete all versions of picture
		if ($handle = opendir($uploaddir)) {
			while (false !== ($file = readdir($handle))) {
				if (! (strpos ("$file", "$filetodelete") === false)) {
					if (!unlink ($uploaddir . $file)) {
						echo "<font color=\"#ff0000\">Error Deleting Picture!</font><br><br>";
					}
				}
			}
			closedir($handle);	
		} else {
			echo "<font color=\"#ff0000\">Error Opening Images Directory!</font><br><br>";
		}		
		
	} else {
		printMessage("Error Deleting Image: " . mysql_error() . "");
	}

}
?>