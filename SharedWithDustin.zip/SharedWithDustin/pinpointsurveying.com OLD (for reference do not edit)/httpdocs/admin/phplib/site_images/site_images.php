<?php
switch($step){
	case "1":									// index
		include("phplib/site_images/idx.php");
		break;
	case "2":									// add/edit
		include("phplib/site_images/edit.php");
		break;
	case "3":									// done
		include("phplib/site_images/done.php");
		break;
	default:									// index
		include("phplib/site_images/idx.php");
		break;
}
?>