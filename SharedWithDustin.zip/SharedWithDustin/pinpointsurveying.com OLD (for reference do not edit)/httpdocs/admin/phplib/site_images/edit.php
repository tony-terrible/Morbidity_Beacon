<form method="post" action="index.php" name="form" enctype="multipart/form-data">
<input type="hidden" name="idx" value="site_images">
<input type="hidden" name="step" value="3">
<input type="hidden" name="act" value="add">
	
<table width="100%" border="0" cellspacing="1" cellpadding="2">
  <tr>
    <td colspan="2" class="header">Image Editor</td>
  </tr>
  <tr>
    <td colspan="2" class="mainlight"><hr size="1" noshade></td>
  </tr>
  <tr>
    <td class="mainlight">Image</td>
    <td class="mainlight"><input name="fileName" type="file" class="form" id="fileName" size="60" maxlength="200"></td>
  </tr>
  <tr>
    <td class="mainlight">&nbsp;</td>
    <td class="mainlight">&nbsp;</td>
  </tr>
  <tr>
    <td class="mainlight">Page</td>
    <td class="mainlight">
    
    <select name="page" id="page" class="form">
      <option value="Profile">Profile</option>
      <option value="Team">Team</option>
      <option value="Contact">Contact</option>
    </select>
    
    </td>
  </tr>
  <tr>
    <td colspan="2" class="mainlight"><hr size="1" noshade></td>
  </tr>
  <tr>
    <td class="mainlight">&nbsp;</td>
    <td align="right"><input name="Submit" type="image" src="images/button_ok.gif" class="form" value="Submit">&nbsp; &nbsp; &nbsp;<a href="index.php?idx=site_images"><img src="images/button_cancel.gif" border="0"></a></td>
  </tr>
</table>
