<table width="100%"  border="0" cellspacing="2" cellpadding="2">
  <tr>
    <td class="header">Site Images</td>
  </tr>
  <tr>
    <td class="submenu">[ <a href="index.php?idx=site_images&step=2&act=add">Add Image</a> ] </td>
  </tr>
</table>

<table width="100%" border="0" cellspacing="2" cellpadding="2">
  <tr class="tableheader">
    <td>Original File Name</td>
    <td>Safe File Name</td>
	<td>Page</td>
    <td width="15">&nbsp;</td>
  </tr>
  <?php

$result = mysql_query ("SELECT * FROM `site_images` ORDER BY `page`,`orig_filename` ASC");
if (!$result) {	echo("error performing query: " . mysql_error() . ""); exit(); }

$rowcount = "0";

if(mysql_num_rows($result)) {
	while($row = mysql_fetch_assoc ($result)) {
		
		if ($rowcount == "1") { $bgclass = "class=\"tablealt\""; $rowcount = "0"; } else { $bgclass = "class=\"table\""; $rowcount++; }
		
		echo "<tr $bgclass>";
		echo "<td>" . $row['orig_filename'] . "</td>";
		echo "<td>" . $row['safe_filename'] . "</td>";
		echo "<td>" . $row['page'] . "</td>";
		echo "<td width=\"16\"><a href=\"javascript:confirmDelete('index.php?idx=site_images&step=3&act=del&id=" . $row['site_image_id'] . "')\"><img src=\"images/x.gif\" border=\"0\" alt=\"Delete\"></a></td>";
		echo "</tr>";
		
	}
} else {
	echo "<tr bgcolor=\"#EEEEEE\" class=\"main\">";
	echo "<td colspan=\"3\"><div align=\"center\">No images in database</div></td>";
	echo "</tr>";
}           
?>
</table>
