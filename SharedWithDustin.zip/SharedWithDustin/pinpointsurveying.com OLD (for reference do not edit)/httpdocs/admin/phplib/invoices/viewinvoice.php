<?php
session_start();
include ('../../includes/db.php');
include ('../../includes/config.php');

if (isset($_SESSION["$site_session_prefix"]['user_email']) && isset($_SESSION["$site_session_prefix"]['user_password'])) {

	$session_user_email = $_SESSION["$site_session_prefix"]['user_email'];
	$session_user_password = $_SESSION["$site_session_prefix"]['user_password'];

	$result = mysql_query ("SELECT * FROM `users` WHERE `email` = '{$_SESSION["$site_session_prefix"]['user_email']}' && `password` = '{$_SESSION["$site_session_prefix"]['user_password']}'");
	if (!$result) {	echo("error performing query: " . mysql_error() . ""); exit(); }
	
	if (!mysql_num_rows($result)) {
	
		unset ($_SESSION["$site_session_prefix"]);
		header ("Location: ../../login.php");
		exit();
	}
} else {
	
	unset ($_SESSION["$site_session_prefix"]);
	header ("Location: ../../login.php");
	exit();

}

include ("../../includes/validate.php");
include ('../../includes/functions.php');



$sql = "SELECT * 
		FROM `invoices`
		LEFT JOIN `jobs` 		ON `invoices`.`job_id` 		= `jobs`.`job_id`
		LEFT JOIN `clients` 	ON `invoices`.`client_id` 	= `clients`.`client_id`
		WHERE `invoices`.`invoice_id` = '$_GET[id]'
		LIMIT 1
		";

$result = mysql_query ($sql);
if (!$result) {	echo("error performing query: " . mysql_error() . ""); exit(); }

if(mysql_num_rows($result)) {
	while($row = mysql_fetch_assoc ($result)) {
	
		$fieldRate = $row['fieldTimePrice'];
		$fieldgpsRate = $row['fieldgpsTimePrice'];
		$travelRate = $row['travelTimePrice'];
		$officeRate = $row['officeTimePrice'];
		
		$invoiceDate = date("l, F jS, Y", strtotime($row['invoice_date']));
		
		?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>PinPoint Surveying Invoice <?php echo $row['invoiceNum']; ?></title>
<style type="text/css">
<!--
body,td,th {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.style1 {
	font-size: 14px;
	font-weight: bold;
}
.style2 {font-size: 24px; font-weight: bold; }
.style3 {
	color: #FF0000;
	font-size: 18px;
}
.style5 {
	font-size: 14px;
	font-style: italic;
}
.style7 {font-size: 10px; }
.pageBreak { page-break-before: always; }
-->
</style>

</head>

<body>
<table width="100%"  border="0" cellspacing="5" cellpadding="5">
  <tr>
    <td><table width="100%"  border="0" cellspacing="2" cellpadding="2">
      <tr valign="bottom">
        <td colspan="2"><div align="center">
            <p><img src="../../images/logo.gif" width="150" height="72"><br>
                <span class="style1">Surveying Ltd.</span></p>
            <div align="center" class="style2">
              <p class="style3">I N V O I C E</p>
            </div>
            <p align="center"><strong>Invoice # <?php echo $row['invoiceNum']; ?> | Job # <?php echo $row['number']; ?> | <?php echo $invoiceDate; ?></strong></p>
        </div></td>
      </tr>
      <tr>
        <td colspan="2"><hr size="1"></td>
      </tr>
      <tr>
        <td width="50%" valign="top"><table width="100%"  border="0" cellspacing="2" cellpadding="2">
            <tr valign="top">
              <td width="100" class="style1">Client:</td>
              <td><?php
				echo "<b>$row[company]</b>";
				if ($row['contact'] != "") { echo "<br>$row[contact]"; }
				if ($row['address1'] != "") { echo "<br>$row[address1]"; }
				if ($row['address2'] != "") { echo "<br>$row[address2]"; }
				if ($row['city'] != "") { echo "<br>$row[city] $row[province_state]"; }
				if ($row['postal_zip'] != "") { echo "<br>$row[postal_zip]"; }			  
				?></td>
            </tr>
        </table></td>
        <td width="50%" valign="top"><table width="100%"  border="0" cellspacing="2" cellpadding="2">
            <tr valign="top">
              <td width="100" class="style1">Rates:</td>
              <td>Field: <br>
              Field GPS: <br>
            Travel:<br>
            Office: </td>
              <td>$<?php echo $fieldRate; ?> per hour<br>
            $<?php echo $fieldgpsRate; ?> per hour<br>
            $<?php echo $travelRate; ?> per hour<br>
            $<?php echo $officeRate; ?> per hour </td>
            </tr>
        </table></td>
      </tr>
      <tr>
        <td colspan="2"><hr size="1"></td>
      </tr>
      <tr>
        <td colspan="2"><strong class="style1">Job Description:</strong></td>
      </tr>
      <tr>
        <td colspan="2"><?php echo $row['description']; ?></td>
      </tr>
      <tr>
        <td colspan="2"><hr size="1"></td>
      </tr>
      <tr>
        <td colspan="2"><table width="100%"  border="0" cellpadding="2" cellspacing="2">
            <tr>
              <td><strong>Field Time </strong></td>
              <td><strong><?php echo $row['fieldHours']; ?> hours </strong></td>
              <td><div align="right"><strong>$<?php echo $row['fieldBill']; ?></strong></div></td>
            </tr>
            <tr>
              <td><strong>Field GPS Time </strong></td>
              <td><strong><?php echo $row['fieldgpsHours']; ?> hours </strong></td>
              <td><div align="right"><strong>$<?php echo $row['fieldgpsBill']; ?></strong></div></td>
            </tr>            
            <tr>
              <td><strong>Travel Time </strong></td>
              <td><strong><?php echo $row['travelHours']; ?> hours </strong></td>
              <td><div align="right"><strong>$<?php echo $row['travelBill']; ?></strong></div></td>
            </tr>
            <tr>
              <td><strong>Office Time </strong></td>
              <td><strong><?php echo $row['officeHours']; ?> hours </strong></td>
              <td><div align="right"><strong>$<?php echo $row['officeBill']; ?></strong></div></td>
            </tr>
			<?php
			$sql_items = "SELECT * FROM `invoice_items_join` WHERE `invoice_id` = '{$row['invoice_id']}'";
			$result_items = mysql_query($sql_items);
			if (mysql_num_rows($result_items)) {
				while ($row_items = mysql_fetch_assoc($result_items)) {
					echo '<tr>';
					echo "<td><strong>$row_items[name]</strong></td>";
				 	echo "<td><strong>{$row_items['quantity']}</strong></td>";
					echo '<td><div align="right"><strong>$';
					echo number_format($row_items['price']*$row_items['quantity'], 2);
					echo '</strong></div></td>';
					echo '</tr>';
					
				}
				
				echo '<tr>';
				echo '<td colspan="3"><hr align="right" size="1"></td>';
				echo '</tr>';
			}
			?>
            
            <tr>
              <td>&nbsp;</td>
              <td><div align="right">Sub Total: </div></td>
              <td><div align="right">$<?php echo $row['subtotal']; ?></div></td>
            </tr>
            <tr>
              <td>Thank you, we appreciate your business. </td>
              <td><div align="right">GST: </div></td>
              <td><div align="right">$<?php echo $row['GST']; ?></div></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td class="style1"><div align="right"><em>Total: </em></div></td>
              <td bgcolor="#CCCCCC" class="style1"><div align="right" class="style5">$<?php echo $row['totalBill']; ?></div></td>
            </tr>
        </table></td>
      </tr>
      <tr>
        <td colspan="2"><hr size="1"></td>
      </tr>
      <tr valign="top">
        <td><p align="left" class="style7">* All accounts are due 14 days from date of this invoice<br>
* Interest of 24%/annum (2%/month) will be charged on all overdue accounts<br>
* GST Number: 885460501</p>
          </td>
        <td><div align="right" class="style7">Pin Point Surveying Ltd.<br>
  P.O. Box 38, Salmon Arm, B.C. Canada, V1E 4N2<br>
  Office (250) 832-6220 | Fax (250) 832-0084<br>
  randy@pinpointsurveying.com | www.pinpointsurveying.com</div></td>
      </tr>
    </table>
<br><br><br>
<!--<div class="pageBreak">--!>
<div>

<span class="style1">Invoice Details:
</span>
<table width="100%"  border="0" cellpadding="2" cellspacing="2" class="tableborder">
		<tr class="tableheader">
			<td><strong>Date</strong></td>
			<td><strong>Type</strong></td>
			<td align="center"><strong>Time In</strong></td>
			<td align="center"><strong>Time Out</strong></td>
			<td align="center"><strong>Total Hours</strong></td>
			<td><strong>Description</strong></td>
		</tr>
<?php

$sql = "SELECT * 
		FROM `timerecords` 
		LEFT JOIN `descriptions` ON `timerecords`.`description_id` = `descriptions`.`description_id`
		WHERE `invoice_id` = '$row[invoice_id]' && `userType`='0' 
		ORDER BY `timerecord_date`,`timeIn` ASC";

$resultRecords = mysql_query ($sql);
if (!$resultRecords) {	echo("error performing query: " . mysql_error() . ""); exit(); }

if(mysql_num_rows($resultRecords)) {
	while($rowRecords = mysql_fetch_assoc ($resultRecords)) {
		
		echo "<tr>";
		echo "<td>$rowRecords[timerecord_date]</td>";
		echo "<td>$rowRecords[type]</td>";
		echo "<td align=\"center\" width=\"75\">$rowRecords[timeIn]</td>";
		echo "<td align=\"center\" width=\"75\">$rowRecords[timeOut]</td>";
		echo "<td align=\"center\" width=\"75\">$rowRecords[totalTime]</td>";
		echo "<td>$rowRecords[description] $rowRecords[extDescription]</td>";
		echo "</tr>";
	}
} else {
	echo "<tr class=\"table\">";
	echo "<td colspan=\"6\">No time records</td>";
	echo "</tr>";
}

?>
</table>
</div>
	</td>
  </tr>
</table>
</body>
</html>
		<?php
	}
} else {
	printMessage ("<b>Error</b>: No Invoice Selected!");
}
?>