<?
$result = mysql_query ("SELECT * FROM `invoices` WHERE `id`='$id'");
if (!$result) {	echo("error performing query: " . mysql_error() . ""); exit(); }

$row = mysql_fetch_row($result);

$createdBy = mysql_result (mysql_query ("SELECT `name` FROM `users` WHERE `id`='$row[2]'"), 0);

$jobNum = mysql_result (mysql_query ("SELECT `number` FROM `jobs` WHERE `job_id`='$row[4]'"), 0);
$jobTitle = mysql_result (mysql_query ("SELECT `title` FROM `jobs` WHERE `job_id`='$row[4]'"), 0);
$clientId = mysql_result (mysql_query ("SELECT `clientId` FROM `jobs` WHERE `job_id`='$row[4]'"), 0);
$client = mysql_result (mysql_query ("SELECT `company` FROM `clients` WHERE `client_id`='$row[3]'"), 0);

$fieldRate = mysql_result (mysql_query ("SELECT `fieldTimePrice` FROM `clients` WHERE `client_id`='$row[3]'"), 0);
$travelRate = mysql_result (mysql_query ("SELECT `travelTimePrice` FROM `clients` WHERE `client_id`='$row[3]'"), 0);
$officeRate = mysql_result (mysql_query ("SELECT `officeTimePrice` FROM `clients` WHERE `client_id`='$row[3]'"), 0);

$settingGST = mysql_result (mysql_query ("SELECT `value` FROM `settings` WHERE `key`='GST'"), 0);
?>

<form method="post" action="<?=$PHP_SELF?>" name="form" >
<input type="hidden" name="idx" value="invoices">
<input type="hidden" name="step" value="4">
<input type="hidden" name="act" value="edit">
<input type="hidden" name="id" value="<?=$row[0]?>">

<input type="hidden" name="invoiceNum" value="<?=$invoiceNum?>">
<input type="hidden" name="createdby" value="<?php echo $_SESSION["$site_session_prefix"]['session_userId']; ?>">
<input type="hidden" name="clientId" value="<?=$clientId?>">
<input type="hidden" name="jobId" value="<?=$jobId?>">
<input type="hidden" name="date" value="<?=$date?>">

<script language="JavaScript">
<!--
function formatNumber(x) {
	return (Math.round(x*Math.pow(10,2)))/Math.pow(10,2);
}
function calc(fieldRate, travelRate, officeRate) {
	fieldBill = formatNumber(document.form.fieldHours.value * fieldRate);
	travelBill = formatNumber(document.form.travelHours.value * travelRate);
	officeBill = formatNumber(document.form.officeHours.value * officeRate);
	
	SubTotal = formatNumber(fieldBill + travelBill + officeBill);
	GST = formatNumber(SubTotal * <?=$settingGST?>);
	totalBill = formatNumber(SubTotal + GST);
	
	document.form.fieldBill.value = fieldBill;
	document.form.travelBill.value = travelBill;
	document.form.officeBill.value = officeBill;
	
	document.form.SubTotal.value = SubTotal;
	document.form.GST.value = GST;
	document.form.totalBill.value = totalBill;
	
	
	return false;
}
//-->
</script>



<table width="100%" border="0" cellspacing="1" cellpadding="2">
  <tr>
    <td colspan="4" class="header">Edit Invoice</td>
  </tr>
  <tr>
    <td colspan="4" class="mainlight"><hr size="1" noshade></td>
  </tr>
  <tr>
    <td width="150" class="bodybold">Invoice Number</td>
    <td colspan="3"><?=$row[1]?></td>
  </tr>
    <tr>
    <td width="150" class="bodybold">Created By</td>
    <td colspan="3"><?=$createdBy?></td>
    </tr>
      <tr>
        <td class="bodybold">Job</td>
        <td colspan="3"># <?=$jobNum?> (<?=$jobTitle?> - <?=$client?>)</td>
      </tr>
      <tr>
        <td class="bodybold">Date</td>
        <td colspan="3"><?=$row[5]?></td>
      </tr>
      <tr>
        <td class="bodybold">Sent?</td>
        <td colspan="3"><select name="sent" id="sent" class="form">
          <option value="0" <? if ($row[15] == "0") { echo "selected"; } ?>>No</option>
          <option value="1" <? if ($row[15] == "1") { echo "selected"; } ?>>Yes</option>
        </select></td>
      </tr>
  <tr>
    <td colspan="4" class="mainlight"><hr size="1" noshade></td>
  </tr>
        <tr>
          <td class="bodybold">Field Hours <span class="required">*</span></td>
          <td><input name="fieldHours" type="text" class="form" id="fieldHours" value="<?=$row[6]?>" size="5" maxlength="14" onchange="calc(<?=$fieldRate?>,<?=$travelRate?>,<?=$officeRate?>);"></td>
          <td class="bodybold">Field Bill</td>
          <td>$
          <input name="fieldBill" type="text" class="form" id="fieldBill" size="8" maxlength="14" style="text-align: right;"></td>
        </tr>
        <tr>
          <td class="bodybold">Travel Hours  <span class="required">*</span></td>
          <td><input name="travelHours" type="text" class="form" id="travelHours" value="<?=$row[7]?>" size="5" maxlength="14" onchange="calc(<?=$fieldRate?>,<?=$travelRate?>,<?=$officeRate?>);"></td>
          <td class="bodybold">Travel Bill</td>
          <td>$
          <input name="travelBill" type="text" class="form" id="travelBill" size="8" maxlength="14" style="text-align: right;"></td>
        </tr>
        <tr>
          <td class="bodybold">Office Hours <span class="required">*</span></td>
          <td><input name="officeHours" type="text" class="form" id="officeHours" value="<?=$row[8]?>" size="5" maxlength="14" onchange="calc(<?=$fieldRate?>,<?=$travelRate?>,<?=$officeRate?>);"></td>
          <td class="bodybold">Office Bill</td>
          <td>$
          <input name="officeBill" type="text" class="form" id="officeBill" size="8" maxlength="14" style="text-align: right;"></td>
        </tr>
        <tr>
          <td class="bodybold">Field Rate </td>
          <td>$<?=$fieldRate?> /hour</td>
          <td class="bodybold">Sub Total</td>
          <td>$
          <input name="subtotal" type="text" class="form" id="SubTotal" size="8" maxlength="14" style="text-align: right;" readonly></td>
        </tr>
        <tr>
          <td class="bodybold">Travel Rate </td>
          <td>$<?=$travelRate?>
          /hour</td>
          <td class="bodybold">GST (<?=$settingGST?>)</td>
          <td>$
          <input name="GST" type="text" class="form" id="GST" size="8" maxlength="14" style="text-align: right;" readonly></td>
        </tr>
        <tr>
        <td class="bodybold">Office Rate</td>
        <td>$<?=$officeRate?>
          /hour</td>
        <td width="150" class="bodybold">Total</td>
        <td>$
          <input name="totalBill" type="text" class="form" id="totalBill" size="8" maxlength="14" style="text-align: right;" readonly></td>
      </tr>
	    <tr>
    <td colspan="4" class="mainlight"><hr size="1" noshade></td>
  </tr>
  <tr>
    <td class="required">* Required Fields</td>
    <td colspan="3" align="right"><input name="Submit" type="image" src="images/button_ok.gif" class="form" value="Submit">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="index.php?idx=<?=$idx?>"><img src="images/button_cancel.gif" border="0"></a></td>
  </tr>
</table>
</form>
<script language="javascript">
<!--
	calc(<?=$fieldRate?>,<?=$travelRate?>,<?=$officeRate?>);
//-->
</script>