<?php

if ($act == "add" ) {				// ####################### ADD #######################

	$error = false;
	
	$sql = "INSERT INTO `invoices` (
				`invoiceNum`,
				`createdby`,
				`client_id`,
				`job_id`,
				`invoice_date`,
				`fieldHours`,
				`fieldgpsHours`,
				`travelHours`,
				`officeHours`,
				`fieldBill`,
				`fieldgpsBill`,
				`travelBill`,
				`officeBill`,
				`subtotal`,
				`GST`,
				`totalBill`
			) VALUES (
				'$_POST[invoiceNum]',
				'$_POST[createdby]',
				'$_POST[client_id]',
				'$_POST[job_id]',
				'$_POST[invoice_date]',
				'$_POST[fieldHours]',
				'$_POST[fieldgpsHours]',
				'$_POST[travelHours]',
				'$_POST[officeHours]',
				'$_POST[fieldBill]',
				'$_POST[fieldgpsBill]',
				'$_POST[travelBill]',
				'$_POST[officeBill]',
				'$_POST[subtotal]',
				'$_POST[GST]',
				'$_POST[totalBill]'
			)";
			
	if (mysql_query($sql)) {
	
		// Get invoice id for timerecords
		$invoice_id = mysql_insert_id();
		
		###############################################
		### Update timerecords with invoice id
		###############################################

		if (!@mysql_query("UPDATE `timerecords` SET `invoice_id` = '$invoice_id' WHERE ((`job_id` = '$_POST[job_id]') && (`invoice_id` = '0'))")) {
			echo "Error Updating Job: " . mysql_error();
			$error = true;
		}
		

		###############################################
		### Insert invoice items
		###############################################		
		
		if (isset($_SESSION['invoice_items'])) {
			foreach($_SESSION['invoice_items'] as $name => $value) {

				$sql_insert_items = "INSERT INTO `invoice_items_join` (
						`invoice_id`,
						`name`,
						`price`,
						`quantity`
					) VALUES (
						'$invoice_id',
						'$name',
						'$value[price]',
						'$value[quantity]'
					)";

				if (!@mysql_query($sql_insert_items)) {
					echo "Error inserting invoice: " . mysql_error()."<br>";
					$error = true;
				}
			}
		}
	} else {
		$error = true;
		echo "Error inserting invoice: " . mysql_error()."<br>";
	}
	
	if ($error == false) {
		printMessage ("<a href=\"#\" onClick=\"javascript:viewInvoice('phplib/invoices/viewinvoice.php?id=$invoice_id')\">View Invoice $_POST[invoiceNum]</a>");
	}

}


if ($act == "edit" ) {				// ####################### EDIT #######################

	$invoice_id = $_SESSION['invoice']['invoice_id'];

	$error = false;
	//update invoice information(hours and cost)
	$sql = "UPDATE `invoices` SET 
				`fieldHours` 	= '$_POST[fieldHours]',
				`fieldgpsHours` = '$_POST[fieldgpsHours]',
				`travelHours` 	= '$_POST[travelHours]',
				`officeHours` 	= '$_POST[officeHours]',
				`fieldBill` 	= '$_POST[fieldBill]',
				`fieldgpsBill` 	= '$_POST[fieldgpsBill]',
				`travelBill` 	= '$_POST[travelBill]',
				`officeBill` 	= '$_POST[officeBill]',
				`subtotal` 		= '$_POST[subtotal]',
				`GST` 			= '$_POST[GST]',
				`totalBill` 	= '$_POST[totalBill]',
				`sent` 			= '$_POST[sent]' 
			WHERE `invoice_id` 	= '$invoice_id'";
			
	if (@mysql_query($sql)) {
		
		### Delete all previous invoice items
		if (@mysql_query ("DELETE FROM `invoice_items_join` WHERE `invoice_id`='$invoice_id'")) { 
		
			###############################################
			### Insert invoice items
			###############################################		
			
			if (isset($_SESSION['invoice_items'])) {
				foreach($_SESSION['invoice_items'] as $name => $value) {
	
					$sql_insert_items = "INSERT INTO `invoice_items_join` (
							`invoice_id`,
							`name`,
							`price`,
							`quantity`
						) VALUES (
							'$invoice_id',
							'$name',
							'$value[price]',
							'$value[quantity]'
						)";
	
					if (!@mysql_query($sql_insert_items)) {
						echo "Error inserting invoice: " . mysql_error()."<br>";
						$error = true;
					}
				}
			}
		} else {
			echo "Error deleting previous invoice items: " . mysql_error()."<br>";
			$error = true;
		}	
	} else {
		$error = true;
		echo "Error Updating Invoice: " . mysql_error();
	}
		
	if ($error == false) {
		printMessage ("<a href=\"#\" onClick=\"javascript:viewInvoice('phplib/invoices/viewinvoice.php?id={$_SESSION['invoice']['invoice_id']}')\">View Invoice $_POST[invoiceNum]</a>");
	}
}



if ($act == "sent" ) {				// ####################### SENT #######################

	$sql = "UPDATE `invoices` SET `sent`='1' WHERE `invoice_id` = '$_GET[id]'";
			
	if (@mysql_query($sql)) {
		printMessage("Invoice Successfully Marked as Sent");
	} else {
		printMessage("Error Updating Invoice: " . mysql_error() . "");
	}	
}

printMessage ("[ <a href=\"index.php?idx=$idx\">Go Back</a> ]");
?>