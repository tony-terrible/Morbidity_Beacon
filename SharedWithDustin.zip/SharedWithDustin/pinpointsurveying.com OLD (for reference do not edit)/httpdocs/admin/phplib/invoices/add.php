<?php
$checkJobs = mysql_fetch_row (mysql_query ("SELECT * FROM `jobs` WHERE `complete`='0' LIMIT 0,1"));
if ($checkJobs == "") { printMessage ("<b>Error</b>:  You cannot create an invoice without an incomplete job.");	exit(); }

$now = getdate();
$today = $now['year'] . "-" . $now['mon'] . "-" . $now['mday'];


$resultLI = mysql_query ("SELECT `invoiceNum` AS lastInvoiceNum FROM `invoices` ORDER BY `invoiceNum` DESC LIMIT 0,1");
if (!$resultLI) { echo("error performing query: " . mysql_error() . ""); exit(); }

if(mysql_num_rows($resultLI)) {
	while($rowLI = mysql_fetch_assoc($resultLI)) {
		extract($rowLI);
	}
} else {
	$lastInvoiceNum = 0;
}
$invoiceNum = $lastInvoiceNum + 1;
?>

<script language="JavaScript">
<!--
function checkForm(form) {
	if (document.form.invoiceNum.value == "") { alert ('Please enter an invoice number.'); document.form.invoiceNum.focus(); return false; }
	if (document.form.job_id.value == "") { alert ('Please select a job.'); document.form.job_id.focus(); return false; }
	if (document.form.invoice_date.value == "") { alert ('Please enter a date.'); document.form.invoice_date.focus(); return false; }
	else { return true; }
}
//-->
</script>

<form method="post" action="index.php" name="form">
<input type="hidden" name="idx" value="invoices">
<input type="hidden" name="step" value="3">
<input type="hidden" name="act" value="add">
<input type="hidden" name="createdby" value="<?php echo $_SESSION["$site_session_prefix"]['session_userId']; ?>">

<table width="100%" border="0" cellspacing="1" cellpadding="2">
  <tr>
    <td colspan="2" class="header">Create Invoice</td>
  </tr>
  <tr>
    <td colspan="2"><hr size="1" noshade></td>
  </tr>
  <tr>
    <td width="150">Invoice Number <span class="required">*</span></td>
    <td><input name="invoiceNum" type="text" class="form" id="invoiceNum" size="11" maxlength="11" value="<?php echo $invoiceNum; ?>"></td>
  </tr>
    <tr>
    <td width="150">Created By</td>
    <td><?php echo $_SESSION["$site_session_prefix"]['session_name']; ?></td>
    </tr>
      <tr>
        <td>Job <span class="required">*</span></td>
        <td><select name="job_id" id="job_id" class="form">
		<option value=""></option>
		<?php
		$sql = "SELECT *
				FROM `jobs`
				LEFT JOIN `clients` ON `jobs`.`client_id` = `clients`.`client_id`
				WHERE `complete`='0'
				ORDER BY `number` DESC";
		
		$resultjobId = mysql_query ($sql);
		if (!$resultjobId) { echo("error performing query: " . mysql_error() . ""); exit(); }
		
		if (mysql_num_rows($resultjobId)) {
			while ($rowjobId = mysql_fetch_assoc ($resultjobId)) {
			
				// Only show jobs with unbilled time records
				$resultCheckBilled = mysql_query ("SELECT * FROM `timerecords` WHERE ((`job_id` = '$rowjobId[job_id]') && (`invoice_id` = '0')) LIMIT 0,1");
				if (!$resultCheckBilled) {	echo("error performing query: " . mysql_error() . ""); exit(); }
				
				if (mysql_num_rows($resultCheckBilled)) {
				
					echo "<option value=\"$rowjobId[job_id]\">$rowjobId[number] - $rowjobId[title] - $rowjobId[company]</option>";
					
				}
			}
		}
		?>
        </select></td>
      </tr>
      <tr>
        <td>Date <span class="required">*</span></td>
        <td><script>DateInput('invoice_date', false, 'YYYY-MM-DD', '<?php echo $today; ?>')</script></td>
      </tr>
  <tr>
    <td colspan="2"><hr size="1" noshade></td>
  </tr>
  <tr>
    <td class="required">* Required Fields</td>
    <td align="right"><input name="Submit" type="image" src="images/button_ok.gif" class="form" value="Submit" onClick="return checkForm(this);">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="index.php?idx=<?=$idx?>"><img src="images/button_cancel.gif" border="0"></a></td>
  </tr>
</table>
</form>