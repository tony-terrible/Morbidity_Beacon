<?
$jobNum = mysql_result (mysql_query ("SELECT `number` FROM `jobs` WHERE `id`='$jobId'"), 0);
$jobTitle = mysql_result (mysql_query ("SELECT `title` FROM `jobs` WHERE `id`='$jobId'"), 0);
$clientId = mysql_result (mysql_query ("SELECT `clientId` FROM `jobs` WHERE `id`='$jobId'"), 0);
$client = mysql_result (mysql_query ("SELECT `company` FROM `clients` WHERE `id`='$clientId'"), 0);

$fieldRate = mysql_result (mysql_query ("SELECT `fieldTimePrice` FROM `clients` WHERE `id`='$clientId'"), 0);
$travelRate = mysql_result (mysql_query ("SELECT `travelTimePrice` FROM `clients` WHERE `id`='$clientId'"), 0);
$officeRate = mysql_result (mysql_query ("SELECT `officeTimePrice` FROM `clients` WHERE `id`='$clientId'"), 0);

$totalFieldHours = mysql_result (mysql_query ("SELECT SUM(`totaltime`) FROM `timerecords` WHERE `jobId`='$jobId' && `type`='1' && `userType`='0' && `invoiceId`='0'"), 0);
$totalTravelHours = mysql_result (mysql_query ("SELECT SUM(`totaltime`) FROM `timerecords` WHERE `jobId`='$jobId' && `type`='2' && `userType`='0' && `invoiceId`='0'"), 0);
$totalOfficeHours = mysql_result (mysql_query ("SELECT SUM(`totaltime`) FROM `timerecords` WHERE `jobId`='$jobId' && `type`='3' && `userType`='0' && `invoiceId`='0'"), 0);

$fieldBill = $fieldRate * $totalFieldHours;
$travelBill = $travelRate * $totalTravelHours;
$officeBill = $officeRate * $totalOfficeHours;

$settingGST = mysql_result (mysql_query ("SELECT `value` FROM `settings` WHERE `key`='GST'"), 0);
?>

<script language="JavaScript">
<!--
function formatAsMoney(mnt) {
    mnt -= 0;
    mnt = (Math.round(mnt*100))/100;
    return (mnt == Math.floor(mnt)) ? mnt + '.00' 
              : ( (mnt*10 == Math.floor(mnt*10)) ? 
                       mnt + '0' : mnt);
}

function calc(fieldRate, travelRate, officeRate) {
	fieldBill = document.form.fieldHours.value * fieldRate;
	travelBill = document.form.travelHours.value * travelRate;
	officeBill = document.form.officeHours.value * officeRate;
	
	SubTotal = fieldBill + travelBill + officeBill;
	

	
	GST = SubTotal * <?=$settingGST?>;
	totalBill = SubTotal + GST;
	
	fieldBillFormatted = formatAsMoney(fieldBill);
	travelBillFormatted = formatAsMoney(travelBill);
	officeBillFormatted = formatAsMoney(officeBill);
	
	SubTotalFormatted = formatAsMoney(SubTotal);
	GSTFormatted = formatAsMoney(GST);
	totalBillFormatted = formatAsMoney(totalBill);
	
	document.form.fieldBill.value = fieldBillFormatted;
	document.form.travelBill.value = travelBillFormatted;
	document.form.officeBill.value = officeBillFormatted;
	
	document.form.SubTotal.value = SubTotalFormatted;
	document.form.GST.value = GSTFormatted;
	document.form.totalBill.value = totalBillFormatted;

	return false;
}
//-->
</script>
<link href="../../styles.css" rel="stylesheet" type="text/css" />


<form method="post" action="index.php" name="form">
<input type="hidden" name="idx" value="invoices">
<input type="hidden" name="step" value="4">
<input type="hidden" name="act" value="add">
<input type="hidden" name="invoiceNum" value="<?=$invoiceNum?>">
<input type="hidden" name="createdby" value="<?=$session_userId?>">
<input type="hidden" name="client_id" value="<?=$client_id?>">
<input type="hidden" name="job_id" value="<?=$job_id?>">
<input type="hidden" name="invoice_date" value="<?=$invoice_date?>">

<table width="100%" border="0" cellspacing="1" cellpadding="2">
  <tr>
    <td colspan="4" class="header">Create Invoice</td>
  </tr>
  <tr>
    <td colspan="4"><hr size="1" noshade></td>
  </tr>
  <tr>
    <td width="150" class="bodybold">Invoice Number</td>
    <td colspan="3"><?=$invoiceNum?></td>
  </tr>
    <tr>
    <td width="150" class="bodybold">Created By</td>
    <td colspan="3"><?=$session_name?></td>
    </tr>
      <tr>
        <td class="bodybold">Job</td>
        <td colspan="3"><?=$jobNum?> (<?=$jobTitle?> - <?=$client?>)</td>
      </tr>
      <tr>
        <td class="bodybold">Date</td>
        <td colspan="3"><?=$date?></td>
      </tr>
  <tr>
    <td colspan="4"><hr size="1" noshade></td>
  </tr>
        <tr>
          <td class="subheader">Invoice Items </td>
          <td>&nbsp;</td>
          <td width="150" class="bodybold">&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td colspan="4" class="bodybold"><table width="100%" border="0" cellpadding="2" cellspacing="2" class="table_full_border">
            <tr>
              <td class="tableheader">Item</td>
              <td class="tableheader">Amount</td>
              <td class="tableheader">Quantity</td>
              <td class="tableheader">Total</td>
            </tr>
            <tr>
              <td>Field Hours <span class="required">*</span></td>
              <td>$
                <?=$fieldRate?>
/hour</td>
              <td><input name="fieldHours" type="text" class="form" id="fieldHours" value="<?=$totalFieldHours?>" size="5" maxlength="14" onchange="calc(<?=$fieldRate?>,<?=$travelRate?>,<?=$officeRate?>);" /></td>
              <td>$
              <input name="fieldBill" type="text" class="form" id="fieldBill" size="8" maxlength="14" style="text-align: right;" /></td>
            </tr>
            <tr>
              <td>Travel Hours <span class="required">*</span></td>
              <td>$
                <?=$travelRate?>
/hour</td>
              <td><input name="travelHours" type="text" class="form" id="travelHours" value="<?=$totalTravelHours?>" size="5" maxlength="14" onchange="calc(<?=$fieldRate?>,<?=$travelRate?>,<?=$officeRate?>);" /></td>
              <td>$
              <input name="travelBill" type="text" class="form" id="travelBill" size="8" maxlength="14" style="text-align: right;" /></td>
            </tr>
            <tr>
              <td>Office Hours <span class="required">*</span></td>
              <td>$
                <?=$officeRate?>
/hour</td>
              <td><input name="officeHours" type="text" class="form" id="officeHours" value="<?=$totalOfficeHours?>" size="5" maxlength="14" onchange="calc(<?=$fieldRate?>,<?=$travelRate?>,<?=$officeRate?>);" /></td>
              <td>$
              <input name="officeBill" type="text" class="form" id="officeBill" size="8" maxlength="14" style="text-align: right;" /></td>
            </tr>
            <tr>
              <td colspan="4"><hr size="1" noshade="noshade" /></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
            </tr>
            <tr>
              <td>
			  <select name="clientId" id="select" class="form">
			<?php
			$resultItems = mysql_query ("SELECT * FROM `invoice_items` ORDER BY `name` ASC");
			if (!$resultItems) {	echo("error performing query: " . mysql_error() . ""); exit(); }
			
			if (mysql_num_rows($resultItems)) {
				while($rowItems = mysql_fetch_assoc ($resultItems)) {
					echo "<option value=\"$rowItems[id]\">$rowItems[name] - $rowItems[price]</option>";
				}
			}
			?>
			</select>
			</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
            </tr>
            <tr>
              <td colspan="4"><hr size="1" noshade="noshade" /></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td><div align="right">SubTotal</div></td>
              <td>$
              <input name="SubTotal" type="text" class="form" id="SubTotal" size="8" maxlength="14" style="text-align: right;" readonly="readonly" /></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td><div align="right">GST</div></td>
              <td>$
              <input name="GST" type="text" class="form" id="GST" size="8" maxlength="14" style="text-align: right;" readonly="readonly" /></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td><div align="right">Total</div></td>
              <td>$
              <input name="totalBill" type="text" class="form" id="totalBill" size="8" maxlength="14" style="text-align: right;" readonly="readonly" /></td>
            </tr>
          </table></td>
        </tr>
	    <tr>
    <td colspan="4"><hr size="1" noshade></td>
  </tr>
  <tr>
    <td class="required">* Required Fields</td>
    <td colspan="3" align="right"><input name="Submit" type="image" src="images/button_ok.gif" class="form" value="Submit">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="index.php?idx=<?=$idx?>"><img src="images/button_cancel.gif" border="0"></a></td>
  </tr>
</table>
</form>
<script language="javascript">
<!--
	calc(<?=$fieldRate?>,<?=$travelRate?>,<?=$officeRate?>);
//-->
</script>
<br><br>
<span class="subHeader">Time Records in this Invoice</span><br><br>
<table width="100%"  border="0" cellpadding="2" cellspacing="2" class="tableborder">
		<tr class="tableheader">
			<td>Timesheet ID</td>
			<td>Date</td>
			<td>Job #</td>
			<td>Type</td>
			<td align="center">Time In</td>
			<td align="center">Time Out</td>
			<td align="center">Total Hours</td>
			<td>Description</td>
			<td>Employee</td>
		</tr>
<?php

$resultRecords = mysql_query ("SELECT * FROM `timerecords` WHERE ((`jobId`='$jobId') && (`invoiceId`='0') && (`userType`='0')) ORDER BY `date`,`timeIn` ASC");
if (!$resultRecords) {	echo("error performing query: " . mysql_error() . ""); exit(); }

if(mysql_num_rows($resultRecords)) {
	while($rowRecords = mysql_fetch_row($resultRecords)) {
		if ($rowcount == "1") { $bgclass = "class=\"tablealt\""; $rowcount = "0"; } else { $bgclass = "class=\"table\""; $rowcount++; }
		$jobNumber = mysql_result (mysql_query ("SELECT `number` FROM `jobs` WHERE `id`='$rowRecords[4]'"), 0);
		if ($rowRecords[5] == "1") { $typename = "Field"; } else if ($rowRecords[5] == "2") { $typename = "Travel"; } else if ($rowRecords[5] == "3") { $typename = "Office"; }
		$description = mysql_result (mysql_query ("SELECT `description` FROM `descriptions` WHERE `id`='$rowRecords[9]'"), 0);
		$employee = mysql_result (mysql_query ("SELECT `name` FROM `users` WHERE `id`='$rowRecords[2]'"), 0);
		if ($rowRecords[11] == "0") { $userType = "Crewcheif"; } else if ($rowRecords[11] == "1") { $userType = "Rodman"; }
		echo "<tr $bgclass>";
		echo "<td><a href=\"index.php?idx=timesheets&step=5&id=$rowRecords[1]\">$rowRecords[1]</a></td>";
		echo "<td>$rowRecords[3]</td>";
		echo "<td>$jobNumber</td>";
		echo "<td>$typename</td>";
		echo "<td align=\"center\" width=\"75\">$rowRecords[6]</td>";
		echo "<td align=\"center\" width=\"75\">$rowRecords[7]</td>";
		echo "<td align=\"center\" width=\"75\">$rowRecords[8]</td>";
		echo "<td>$description - $rowRecords[10]</td>";
		echo "<td>$employee ($userType)</td>";
		echo "</tr>";
	}
} else {
	echo "<tr class=\"table\">";
	echo "<td colspan=\"11\">No time records</td>";
	echo "</tr>";
}

?>
</table>