<script language="JavaScript">
<!--
function checkForm(form) {
	if (document.form.invoice_item_id.value == ""){ 
		alert ('No invoice items are available at this time.'); 			
		document.form.invoice_item_id.focus(); 		
		return false; 
	}
	
	if (document.form.quantity.value == ""){ 
		alert ('Please enter the quantity for the item before adding.'); 			
		document.form.quantity.focus(); 		
		return false; 
	}

	if (isNaN(document.form.quantity.value)){ 
		alert ('The quantity must be a number.'); 			
		document.form.quantity.focus(); 		
		return false; 
	}
	
	if ((document.form.quantity.value % 1) != 0){ 
		alert ('The quantity must be an integer.'); 			
		document.form.quantity.focus(); 		
		return false; 
	}	
	
	else { return true; }
}
// -->
</script>
<?php


###################################################
## Function : get_job_info
## Get job info, hourly rate, andclient information
###################################################

function get_job_info ($job_id, $invoice) {

	$invoice_info = array();

	############################
	## Job Information
	############################
	
	$result = mysql_query ("SELECT `title`,`number`,`client_id` FROM `jobs` WHERE `job_id` = '$job_id' LIMIT 0,1");
	if (!$result) { echo("error performing query: " . mysql_error() . ""); exit(); }
	
	if (mysql_num_rows($result)) {
		$_SESSION['invoice']['job'] = mysql_fetch_assoc ($result);
	}

	############################
	## Job Hours
	############################
	
	$result = mysql_query ("SELECT SUM(`totaltime`) AS `field` FROM `timerecords` WHERE `job_id` = '$job_id' && `type`='Field' && `userType`='0' && `invoice_id`='$invoice'");
	if (!$result) { echo("error performing query: " . mysql_error() . ""); exit(); }
	
	if (mysql_num_rows($result)) {
		$row = mysql_fetch_assoc ($result);
		$_SESSION['invoice']['job_hours']['field'] = $row['field'];
	}
	
	$result = mysql_query ("SELECT SUM(`totaltime`) AS `fieldgps` FROM `timerecords` WHERE `job_id` = '$job_id' && `type`='Field GPS' && `userType`='0' && `invoice_id`='$invoice'");
	if (!$result) { echo("error performing query: " . mysql_error() . ""); exit(); }
	
	if (mysql_num_rows($result)) {
		$row = mysql_fetch_assoc ($result);
		$_SESSION['invoice']['job_hours']['fieldgps'] = $row['fieldgps'];
	}		
	
	$result = mysql_query ("SELECT SUM(`totaltime`) AS `travel` FROM `timerecords` WHERE `job_id` = '$job_id' && `type`='Travel' && `userType`='0' && `invoice_id`='$invoice'");
	if (!$result) { echo("error performing query: " . mysql_error() . ""); exit(); }
	
	if (mysql_num_rows($result)) {
		$row = mysql_fetch_assoc ($result);
		$_SESSION['invoice']['job_hours']['travel'] = $row['travel'];
	}	
	
	$result = mysql_query ("SELECT SUM(`totaltime`) AS `office` FROM `timerecords` WHERE `job_id` = '$job_id' && `type`='Office' && `userType`='0' && `invoice_id`='$invoice'");
	if (!$result) { echo("error performing query: " . mysql_error() . ""); exit(); }
	
	if (mysql_num_rows($result)) {
		$row = mysql_fetch_assoc ($result);
		$_SESSION['invoice']['job_hours']['office'] = $row['office'];
	}		

	############################
	## Client Information
	############################
	
	$sql = "SELECT `client_id`,`company`,`fieldTimePrice`,`fieldgpsTimePrice`,`travelTimePrice`,`officeTimePrice` 
			FROM `clients`
			WHERE `client_id` = '{$_SESSION['invoice']['client_id']}'
			LIMIT 0,1";

	$result = mysql_query ($sql);
	if (!$result) { echo("error performing query: " . mysql_error() . ""); exit(); }
	
	if (mysql_num_rows($result)) {
		$_SESSION['invoice']['client'] = mysql_fetch_assoc ($result);
	}

	return $invoice_info;
}


### End get_job_info function



###################################################
## Function : update_invoice_session
## Get invoice information and place in sessions
###################################################

function update_invoice_session ($invoice_id,$invoiceNum,$createdby,$client_id,$job_id,$invoice_date,$fieldHours,$fieldgpsHours,$travelHours,$officeHours,$fieldBill,$fieldgpsBill,$travelBill,$officeBill,$subtotal,$invoice_items_total,$GST,$totalBill,$sent) {

	if (!empty($invoice_id)) 			{ $_SESSION['invoice']['invoice_id'] 			= $invoice_id; }
	if (!empty($invoiceNum)) 			{ $_SESSION['invoice']['invoiceNum'] 			= $invoiceNum; }
	if (!empty($createdby)) 			{ $_SESSION['invoice']['createdby'] 			= $createdby; }
	if (!empty($client_id)) 			{ $_SESSION['invoice']['client_id'] 			= $client_id; }
	if (!empty($job_id)) 				{ $_SESSION['invoice']['job_id'] 				= $job_id; }
	if (!empty($invoice_date))			{ $_SESSION['invoice']['invoice_date'] 			= $invoice_date; }
	
	if (!empty($fieldHours))			{ $_SESSION['invoice']['fieldHours'] 			= $fieldHours; }
	if (!empty($fieldgpsHours))			{ $_SESSION['invoice']['fieldgpsHours'] 		= $fieldgpsHours; }
	if (!empty($travelHours))			{ $_SESSION['invoice']['travelHours'] 			= $travelHours; }
	if (!empty($officeHours))			{ $_SESSION['invoice']['officeHours'] 			= $officeHours; }
	if (!empty($fieldBill))				{ $_SESSION['invoice']['fieldBill'] 			= $fieldBill; }
	if (!empty($fieldgpsBill))			{ $_SESSION['invoice']['fieldgpsBill'] 			= $fieldgpsBill; }
	if (!empty($travelBill))			{ $_SESSION['invoice']['travelBill'] 			= $travelBill; }
	if (!empty($officeBill))			{ $_SESSION['invoice']['officeBill'] 			= $officeBill; }
	
	if (!empty($subtotal))				{ $_SESSION['invoice']['subtotal'] 				= $subtotal; }
	
	if (!empty($invoice_items_total))	{ $_SESSION['invoice']['invoice_items_total'] 	= $invoice_items_total; }
	
	if (!empty($GST))					{ $_SESSION['invoice']['GST'] 					= $GST; }
	if (!empty($totalBill))				{ $_SESSION['invoice']['totalBill'] 			= $totalBill; }
	
	if (!empty($sent)) 					{ $_SESSION['invoice']['sent'] 					= $sent; }
	
}
### End update_invoice_session function



###################################################
## Edit Invoice
## Calls update_invoice_session and get_job_info 
## functions and prepares old invoice items to show
###################################################

if (isset($_GET['id'])) {																	### EDIT

	// get information and start session here
	$settingGST = mysql_result (mysql_query ("SELECT `value` FROM `settings` WHERE `key`='GST'"), 0);
	
	$result = mysql_query ("SELECT * FROM `invoices` WHERE `invoice_id` = '$_GET[id]'");
	if (!$result) { echo("error performing query: " . mysql_error() . ""); exit(); }
	
	if (mysql_num_rows($result)) {
		$row = mysql_fetch_assoc ($result);
		
		//Get all old invoice items from database
		$resultItems = mysql_query ("SELECT * FROM `invoice_items_join` WHERE `invoice_id` = '$row[invoice_id]'");
		if (!$resultItems) { echo("error performing query: " . mysql_error() . ""); exit(); }
		
		if (mysql_num_rows($resultItems)) {	
			while ($rowItems = mysql_fetch_assoc($resultItems)) {

				$_SESSION['invoice_items'][$rowItems['name']] = array (
					"price" 	=> $rowItems['price'],
					"quantity"	=> $rowItems['quantity']);
							
			}
		}	
	}
		
	update_invoice_session ("$row[invoice_id]",
							"$row[invoiceNum]",
							"$row[createdby]",
							"$row[client_id]",
							"$row[job_id]",
							"$row[invoice_date]",
							"$row[fieldHours]",
							"$row[fieldgpsHours]",
							"$row[travelHours]",
							"$row[officeHours]",
							"$row[fieldBill]",
							"$row[fieldgpsBill]",
							"$row[travelBill]",
							"$row[officeBill]",
							"$row[subtotal]",
							'',
							"$settingGST",
							"$row[totalBill]",
							"$row[sent]");
	
	$job_info = get_job_info("$row[job_id]", "$row[invoice_id]");

}

### End Edit Invoice

###################################################
## Add Invoice
## Calls update_invoice_session and get_job_info 
## functions and gets job and client info to create 
## new invoice
###################################################

if (isset($_POST['act']) && ($_POST['act'] == "add")) {										### ADD

	$settingGST = mysql_result (mysql_query ("SELECT `value` FROM `settings` WHERE `key`='GST'"), 0);
	
	$result_job = mysql_query ("SELECT * FROM `jobs` WHERE `job_id` = '$_POST[job_id]'");
	if (!$result_job) { echo("error performing query: " . mysql_error() . ""); exit(); }
	
	if (mysql_num_rows($result_job)) {
		$row_job = mysql_fetch_assoc($result_job);

		$result_client = mysql_query ("SELECT * FROM `clients` WHERE `client_id` = '$row_job[client_id]'");
		if (!$result_client) { echo("error performing query: " . mysql_error() . ""); exit(); }
		
		if (mysql_num_rows($result_client)) {
			$row_client =  mysql_fetch_assoc($result_client);
			
			update_invoice_session ('',
									"$_POST[invoiceNum]",
									"$_POST[createdby]",
									"$row_client[client_id]",
									"$_POST[job_id]",
									"$_POST[invoice_date]",
									"$row_client[fieldTimePrice]",
									"$row_client[fieldgpsTimePrice]",
									"$row_client[travelTimePrice]",
									"$row_client[officeTimePrice]",
									'',
									'',
									'',
									'',
									'',
									'',
									"$settingGST",
									'',
									'');
			
			
		}
	}
	
	$job_info = get_job_info("$_POST[job_id]", "0");

}
##End Add Invoice
############################################


############################################
## Invoice item steps (add, remove, update and delete old invoice items
############################################
// adding new invoice item

if (isset($_POST['Add']) && isset($_POST['invoice_item_id'])) {
	if (isset($_POST['quantity']) && !empty($_POST['quantity']) && is_numeric($_POST['quantity'])) {
		if ($_POST['quantity'] - floor($_POST['quantity']) == 0) {
			if (is_numeric($_POST['invoice_item_id'])) {
			
				$invoice_item_id = $_POST['invoice_item_id'];
				$invoice_item_qty = $_POST['quantity'];

				$resultAddItem = mysql_query ("SELECT `name`,`price` FROM `invoice_items` WHERE `invoice_item_id` = '$invoice_item_id'");
				
				if (mysql_num_rows($resultAddItem)) {
					$rowAddItem = mysql_fetch_assoc ($resultAddItem);
					
					$_SESSION['invoice_items'][$rowAddItem['name']] = array (
						"price" 	=> $rowAddItem['price'],
						"quantity"	=> $quantity);
					
				} else {
					$quantity_error = "Invalid invoice item ID passed.";
				}
			} else {
				$quantity_error = "Invalid invoice item ID passed.";
			}
		} else {
			$quantity_error = "Please provide a whole number when adding an item to an invoice.";
		}
	} else {
		$quantity_error = "Please enter a quantity.";
	}
}


// Update quantities
if (isset($_POST['update_item_quantity'])) {	
	foreach ($_POST['update_item_quantity'] as $name => $quantity) {
		if (is_numeric ($quantity)) {
			if ($quantity == 0) {
				unset ($_SESSION['invoice_items']["$name"]);
			} else {
				$_SESSION['invoice_items']["$name"]['quantity'] = $quantity;
			}
		} else {
			$quantity_error = "Quantity must be a whole number.";
		}
	}
}

### End invoice item steps



################################################
### Calculations
################################################

if (isset($_POST['fieldHours'])) {
	$fieldHours = $_POST['fieldHours'];
} else if (isset($_GET['fieldHours'])) {
	$fieldHours = $_GET['fieldHours'];
} else {
	$fieldHours = $_SESSION['invoice']['job_hours']['field'];
}

if (isset($_POST['fieldgpsHours'])) {
	$fieldgpsHours = $_POST['fieldgpsHours'];
} else if (isset($_GET['fieldgpsHours'])) {
	$fieldgpsHours = $_GET['fieldgpsHours'];
} else {
	$fieldgpsHours = $_SESSION['invoice']['job_hours']['fieldgps'];
}

if (isset($_POST['travelHours'])) {
	$travelHours = $_POST['travelHours'];
} else if (isset($_GET['travelHours'])) {
	$travelHours = $_GET['travelHours'];
} else {
	$travelHours = $_SESSION['invoice']['job_hours']['travel'];
}

if (isset($_POST['officeHours'])) {
	$officeHours = $_POST['officeHours'];
} else if (isset($_GET['officeHours'])) {
	$officeHours = $_GET['officeHours'];
} else {
	$officeHours = $_SESSION['invoice']['job_hours']['office'];
}

$fieldBill = $_SESSION['invoice']['client']['fieldTimePrice'] * $fieldHours;
$fieldgpsBill = $_SESSION['invoice']['client']['fieldgpsTimePrice'] * $fieldgpsHours;
$travelBill = $_SESSION['invoice']['client']['travelTimePrice'] * $travelHours;
$officeBill = $_SESSION['invoice']['client']['officeTimePrice'] * $officeHours;

$subtotal = $fieldBill+$fieldgpsBill+$travelBill+$officeBill;

### End Calculations
################################################

?>


<form method="post" action="index.php" name="form">
<input type="hidden" name="idx" value="invoices">
<input type="hidden" name="step" value="3">

<input type="hidden" name="act" value="<?php if (isset($act) && $act == "add") { echo $act; } else { echo "edit"; } ?>">

<input type="hidden" name="invoiceNum" value="<?php echo $_SESSION['invoice']['invoiceNum']; ?>">
<input type="hidden" name="createdby" value="<?php echo $_SESSION['invoice']['createdby']; ?>">
<input type="hidden" name="client_id" value="<?php echo $_SESSION['invoice']['client_id'];?>">
<input type="hidden" name="job_id" value="<?php echo $_SESSION['invoice']['job_id']; ?>">
<input type="hidden" name="invoice_date" value="<?php echo $_SESSION['invoice']['invoice_date']; ?>">


<table width="100%" border="0" cellspacing="1" cellpadding="2">
  <tr>
    <td colspan="2" class="header">Create Invoice</td>
  </tr>
  <tr>
    <td colspan="2"><hr size="1" noshade></td>
  </tr>
  <tr>
    <td width="150" class="bodybold">Invoice Number</td>
    <td><?php echo $_SESSION['invoice']['invoiceNum']; ?></td>
  </tr>
    <tr>
    <td width="150" class="bodybold">Created By</td>
    <td><?php echo $_SESSION["$site_session_prefix"]['session_name'];?></td>
    </tr>
      <tr>
        <td class="bodybold">Client</td>
        <td><?php if (isset($_SESSION['invoice']['client']['company'])) { echo $_SESSION['invoice']['client']['company']; } ?></td>
      </tr>
      <tr>
        <td class="bodybold">Job</td>
        <td><?php echo $_SESSION['invoice']['job']['number']; ?> (<?php echo $_SESSION['invoice']['job']['title']; ?> - <?php echo $_SESSION['invoice']['client']['company']; ?>)</td>
      </tr>
      <tr>
        <td class="bodybold">Invoice Date</td>
        <td><?php echo $_SESSION['invoice']['invoice_date']; ?></td>
      </tr>
      <tr>
        <td class="bodybold">Mark as Sent </td>
        <td><input type="checkbox" name="sent" value="1" /></td>
      </tr>
  <tr>
    <td colspan="2"><hr size="1" noshade></td>
  </tr>
	<tr>
	  <td class="subheader">Invoice Items </td>
	  <td>&nbsp;</td>
	</tr>
	<tr>
	  <td colspan="2" class="bodybold">
	  
	  
	  
		<?php
		#############################################
		### Show Invoice Items
		#############################################
		?>

		  <table width="100%" border="0" cellpadding="2" cellspacing="2" class="table_full_border">
            <tr>
              <td class="tableheader">Item</td>
              <td class="tableheader">Amount</td>
              <td class="tableheader">Quantity</td>
              <td class="tableheader">Total</td>
            </tr>
            <tr>
              <td>Field Hours <span class="required">*</span></td>
              <td>$ <?php echo $_SESSION['invoice']['client']['fieldTimePrice']; ?> / hour</td>
              <td><input name="fieldHours" type="text" class="form" id="fieldHours" value="<?php echo $fieldHours; ?>" size="5" maxlength="14" ></td>
              <td>$ <input name="fieldBill" type="text" class="form" id="fieldBill" size="8" maxlength="14" style="text-align: right;" value="<?php echo number_format($fieldBill, 2, '.', ''); ?>" readonly="readonly"/></td>
            </tr>
            <tr>
              <td>Field GPS Hours <span class="required">*</span></td>
              <td>$ <?php echo $_SESSION['invoice']['client']['fieldgpsTimePrice']; ?> / hour</td>
              <td><input name="fieldgpsHours" type="text" class="form" id="fieldgpsHours" value="<?php echo $fieldgpsHours; ?>" size="5" maxlength="14" ></td>
              <td>$ <input name="fieldgpsBill" type="text" class="form" id="fieldgpsBill" size="8" maxlength="14" style="text-align: right;" value="<?php echo number_format($fieldgpsBill, 2, '.', ''); ?>" readonly="readonly"/></td>
            </tr>            
            <tr>
              <td>Travel Hours <span class="required">*</span></td>
              <td>$ <?php echo $_SESSION['invoice']['client']['travelTimePrice']; ?> / hour</td>
              <td><input name="travelHours" type="text" class="form" id="travelHours" value="<?php echo $travelHours; ?>" size="5" maxlength="14"/></td>
              <td>$ <input name="travelBill" type="text" class="form" id="travelBill" size="8" maxlength="14" style="text-align: right;" value="<?php echo number_format($travelBill, 2, '.', ''); ?>" readonly="readonly"/></td>
            </tr>
            <tr>
              <td>Office Hours <span class="required">*</span></td>
              <td>$ <?php echo $_SESSION['invoice']['client']['officeTimePrice']; ?> / hour</td>
              <td><input name="officeHours" type="text" class="form" id="officeHours" value="<?php echo $officeHours; ?>" size="5" maxlength="14"/></td>
              <td>$ <input name="officeBill" type="text" class="form" id="officeBill" size="8" maxlength="14" style="text-align: right;" value="<?php echo number_format($officeBill, 2, '.', ''); ?>" readonly="readonly"/></td>
            </tr>
            <tr>
              <td colspan="4"><hr size="1" noshade="noshade" /></td>
            </tr>
			
			<?php
			###############################################
			### Display Invoice Items from session
			###############################################
			
			if (isset($_SESSION['invoice_items'])) {
				foreach($_SESSION['invoice_items'] as $name => $value) {
				
					$item_subtotal = $value['quantity'] * $value['price'];
					$item_subtotal_disp = number_format ($item_subtotal, 2, '.', '');
					$subtotal += $item_subtotal;
						
					echo '<tr>';
					echo "<td>$name</td>";
					echo "<td>$ $value[price] / each</td>";
					echo "<td><input name=\"update_item_quantity[$name]\" type=\"text\" class=\"form\" id=\"update_item_quantity[$name]\" size=\"5\" maxlength=\"14\" value=\"$value[quantity]\"></td>";
					echo "<td>$ <input name=\"items_total\" type=\"text\" class=\"form\" id=\"items_total\" size=\"8\" maxlength=\"14\" style=\"text-align: right;\" readonly=\"readonly\" value=\"$item_subtotal_disp\"/></td>";
					echo '</tr>';
					
				}
			}
			
			$tax = $subtotal * $_SESSION['invoice']['GST'];
			$total = $subtotal + $tax;
			?>
					
			<tr>
			  <td>
			  <select name="invoice_item_id" id="invoice_items_id" class="form">
				<?php
				$resultItems = mysql_query ("SELECT * FROM `invoice_items` ORDER BY `name` ASC");
				if (!$resultItems) { echo("error performing query: " . mysql_error() . ""); exit(); }
				
				$items_shown = FALSE;
				
				if (mysql_num_rows($resultItems)) {
					while($rowItems = mysql_fetch_assoc ($resultItems)) {
						if (!array_key_exists($rowItems['name'], $_SESSION['invoice_items'])) {
							echo "<option value=\"$rowItems[invoice_item_id]\">$rowItems[name] ($$rowItems[price] each)</option>";
							$items_shown = TRUE;
						}
					}
				}
				
				if (!$items_shown) { 
					echo '<option value="">No invoice items available</option>';
				}
				?>
			  </select>			  </td>
			  <td>&nbsp;</td>
			  <td><input name="quantity" type="text" class="form" id="quantity" size="5" maxlength="14"></td>
			  <td><input name="Add" type="submit" id="Add" value="Add Item"  class="form" onclick="return checkForm(this)"/></td>
			</tr>
			
			
			<?php
			// If javascript is disabled, this error will prevent the user from entering invalid values
			if (isset($quantity_error)) {
				echo '<tr>';
				echo "<td colspan=\"5\"><font color=\"#FF0000\">$quantity_error</font></td>";
			  	echo '</tr>'; 
			}
			?>
			  
			
            <tr>
              <td colspan="5"><hr size="1" noshade="noshade" /></td>
            </tr>
            <tr>
              <td colspan="2" rowspan="3"><div align="center"><input name="Update" type="submit" id="Update" value="Update Totals" class="form"/><br /><br />* Set quantity to 0 to delete invoice items</div></td>
              <td><div align="right">SubTotal</div></td>
              <td>$ <input name="subtotal" type="text" class="form" id="subtotal" size="8" maxlength="14" style="text-align: right;" readonly="readonly" value="<?php echo number_format($subtotal, 2, '.', ''); ?>" /></td>
            </tr>
            <tr>
              <td><div align="right">HST</div></td>
              <td>$ <input name="GST" type="text" class="form" id="GST" size="8" maxlength="14" style="text-align: right;" readonly="readonly" value="<?php echo number_format($tax, 2, '.', ''); ?>"/></td>
            </tr>
            <tr>
              <td><div align="right">Total</div></td>
              <td>$ <input name="totalBill" type="text" class="form" id="totalBill" size="8" maxlength="14" style="text-align: right;" readonly="readonly" value="<?php echo number_format($total, 2, '.', ''); ?>"/></td>
            </tr>
          </table>
		  
		<?php
		#############################################
		### End Show Invoice Items
		#############################################
		?>		  

		  
		  
		  
	  </td>
        </tr>
	    <tr>
    <td colspan="2"><hr size="1" noshade></td>
  </tr>
  <tr>
    <td class="required">* Required Fields</td>
    <td align="right"><input name="done" type="image" src="images/button_ok.gif" class="form" value="Submit">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="index.php?idx=<?=$idx?>"><img src="images/button_cancel.gif" border="0"></a></td>
  </tr>
  
</table>
</form>



<br><br>


<span class="subHeader">Time Records in this Invoice</span><br><br>


<table width="100%"  border="0" cellpadding="2" cellspacing="2" class="tableborder">
<tr class="tableheader">
    <td>Timesheet ID</td>
    <td>Date</td>
    <td>Job #</td>
    <td>Type</td>
    <td align="center">Time In</td>
    <td align="center">Time Out</td>
    <td align="center">Total Hours</td>
    <td>Description</td>
    <td>Employee</td>
</tr>
<?php
##########################################
##Show Appropriate time records
##########################################
$bgclass = "table";

if ($_SESSION['invoice']['invoice_id'] != "") {
	$invoice_id = $_SESSION['invoice']['invoice_id'];
} else {
	$invoice_id = "0";
}

$sql = "SELECT `timerecords`.*,
				`users`.`id`,
				`users`.`name`,
				`descriptions`.`description_id`,
				`descriptions`.`description`,
				`jobs`.`job_id`,
				`jobs`.`number`				
		FROM `timerecords` 
		LEFT JOIN `users` 				ON `timerecords`.`user_id` 				= `users`.`id`
		LEFT JOIN `descriptions` 		ON `timerecords`.`description_id` 		= `descriptions`.`description_id`
		LEFT JOIN `jobs` 				ON `timerecords`.`job_id` 				= `jobs`.`job_id`
		WHERE ((`jobs`.`job_id`='{$_SESSION['invoice']['job_id']}') && (`timerecords`.`invoice_id`='$invoice_id') && (`userType`='0')) 
		ORDER BY `timerecord_date`,`timeIn` ASC";

$resultRecords = mysql_query ($sql);
							   
if (!$resultRecords) {	echo("error performing query: " . mysql_error() . ""); exit(); }

if(mysql_num_rows($resultRecords)) {

	while($rowRecords = mysql_fetch_assoc($resultRecords)) {
	
		if ($bgclass == "table") { $bgclass = "tablealt";  } else { $bgclass = "table"; }
		
		//$description = mysql_result (mysql_query ("SELECT `description` FROM `descriptions` WHERE `description_id`='$rowRecords[description_id]'"), 0);
		//$employee = mysql_result (mysql_query ("SELECT `name` FROM `users` WHERE `id`='$rowRecords[user_id]'"), 0);
		
		echo "<tr class=\"$bgclass\">\n";
		echo "<td><a href=\"index.php?idx=timesheets&step=5&id=$rowRecords[timesheet_id]\">$rowRecords[timesheet_id]</a></td>\n";
		echo "<td>$rowRecords[timerecord_date]</td>\n";
		
		echo "<td>" . $rowRecords['number'] . "</td>\n";
		
		//echo mysql_result (mysql_query ("SELECT `number` FROM `jobs` WHERE `job_id`='$rowRecords[job_id]'"), 0);
		//echo '</td>';
		
		echo "<td>" . $rowRecords['type'] . "</td>\n";
		
		echo "<td align=\"center\" width=\"75\">$rowRecords[timeIn]</td>";
		echo "<td align=\"center\" width=\"75\">$rowRecords[timeOut]</td>";
		echo "<td align=\"center\" width=\"75\">$rowRecords[totalTime]</td>";
		
		echo "<td>$rowRecords[description] - $rowRecords[extDescription]</td>";
		
		echo "<td>$rowRecords[name] (";
		if ($rowRecords['userType'] == "0") { 
			echo "Crewchief)"; 
		} else if ($rowRecords['userType'] == "1") { 
			echo "Rodman)"; 
		}
		echo '</td>';
		
		echo "</tr>";
	}
	
} else {

	echo "<tr class=\"table\">";
	echo "<td colspan=\"11\">No time records</td>";
	echo "</tr>";
}

?>
</table>