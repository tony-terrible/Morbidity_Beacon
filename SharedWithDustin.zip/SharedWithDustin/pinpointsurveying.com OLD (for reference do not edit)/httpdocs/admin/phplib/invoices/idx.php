<?php
unset($_SESSION['invoice']);
unset($_SESSION['invoice_items']);

$_SESSION['invoice'] = array();

$oldestInvoiceYear = oldestYear(invoices,"invoice_date","");

$currentYear = date("Y");

if (!isset($invoicesYear) || !isset($invoicesMonth)) {
	$invoicesMonth = date("m");
	$invoicesYear = date("Y");
}
?>
<table width="100%"  border="0" cellspacing="2" cellpadding="2">
  <tr>
    <td class="header">Invoices</td>
<form method="post" action="index.php" name="invoicesDate">
<td class="main" align="right">
<input type="hidden" name="idx" value="invoices">
<select name="invoicesMonth" id="invoicesMonth" class="form">
  <option value="%" <? if ($invoicesMonth == "%") { echo "selected"; } ?>>All Months</option>
  <option value="01" <? if ($invoicesMonth == "01") { echo "selected"; } ?>>January</option>
  <option value="02" <? if ($invoicesMonth == "02") { echo "selected"; } ?>>February</option>
  <option value="03" <? if ($invoicesMonth == "03") { echo "selected"; } ?>>March</option>
  <option value="04" <? if ($invoicesMonth == "04") { echo "selected"; } ?>>April</option>
  <option value="05" <? if ($invoicesMonth == "05") { echo "selected"; } ?>>May</option>
  <option value="06" <? if ($invoicesMonth == "06") { echo "selected"; } ?>>June</option>
  <option value="07" <? if ($invoicesMonth == "07") { echo "selected"; } ?>>July</option>
  <option value="08" <? if ($invoicesMonth == "08") { echo "selected"; } ?>>August</option>
  <option value="09" <? if ($invoicesMonth == "09") { echo "selected"; } ?>>September</option>
  <option value="10" <? if ($invoicesMonth == "10") { echo "selected"; } ?>>October</option>
  <option value="11" <? if ($invoicesMonth == "11") { echo "selected"; } ?>>November</option>
  <option value="12" <? if ($invoicesMonth == "12") { echo "selected"; } ?>>December</option>
</select>
<select name="invoicesYear" id="invoicesYear" class="form">
<?php
for ($i = $currentYear; $i >= $oldestInvoiceYear; $i--) {
	if ($invoicesYear == $i) { $selected = "selected"; } else { $selected = ""; }
	echo "<option value=\"$i\" $selected>$i</option>";
}
?>
</select>
<input type="submit" name="Submit" value="Go" class="form"></td></form>
  </tr>
  <tr>
    <td colspan="2" class="submenu">[ <a href="index.php?idx=invoices&step=2">Create Invoice</a> | <a href="index.php?idx=invoice_items">Invoice Items</a> ] </td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="2" cellpadding="2">
  <tr class="tableheader">
    <td width="15">&nbsp;</td>
	<td width="15">&nbsp;</td>
	<td>id</td>
	<td>Date</td>
    <td>Invoice #</td>
    <td>Client</td>
    <td>Job #</td> 
	<td>Sent</td> 
    <td align="right">Total</td>
  </tr>
<?php

$sql = "SELECT *
		FROM `invoices`
		LEFT JOIN `clients` 	ON `invoices`.`client_id` 	= `clients`.`client_id`
		LEFT JOIN `jobs` 		ON `invoices`.`job_id` 		= `jobs`.`job_id`
		WHERE `invoice_date` LIKE '$invoicesYear-$invoicesMonth-%'
		ORDER BY `invoice_id` DESC";

$result = mysql_query ($sql);
if (!$result) {	echo("error performing query: " . mysql_error() . ""); exit(); }

if(mysql_num_rows($result)) {
	while($row = mysql_fetch_assoc ($result)) {

		if ($bgclass == "table") { $bgclass = "tablealt"; } else { $bgclass = "table"; }
		
		if ($row['sent'] == "0") {
			$sent = "No (<a href=\"index.php?idx=invoices&step=4&act=sent&id=$row[invoice_id]\" onclick=\"return confirm('Are you sure you want to mark this invoice as sent?');\">Sent</a>)";
		} else if ($row['sent'] == "1") {
			$sent = "Yes";
		}

		echo "<tr class=\"$bgclass\">";
		
		echo '<td width=\"16\">';
		echo "<a href=\"#\" onClick=\"javascript:viewInvoice('phplib/invoices/viewinvoice.php?id=$row[invoice_id]')\">";
		echo '<img src="images/_search.gif" border="0" alt="View"></a>';
		echo '</td>';
		echo "<td width=\"15\" align=\"center\">";
		if ($row['sent'] == "0") {
		echo "<a href=\"index.php?idx=invoices&step=3&id=$row[invoice_id]\">";
		echo "<img src=\"images/_edit.gif\" border=\"0\" alt=\"Edit\"></a>";
		} else {
			echo '&nbsp;';
		}
		
		echo '</td>';
		
		echo "<td>$row[invoice_id]</td>";
		echo "<td>$row[invoice_date]</td>";
		echo "<td>$row[invoiceNum]</td>";
		echo "<td><a href=\"index.php?idx=clients&step=4&id=$row[client_id]\">$row[company]</a></td>";
		echo "<td><a href=\"index.php?idx=jobs&step=4&id=$row[job_id]\">$row[number]</a></td>";
		echo "<td>$sent</td>";
		echo "<td align=\"right\">$$row[totalBill]</td>";
		echo "</tr>";
		
		$totalAmount = sprintf ("%01.2f", ($totalAmount + $row['totalBill']));
	}
	echo "<tr><td colspan=\"8\" align=\"right\"><b>Total:</b></td><td colspan=\"2\" align=\"right\"><b>$$totalAmount</b></td></tr>";
} else {
	print "<tr class=\"table\">";
	print "<td colspan=\"9\">No invoices found</td>";
	print "</tr>";
}           
?>
</table>
