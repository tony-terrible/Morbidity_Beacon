<?php


switch($step){
	case "1":									// index
		include("phplib/invoices/idx.php");
		break;
	case "2":									// add
		include("phplib/invoices/add.php");
		break;
	case "3":									// add1 - main form
		
			if (isset($_POST['done_x'])) {
				include("phplib/invoices/done.php");
			} else {
				include("phplib/invoices/add1.php");
			}
		
		break;
	case "4":									// done sent
		include("phplib/invoices/done.php");
		break;
	default:									// index
		include("phplib/invoices/idx.php");
		break;
}
?>