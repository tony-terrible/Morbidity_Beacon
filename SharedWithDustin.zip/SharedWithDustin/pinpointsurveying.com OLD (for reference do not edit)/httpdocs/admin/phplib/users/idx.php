<table width="100%"  border="0" cellspacing="2" cellpadding="2">
  <tr>
    <td class="header">Users</td>
  </tr>
  <tr>
    <td class="submenu">[ <a href="index.php?idx=users&step=2&act=add">Add User</a> ] </td>
  </tr>
</table>

<table width="100%" border="0" cellspacing="2" cellpadding="2">
  <tr class="tableheader">
    <td width="15">&nbsp;</td>
    <td>Name</td>
    <td>Username</td>
    <td>Email</td>
	<td>Hourly Wage</td>
	<td>Vac. Rate</td>
	<td>Active</td>
    <td width="15">&nbsp;</td>
  </tr>
  <?php

$result = mysql_query ("SELECT * FROM `users` ORDER BY `name` ASC");
if (!$result) {	echo("error performing query: " . mysql_error() . ""); exit(); }

$rowcount = "0";
$bgclass = "table";
if(mysql_num_rows($result)) {
	while($row = mysql_fetch_assoc($result)) {
	
		if ($bgclass == "table") { $bgclass = "tablealt"; } else { $bgclass = "table";}
		
		echo "<tr class=\"$bgclass\">";
		echo "<td width=\"15\" align=\"center\"><a href=\"index.php?idx=users&step=2&act=edit&id=$row[id]\"><img src=\"images/_edit.gif\" border=\"0\" alt=\"Edit $row[name]\"></a></td>";
		echo "<td>$row[name]</td>";
		echo "<td>$row[username]</td>";
		echo "<td><a href=\"mailto:$row[email]\" target=\"_blank\">$row[email]</a></td>";
		echo "<td>$$row[hourlyWage]</td>";
		echo "<td>$row[vacationRate]</td>";
		echo '<td>';
		if ($row['active'] == "1") {
			echo 'Yes';
		} else {
			echo 'No';
		}
		echo '</td>';
		echo "<td width=\"15\"><a href=\"index.php?idx=users&step=3&act=del&id=$row[id]\"><img src=\"images/x.gif\" border=\"0\" alt=\"Delete\" onclick=\"return confirmDelete();\"></a></td>";
		echo "</tr>";
		
	}
} else {
	echo "<tr bgcolor=\"#EEEEEE\" class=\"main\">";
	echo "<td colspan=\"5\"><div align=\"center\">No users in database</div></td>";
	echo "</tr>";
}           
?>
</table>
