<?php

$username = safehtml($username);
$password = safehtml($password);
$newPassword = safehtml($newPassword);
$confirmPassword = safehtml($confirmPassword);
$name = safehtml($name);
$email = safehtml($email);

if ($act == "add" ) {				// ####################### ADD #######################

	if ($newPassword != $confirmPassword) {
		printMessage ("Passwords did not match, please go back and try agian");
	} else if ($newPassword == $confirmPassword) {
	
		$password = md5($newPassword);
	
		$sql = "INSERT INTO `users` (
					`username`,
					`password`,
					`userlevel`,
					`name`,
					`email`,
					`hourlyWage`,
					`vacationRate`,
					`active`,
					`rodman`
				) VALUES (
					'$username',
					'$password',
					'$userlevel',
					'$name',
					'$email',
					'$hourlyWage',
					'$vacationRate',
					'$_POST[active]',
					'$_POST[rodman]'
				)";
			
		if (@mysql_query($sql)) {
			printMessage("User Successfully Added");
		} else {
			printMessage("Error Adding User: " . mysql_error() . "");
		}
	}
}


if ($act == "edit" ) {				// ####################### EDIT #######################

	if ((!empty($newPassword)) && ($newPassword != $confirmPassword)) {
		printMessage ("Passwords did not match, please go back and try again");
	} else {
		if ((!empty($newPassword)) && ($newPassword == $confirmPassword)) {
			$password = md5($newPassword);
		}
		
		$sql = "UPDATE `users` SET `username`='$username',
					`password`='$password',
					`userlevel`='$userlevel',
					`name`='$name',
					`email`='$email',
					`hourlyWage`='$hourlyWage',
					`vacationRate`='$vacationRate',
					`active`='$_POST[active]',
					`rodman`='$_POST[rodman]'
				 WHERE `id`='$id'";
			
		if (@mysql_query($sql)) {
			printMessage("User Successfully Updated");
		} else {
			printMessage("Error Updating User: " . mysql_error() . "");
		}	
	}
}


if ($act == "del" ) {				// ####################### DEL #######################

	$checktimerecords = mysql_fetch_row (mysql_query ("SELECT * FROM `timerecords` WHERE `user_id`='$_GET[id]' LIMIT 0,1"));
	
	if ($checktimerecords != "") {
		printMessage ("<b>Error</b>:  You cannot delete a user with time records.");
	} else {

		$sql = "DELETE FROM `users` WHERE `id`='$id'";
	
		if (@mysql_query($sql)) { 
			printMessage("User Successfully Deleted");
		} else {
			printMessage("Error Deleting User: " . mysql_error() . "");
		}
		
	}
}

printMessage ("[ <a href=\"index.php?idx=$idx\">Go Back</a> ]");
?>