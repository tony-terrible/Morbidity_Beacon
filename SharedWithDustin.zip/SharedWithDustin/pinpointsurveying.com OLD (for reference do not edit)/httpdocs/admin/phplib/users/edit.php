<script language="JavaScript">
<!--
function checkForm(form) {
	if (document.form.name.value == "") 			{ alert ('Please enter a name.'); 				document.form.name.focus(); 			return false; }
	if (document.form.username.value == "") 		{ alert ('Please enter a username.'); 			document.form.username.focus(); 		return false; }
	if (document.form.hourlyWage.value == "") 		{ alert ('Please enter a hourly wage.'); 		document.form.hourlyWage.focus(); 		return false; }
	if (document.form.vacationRate.value == "") 	{ alert ('Please enter a vacation rate.'); 		document.form.vacationRate.focus(); 	return false; }
	<?php if ($act == "add") { ?>
	if (document.form.newPassword.value == "") 		{ alert ('Please enter a new password.'); 		document.form.newPassword.focus(); 		return false; }
	if (document.form.confirmPassword.value == "") 	{ alert ('Please confirm the password.'); 		document.form.confirmPassword.focus(); 	return false; }
	<?php } ?>
	else { return true; }
}
//-->
</script>
<?php if ($act == "edit") { 

$result = mysql_query ("SELECT * FROM `users` WHERE id=$id");
if (!$result) {	echo("error performing query: " . mysql_error() . ""); exit(); }

$row = mysql_fetch_assoc($result);

?>

<form method="post" action="index.php" name="form">
<input type="hidden" name="idx" value="users">
<input type="hidden" name="step" value="3">
<input type="hidden" name="act" value="edit">
<input type="hidden" name="id" value="<?php echo $row['id']; ?>">
<input type="hidden" name="password" value="<?php echo $row['password']; ?>">

<?php } else { ?>

<form method="post" action="index.php" name="form">
<input type="hidden" name="idx" value="users">
<input type="hidden" name="step" value="3">
<input type="hidden" name="act" value="add">
	
<?php } ?>

	
	<table width="100%" border="0" cellspacing="1" cellpadding="2">
      <tr>
        <td colspan="3" class="header">User Editor</td>
      </tr>
      <tr>
        <td colspan="3" class="mainlight"><hr size="1" noshade></td>
      </tr>
      <tr>
        <td width="150" colspan="2" class="mainlight">Name <span class="required">*</span></td>
        <td><input name="name" type="text" class="form" size="25" maxlength="25" <?php if ($act == "edit") { print "value=\"$row[name]\""; } ?>></td>
      </tr>
      <tr>
        <td width="150" colspan="2" class="mainlight">Username <span class="required">*</span></td>
        <td><input name="username" type="text" class="form" size="25" maxlength="25" <?php if ($act == "edit") { print "value=\"$row[username]\""; } ?>></td>
      </tr>
      <tr>
        <td width="150" colspan="2" class="mainlight">Email</td>
        <td><input name="email" type="text" class="form" size="50" maxlength="50" <?php if ($act == "edit") { print "value=\"$row[email]\""; } ?>></td>
      </tr>
      <tr>
        <td width="100" class="mainlight">Hourly Wage <span class="required">*</span></td>
        <td width="50" class="mainlight"><div align="right">$</div></td>
        <td><input name="hourlyWage" type="text" class="form" id="hourlyWage" size="8" maxlength="8" <?php if ($act == "edit") { print "value=\"$row[hourlyWage]\""; } ?>></td>
      </tr>
      <tr>
        <td colspan="2" class="mainlight">Vacation Rate <span class="required">*</span></td>
        <td><input name="vacationRate" type="text" class="form" id="vacationRate" value="0.04" size="8" maxlength="8" <?php if ($act == "edit") { print "value=\"$row[vacationRate]\""; } ?>></td>
      </tr>
      <tr>
        <td colspan="2" class="mainlight">&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
<?php if ($act == "edit") { ?>
      <tr>
        <td colspan="2" class="mainlight">Current Password:</td>
        <td><input name="password" type="password" class="form" size="12" maxlength="12" <?php if ($act == "edit") { print "value=\"$row[password]\""; } ?> disabled></td>
      </tr>
<?php } ?>
      <tr>
        <td colspan="2" class="mainlight">New Password<?php if ($act == "add") { ?> <span class="required">*</span><?php } ?></td>
        <td><input name="newPassword" type="password" class="form" size="12" maxlength="12"></td>
      </tr>
      <tr>
        <td colspan="2" class="mainlight">Confirm Password<?php if ($act == "add") { ?> <span class="required">*</span><?php } ?></td>
        <td><input name="confirmPassword" type="password" class="form" size="12" maxlength="12"></td>
      </tr>
      <tr>
        <td colspan="2" class="mainlight">&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
	  <tr>
        <td colspan="2" class="mainlight">Active</td>
        <td><select name="active" class="form">
          <option value="0" <?php if ($act == "edit" && $row['active'] == "0") { print "selected"; } ?>>No</option>
          <option value="1" <?php if ($act == "edit" && $row['active'] == "1") { print "selected"; } ?>>Yes</option>
        </select></td>
      </tr>
      <tr>
        <td colspan="2" class="mainlight">User Level</td>
        <td><select name="userlevel" class="form">
          <option value="0" <?php if ($act == "edit" && $row['userlevel'] == "0") { print "selected"; } ?>>Admin</option>
          <option value="1" <?php if ($act == "edit" && $row['userlevel'] == "1") { print "selected"; } ?>>User</option>
        </select></td>
      </tr>
	  <tr>
        <td colspan="2" class="mainlight">Show As Rodman</td>
        <td><input name="rodman" type="checkbox" value="1" <?php if ($act == "edit" && $row['rodman'] == "1") { echo "checked"; } ?>/></td>
      </tr>
      <tr>
        <td colspan="3" class="mainlight"><hr size="1" noshade></td>
      </tr>
      <tr>
        <td colspan="2" class="required">* Required Fields</td>
        <td align="right"><input name="Submit" type="image" src="images/button_ok.gif" class="form" value="Submit" onClick="return checkForm(this);">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="index.php?idx=<?php echo $idx; ?>"><img src="images/button_cancel.gif" border="0"></a></td>
      </tr>
</table>
