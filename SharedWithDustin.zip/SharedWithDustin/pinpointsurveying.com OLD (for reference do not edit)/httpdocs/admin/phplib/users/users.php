<?php
switch($step){
	case "1":									// index
		include("phplib/users/idx.php");
		break;
	case "2":									// add/edit
		include("phplib/users/edit.php");
		break;
	case "3":									// done
		include("phplib/users/done.php");
		break;
	default:									// index
		include("phplib/users/idx.php");
		break;
}
?>