<script language="JavaScript">
<!--
function checkForm(form) {
	if (document.form.company.value == "") 					{ alert ('Please enter a company.'); 					document.form.company.focus(); 					return false; }
	if (document.form.fieldTimePrice.value == "") 			{ alert ('Please enter a Field Time Price.'); 			document.form.fieldTimePrice.focus(); 			return false; }
	if (document.form.fieldgpsTimePrice.value == "") 		{ alert ('Please enter a Field GPS Time Price.'); 		document.form.fieldgpsTimePrice.focus(); 		return false; }
	if (document.form.travelTimePrice.value == "") 			{ alert ('Please enter a Travel Time Price.'); 			document.form.travelTimePrice.focus(); 			return false; }
	if (document.form.officeTimePrice.value == "") 			{ alert ('Please enter a Office Time Price.'); 			document.form.officeTimePrice.focus(); 			return false; }
	else { return true; }
}
//-->
</script>
<?php

if ($act == "edit") { 

$result = mysql_query ("SELECT * FROM `clients` WHERE `client_id` = '$_GET[id]'");
if (!$result) {	echo("error performing query: " . mysql_error() . ""); exit(); }

$row = mysql_fetch_assoc ($result);

?>

<form method="post" action="index.php" name="form">
<input type="hidden" name="idx" value="clients">
<input type="hidden" name="step" value="3">
<input type="hidden" name="act" value="edit">
<input type="hidden" name="id" value="<?php echo $row['client_id']; ?>">

<?php } else { ?>

<form method="post" action="index.php" name="form">
<input type="hidden" name="idx" value="clients">
<input type="hidden" name="step" value="3">
<input type="hidden" name="act" value="add">
	
<?php } ?>

	
	<table width="100%" border="0" cellspacing="1" cellpadding="2">
      <tr>
        <td colspan="2" class="header">Client Editor</td>
      </tr>
      <tr>
        <td colspan="2"><hr size="1" noshade></td>
      </tr>
      <tr>
        <td width="150">Company <span class="required">*</span></td>
        <td><input name="company" type="text" class="form" id="company" size="60" maxlength="255" <?php if ($act == "edit") { echo "value=\"$row[company]\""; } ?>></td>
      </tr>
      <tr>
        <td width="150">Contact</td>
        <td><input name="contact" type="text" class="form" id="contact" size="60" maxlength="255" <?php if ($act == "edit") { echo "value=\"$row[contact]\""; } ?>></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>Address 1 </td>
        <td><input name="address1" type="text" class="form" id="address1" size="60" maxlength="255" <?php if ($act == "edit") { echo "value=\"$row[address1]\""; } ?>></td>
      </tr>
      <tr>
        <td>Address 2 </td>
        <td><input name="address2" type="text" class="form" id="address2" size="60" maxlength="255" <?php if ($act == "edit") { echo "value=\"$row[address2]\""; } ?>></td>
      </tr>
      <tr>
        <td>City</td>
        <td><input name="city" type="text" class="form" id="city" size="60" maxlength="255" <?php if ($act == "edit") { echo "value=\"$row[city]\""; } ?>></td>
      </tr>
      <tr>
        <td>Province/State</td>
        <td><input name="province_state" type="text" class="form" id="province_state" size="2" maxlength="2" <?php if ($act == "edit") { echo "value=\"$row[province_state]\""; } ?>></td>
      </tr>
      <tr>
        <td>Postal Code/Zip Code </td>
        <td><input name="postal_zip" type="text" class="form" id="postal_zip" size="8" maxlength="8" <?php if ($act == "edit") { echo "value=\"$row[postal_zip]\""; } ?>></td>
      </tr>
      <tr>
        <td>Country</td>
        <td><input name="country" type="text" class="form" id="country" size="60" maxlength="255" <?php if ($act == "edit") { echo "value=\"$row[country]\""; } ?>></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>Phone 1 </td>
        <td><input name="phone1" type="text" class="form" id="phone1" size="14" maxlength="14" <?php if ($act == "edit") { echo "value=\"$row[phone1]\""; } ?>></td>
      </tr>
      <tr>
        <td>Phone 2 </td>
        <td><input name="phone2" type="text" class="form" id="phone2" size="14" maxlength="14" <?php if ($act == "edit") { echo "value=\"$row[phone2]\""; } ?>></td>
      </tr>
      <tr>
        <td>Fax</td>
        <td><input name="fax" type="text" class="form" id="fax" size="14" maxlength="14" <?php if ($act == "edit") { echo "value=\"$row[fax]\""; } ?>></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td width="150">Email</td>
        <td><input name="email" type="text" class="form" size="60" maxlength="255" <?php if ($act == "edit") { echo "value=\"$row[email]\""; } ?>></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>Field Time Price <span class="required">*</span></td>
        <td>$
          <input name="fieldTimePrice" type="text" class="form" id="fieldTimePrice" size="7" maxlength="7" <?php if ($act == "edit") { echo "value=\"$row[fieldTimePrice]\""; } ?>></td>
      </tr>
      <tr>
        <td>Field GPS Time Price <span class="required">*</span></td>
        <td>$
          <input name="fieldgpsTimePrice" type="text" class="form" id="fieldgpsTimePrice" size="7" maxlength="7" <?php if ($act == "edit") { echo "value=\"$row[fieldgpsTimePrice]\""; } ?>></td>
      </tr>      
      <tr>
        <td>Travel Time Price <span class="required">*</span></td>
        <td>$
          <input name="travelTimePrice" type="text" class="form" id="travelTimePrice" size="7" maxlength="7" <?php if ($act == "edit") { echo "value=\"$row[travelTimePrice]\""; } ?>></td>
      </tr>
      <tr>
        <td>Office Time Price <span class="required">*</span></td>
        <td>$
          <input name="officeTimePrice" type="text" class="form" id="officeTimePrice" size="7" maxlength="7" <?php if ($act == "edit") { echo "value=\"$row[officeTimePrice]\""; } ?>></td>
      </tr>
      <tr>
        <td colspan="2"><hr size="1" noshade></td>
      </tr>
      <tr valign="top">
        <td class="required">* Required Fields </td>
        <td align="right"><input name="Submit" type="image" src="images/button_ok.gif" class="form" value="Submit" onclick="return checkForm(this);">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="index.php?idx=<?php=$idx?>"><img src="images/button_cancel.gif" border="0"></a></td>
      </tr>
</table>
