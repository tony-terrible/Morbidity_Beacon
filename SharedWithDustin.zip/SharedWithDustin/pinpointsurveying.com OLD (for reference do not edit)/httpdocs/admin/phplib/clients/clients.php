<?php
switch($step){
	case "1":									// index
		include("phplib/clients/idx.php");
		break;
	case "2":									// add/edit
		include("phplib/clients/edit.php");
		break;
	case "3":									// done
		include("phplib/clients/done.php");
		break;
	case "4":									// view
		include("phplib/clients/view.php");
		break;
	default:									// index
		include("phplib/clients/idx.php");
		break;
}
?>