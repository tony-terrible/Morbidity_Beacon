<table width="100%"  border="0" cellspacing="2" cellpadding="2">
  <tr>
    <td class="header">Clients</td>
    <td align="right">
		<table border="0" cellspacing="2" cellpadding="0">
		  <tr>
			<?php
			if (!isset($show)) { $show = "All"; }
			
			$alphabet = array('All','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z');
			while($rowAlph = each($alphabet)) {
				if ($rowAlph[1] == "All") { $width = "30"; } else { $width = "15"; }
				if ($rowAlph[1] == "$show") { 
					echo "<td class=\"alphTableOver\" width=\"$width\" align=\"center\">$rowAlph[1]</td>";
				} else {
					echo "<td class=\"alphTable\" onMouseOver=\"this.className='alphTableOver'\" onMouseOut=\"this.className='alphTable'\" ";
					echo "onClick=\"window.location.href='index.php?idx=clients&show=$rowAlph[1]'\" width=\"$width\" align=\"center\">$rowAlph[1]</td>";
				}
			}
			?>
		  </tr>
		</table>	
	</td>
  </tr>
  <tr>
    <td colspan="2" class="submenu">[ <a href="index.php?idx=clients&step=2&act=add">Add Client</a> ] </td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="2" cellpadding="2">
  <tr class="tableheader">
    <td width="15">&nbsp;</td>
	<td width="15">&nbsp;</td>
    <td>Company</td>
    <td>Contact</td>
    <td>Phone 1</td>
	<td># of Jobs</td>
	<td># of Invoices</td>
    <td width="15">&nbsp;</td>
  </tr>
<?php

if ($show == "All") {

	$sql = "SELECT * FROM `clients`	ORDER BY `company`";

} else {

	$sql = "SELECT * FROM `clients` WHERE `company` LIKE '$show%' ORDER BY `company` ASC";

}

$result = mysql_query ($sql);
if (!$result) {	echo("error performing query: " . mysql_error() . ""); exit(); }

if(mysql_num_rows($result)) {
	while($row = mysql_fetch_assoc($result)) {
		if ($bgclass == "table") { $bgclass = "tablealt"; } else { $bgclass = "table"; }

		$numJobs = mysql_num_rows (mysql_query ("SELECT `client_id` FROM `jobs` WHERE `client_id`='$row[client_id]'"));
		$numInvoices = mysql_num_rows (mysql_query ("SELECT `client_id` FROM `invoices` WHERE `client_id`='$row[client_id]'"));
		
		echo "<tr class=\"$bgclass\">";
		echo "<td width=\"15\"><a href=\"index.php?idx=clients&step=4&id=$row[client_id]\"><img src=\"images/_search.gif\" border=\"0\" alt=\"View\"></a></td>";
		echo "<td width=\"15\"><a href=\"index.php?idx=clients&step=2&act=edit&id=$row[client_id]\"><img src=\"images/_edit.gif\" border=\"0\" alt=\"Edit\"></a></td>";
		echo "<td>$row[company]</td>";
		echo "<td>$row[contact]</td>";
		echo "<td>$row[phone1]</td>";
		echo "<td>$numJobs</td>";
		echo "<td>$numInvoices</td>";
		echo "<td width=\"16\"><a href=\"javascript:confirmDelete('index.php?idx=clients&step=3&act=del&id=" . $row['client_id'] . "')\"><img src=\"images/x.gif\" border=\"0\" alt=\"Delete\"></a></td>";
		echo "</tr>";
		
	}
} else {
	echo "<tr bgcolor=\"#EEEEEE\" class=\"main\">";
	echo "<td colspan=\"8\"><div align=\"center\">No clients in database</div></td>";
	echo "</tr>";
}           
?>
</table>
