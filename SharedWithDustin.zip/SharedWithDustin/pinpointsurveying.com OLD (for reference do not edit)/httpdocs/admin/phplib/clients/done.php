<?php

if ($act == "add" ) {				// ####################### ADD #######################

	$sql = "INSERT INTO `clients` (
				`company`,
				`contact`,
				`address1`,
				`address2`,
				`city`,
				`province_state`,
				`postal_zip`,
				`country`,
				`phone1`,
				`phone2`,
				`fax`,
				`email`,
				`fieldTimePrice`,
				`fieldgpsTimePrice`,
				`travelTimePrice`,
				`officeTimePrice`
			) VALUES (
				'$_POST[company]',
				'$_POST[contact]',
				'$_POST[address1]',
				'$_POST[address2]',
				'$_POST[city]',
				'$_POST[province_state]',
				'$_POST[postal_zip]',
				'$_POST[country]',
				'$_POST[phone1]',
				'$_POST[phone2]',
				'$_POST[fax]',
				'$_POST[email]',
				'$_POST[fieldTimePrice]',
				'$_POST[fieldgpsTimePrice]',
				'$_POST[travelTimePrice]',
				'$_POST[officeTimePrice]'
			)";
		
	if (@mysql_query($sql)) {
		printMessage("Client Successfully Added");
	} else {
		printMessage("Error Adding Client: " . mysql_error() . "");
	}
}


if ($act == "edit" ) {				// ####################### EDIT #######################

	$sql = "UPDATE `clients` SET 
				`company`='$_POST[company]',
				`contact`='$_POST[contact]',
				`address1`='$_POST[address1]',
				`address2`='$_POST[address2]',
				`city`='$_POST[city]',
				`province_state`='$_POST[province_state]',
				`postal_zip`='$_POST[postal_zip]',
				`country`='$_POST[country]',
				`phone1`='$_POST[phone1]',
				`phone2`='$_POST[phone2]',
				`fax`='$_POST[fax]',
				`email`='$_POST[email]',
				`fieldTimePrice`='$_POST[fieldTimePrice]',
				`fieldgpsTimePrice`='$_POST[fieldgpsTimePrice]',
				`travelTimePrice`='$_POST[travelTimePrice]',
				`officeTimePrice`='$_POST[officeTimePrice]' 
			WHERE `client_id` = '$_POST[id]'";
		
	if (@mysql_query($sql)) {
		printMessage("Client Successfully Updated");
	} else {
		printMessage("Error Updating Client: " . mysql_error() . "");
	}	
}


if ($act == "del" ) {				// ####################### DEL #######################

	$checkJobs = mysql_fetch_row (mysql_query ("SELECT * FROM `jobs` WHERE `client_id` = '$_GET[id]' LIMIT 0,1"));
	if ($checkJobs != "") { printMessage ("<b>Error</b>:  You cannot delete a client with jobs.");	exit(); }

	$sql = "DELETE FROM `clients` WHERE `client_id`='$_GET[id]'";

	if (@mysql_query($sql)) { 
		printMessage("Client Successfully Deleted");
	} else {
		printMessage("Error Deleting Client: " . mysql_error() . "");
	}

}

printMessage ("[ <a href=\"index.php?idx=$idx\">Go Back</a> ]");
?>