<?php
$id = $_GET['id'];

$result = mysql_query ("SELECT * FROM `clients` WHERE `client_id`='$id'");
if (!$result) {	echo("error performing query: " . mysql_error() . ""); exit(); }

$row = mysql_fetch_assoc ($result);

$oldestJobYear = oldestYear(jobs,"startDate","`client_id`='$id'");
$oldestInvoiceYear = oldestYear(invoices,"invoice_date","`client_id`='$id'");
if ($oldestJobYear > $oldestInvoiceYear) { $oldestYear = $oldestInvoiceYear; } else { $oldestYear = $oldestJobYear; }
$currentYear = date("Y");

if (!isset($showYear) || !isset($showMonth)) {
	$showMonth = date("m");
	$showYear = date("Y");
}
?>
	<table width="100%" border="0" cellspacing="1" cellpadding="2">
      <tr>
        <td colspan="2" class="header">Client: <?php echo $row['company']; ?></td>
		<form method="get" action="index.php" name="showDate">
		<td class="main" align="right" colspan="2">
		<input type="hidden" name="idx" value="clients">
		<input type="hidden" name="step" value="4">
		<input type="hidden" name="id" value="<?php echo $id; ?>">
		<select name="showMonth" id="showMonth" class="form">
		  <option value="%" <? if ($showMonth == "%") { echo "selected"; } ?>>All Months</option>
		  <option value="01" <? if ($showMonth == "01") { echo "selected"; } ?>>January</option>
		  <option value="02" <? if ($showMonth == "02") { echo "selected"; } ?>>February</option>
		  <option value="03" <? if ($showMonth == "03") { echo "selected"; } ?>>March</option>
		  <option value="04" <? if ($showMonth == "04") { echo "selected"; } ?>>April</option>
		  <option value="05" <? if ($showMonth == "05") { echo "selected"; } ?>>May</option>
		  <option value="06" <? if ($showMonth == "06") { echo "selected"; } ?>>June</option>
		  <option value="07" <? if ($showMonth == "07") { echo "selected"; } ?>>July</option>
		  <option value="08" <? if ($showMonth == "08") { echo "selected"; } ?>>August</option>
		  <option value="09" <? if ($showMonth == "09") { echo "selected"; } ?>>September</option>
		  <option value="10" <? if ($showMonth == "10") { echo "selected"; } ?>>October</option>
		  <option value="11" <? if ($showMonth == "11") { echo "selected"; } ?>>November</option>
		  <option value="12" <? if ($showMonth == "12") { echo "selected"; } ?>>December</option>
		</select>
		<select name="showYear" id="showYear" class="form">
		<?php
		for ($i = $currentYear; $i >= $oldestYear; $i--) {
			if ($showYear == $i) { $selected = "selected"; } else { $selected = ""; }
			echo "<option value=\"$i\" $selected>$i</option>";
		}
		?>
		</select>
		<input type="submit" name="Submit" value="Go" class="form">
		</td></form>
      </tr>
      <tr>
        <td colspan="4"><hr size="1" noshade></td>
      </tr>
      <tr>
        <td width="150" class="bodybold">Contact</td>
        <td><?php echo $row['contact']; ?></td>
        <td class="bodybold">Address 1</td>
        <td><?php $row['address1']; ?></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td class="bodybold">Address 2</td>
        <td><?php $row['address2']; ?></td>
      </tr>
      <tr>
        <td class="bodybold">Phone 1</td>
        <td><?php echo $row['phone1']; ?></td>
        <td class="bodybold">City</td>
        <td><?php echo $row['city']; ?></td>
      </tr>
      <tr>
        <td class="bodybold">Phone 2 </td>
        <td><?php echo $row['phone2']; ?></td>
        <td class="bodybold">Province/State</td>
        <td><?php echo $row['province_state']; ?></td>
      </tr>
      <tr>
        <td class="bodybold">Fax</td>
        <td><?php echo $row['fax']; ?></td>
        <td class="bodybold">Postal Code/Zip Code</td>
        <td><?php echo $row['postal_zip']; ?></td>
      </tr>
      <tr>
        <td class="bodybold">Email</td>
        <td><?php echo $row['email']; ?></td>
        <td class="bodybold">Country</td>
        <td><?php echo $row['country']; ?></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td colspan="3">&nbsp;</td>
      </tr>
      <tr>
        <td class="bodybold">Field Time Price</td>
        <td colspan="3">$<?php echo $row['fieldTimePrice']; ?></td>
      </tr>
      <tr>
        <td class="bodybold">Field GPS Time Price</td>
        <td colspan="3">$<?php echo $row['fieldgpsTimePrice']; ?></td>
      </tr>      
      <tr>
        <td class="bodybold">Travel Time Price</td>
        <td colspan="3">$<?php echo $row['travelTimePrice']; ?></td>
      </tr>
      <tr>
        <td class="bodybold">Office Time Price</td>
        <td colspan="3">$<?php echo $row['officeTimePrice']; ?></td>
      </tr>
      <tr>
        <td colspan="4"><hr size="1" noshade></td>
      </tr>
      <tr valign="top">
        <td colspan="4"><table width="100%" border="0" cellspacing="2" cellpadding="2">
          <tr>
            <td class="subheader">Jobs</td>
            <td class="subheader">Invoices</td>
          </tr>
          <tr>
            <td width="50%" valign="top"><table width="100%"  border="0" cellpadding="2" cellspacing="2" class="tableborder">
              <tr class="tableheader">
                <td width="15">&nbsp;</td>
                <td width="15">&nbsp;</td>
                <td>Start Date</td>
				<td>Title</td>
                <td>Number</td>
                <td>Total Hours</td>
                <td width="15">&nbsp;</td>
              </tr>
<?php

$sql = "SELECT
			`jobs`.`job_id`,
			`jobs`.`title`,
			`jobs`.`number`,
			`jobs`.`startDate`,
			SUM(`timerecords`.`totalTime`) AS 'totaltime'
		FROM `jobs`
			LEFT JOIN `timerecords` ON `jobs`.`job_id` = `timerecords`.`job_id`
		WHERE `client_id`='$id' && `startDate` LIKE '$showYear-$showMonth-%'
		GROUP BY `job_id`
		ORDER BY `startDate` DESC, `number` DESC";

$resultJobs = mysql_query ($sql);
if (!$resultJobs) {	echo("error performing query: " . mysql_error() . ""); exit(); }

if(mysql_num_rows($resultJobs)) {
	while($rowJobs = mysql_fetch_assoc ($resultJobs)) {
		if ($rowcount == "1") { $bgclass = "class=\"tablealt\""; $rowcount = "0"; } else { $bgclass = "class=\"table\""; $rowcount++; }

		//$totaltimesum = mysql_result (mysql_query ("SELECT SUM(`totaltime`) FROM `timerecords` WHERE `jobId`='$rowJobs[0]'"), 0);

		echo "<tr $bgclass>";
		echo "<td width=\"15\"><a href=\"index.php?idx=jobs&step=4&id=$rowJobs[job_id]\"><img src=\"images/_search.gif\" border=\"0\" alt=\"View\"></a></td>";
		echo "<td width=\"15\"><a href=\"index.php?idx=jobs&step=2&act=edit&id=$rowJobs[job_id]\"><img src=\"images/_edit.gif\" border=\"0\" alt=\"Edit\"></a></td>";
		echo "<td class=\"main\">$rowJobs[startDate]</td>";
		echo "<td class=\"main\">$rowJobs[title]</td>";
		echo "<td class=\"main\">$rowJobs[number]</td>";
		echo "<td class=\"main\">$rowJobs[totaltime]</td>";
		echo "<td width=\"15\"><a href=\"index.php?idx=jobs&step=3&act=del&id=$rowJobs[job_id]\"><img src=\"images/x.gif\" border=\"0\" alt=\"Delete\"></a></td>";
		echo "</tr>";
	}
} else {
	print "<tr class=\"table\">";
	print "<td colspan=\"7\">No jobs in database</td>";
	print "</tr>";
}

?>
            </table></td>
            <td width="50%" valign="top"><table width="100%"  border="0" cellpadding="2" cellspacing="2" class="tableborder">
              <tr class="tableheader">
                <td width="15">&nbsp;</td>
                <td width="15">&nbsp;</td>
				<td>Date</td>
                <td>Invoice #</td>
                <td>Job #</td>
                <td align="right">Invoice Amount</td>
              </tr>
<?php

$sql = "SELECT *
		FROM `invoices`
			LEFT JOIN `jobs` ON `invoices`.`job_id` = `jobs`.`job_id`
		WHERE `invoices`.`client_id`='$id' && `invoices`.`invoice_date` LIKE '$showYear-$showMonth-%'
		ORDER BY `invoice_id` DESC

";
			  
$resultInvoices = mysql_query ($sql);
if (!$resultInvoices) {	echo("error performing query: " . mysql_error() . ""); exit(); }

$rowcount = "0";

if(mysql_num_rows($resultInvoices)) {
	while($rowInvoices = mysql_fetch_assoc ($resultInvoices)) {
		
		if ($rowcount == "1") { $bgclass = "class=\"tablealt\""; $rowcount = "0"; } else { $bgclass = "class=\"table\""; $rowcount++; }
		
		echo "<tr $bgclass>";
		echo "<td width=\"15\"><a href=\"#\" onClick=\"javascript:viewInvoice('phplib/invoices/viewinvoice.php?id=$rowInvoices[invoice_id]')\">";
		echo "<img src=\"images/_search.gif\" border=\"0\" alt=\"View\"></a></td>";
		
		if ($row['sent'] == "0") {
			echo "<td width=\"15\"><a href=\"index.php?idx=invoices&step=3&id=$rowInvoices[invoice_id]\"><img src=\"images/_edit.gif\" border=\"0\" alt=\"Edit\"></a></td>";
		} else {
			echo '<td width=\"15\">&nbsp;</td>';
		}

		echo "<td class=\"main\">$rowInvoices[invoice_date]</td>";
		echo "<td class=\"main\">$rowInvoices[invoiceNum]</td>";
		echo "<td class=\"main\">$rowInvoices[number]</td>";
		echo "<td class=\"main\" align=\"right\">$$rowInvoices[totalBill]</td>";
		echo "</tr>";
		$totalAmount = sprintf("%01.2f", ($totalAmount + $rowInvoices['totalBill']));
	}
	echo "<tr><td colspan=\"5\" align=\"right\"><b>Total:</b></td><td colspan=\"2\" align=\"right\"><b>$$totalAmount</b></td></tr>";
} else {
	echo "<tr class=\"table\">";
	echo "<td colspan=\"6\">No invoices in database</td>";
	echo "</tr>";
}

?>
            </table></td>
          </tr>
        </table></td>
</tr>
</table>
