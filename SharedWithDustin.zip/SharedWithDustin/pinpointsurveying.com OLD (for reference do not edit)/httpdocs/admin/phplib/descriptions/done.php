<?php

$description = safehtml($description);

if ($act == "add" ) {				// ####################### ADD #######################

	$sql = "INSERT INTO `descriptions` (
				`description`
			) VALUES (
				'$description'
			)";
		
	if (@mysql_query($sql)) {
		printMessage("Description Successfully Added");
	} else {
		printMessage("Error Adding Description: " . mysql_error() . "");
	}
}

if ($act == "edit" ) {				// ####################### EDIT #######################

	$sql = "UPDATE `descriptions` SET `description`='$description' WHERE `description_id` = '$_POST[id]'";
			
	if (@mysql_query($sql)) {
		printMessage("Description Successfully Updated");
	} else {
		printMessage("Error Updating Description: " . mysql_error() . "");
	}	
}

if ($act == "del" ) {				// ####################### DEL #######################

	$check = mysql_fetch_row (mysql_query ("SELECT * FROM `timerecords` WHERE `description_id` = '$_GET[id]' LIMIT 0,1"));
	if ($check != "") { printMessage ("<b>Error</b>:  You cannot delete a description that is being used."); exit(); }

	$sql = "DELETE FROM `descriptions` WHERE `description_id`='$_GET[id]'";

	if (@mysql_query($sql)) { 
		printMessage("Description Successfully Deleted");
	} else {
		printMessage("Error Deleting Description: " . mysql_error() . "");
	}
}

printMessage ("[ <a href=\"index.php?idx=$idx\">Go Back</a> ]");
?>