<table width="100%"  border="0" cellspacing="2" cellpadding="2">
  <tr>
    <td class="header">Descriptions</td>
  </tr>
  <tr>
    <td class="submenu">[ <a href="index.php?idx=descriptions&step=2&act=add">Add Description</a> ] </td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="2" cellpadding="2">
  <tr class="tableheader">
    <td width="15">&nbsp;</td>
    <td width="95%">Description</td>
    <td width="15">&nbsp;</td>
  </tr>
  <?php

$result = mysql_query ("SELECT * FROM `descriptions` ORDER BY `description_id` ASC");
if (!$result) {	echo("error performing query: " . mysql_error() . ""); exit(); }

if(mysql_num_rows($result)) {
	while($row = mysql_fetch_assoc($result)) {

		if ($bgclass == "table") { $bgclass = "tablealt"; } else { $bgclass = "table"; }

		echo "<tr class=\"$bgclass\">";
		echo "<td width=\"16\"><a href=\"index.php?idx=descriptions&step=2&act=edit&id=$row[description_id]\"><img src=\"images/_edit.gif\" border=\"0\" alt=\"Edit\"></a></td>";
		echo "<td>$row[description]</td>";
		echo "<td width=\"16\"><a href=\"javascript:confirmDelete('index.php?idx=descriptions&step=3&act=del&id=" . $row['description_id'] . "')\"><img src=\"images/x.gif\" border=\"0\" alt=\"Delete\"></a></td>";
		echo "</tr>";
		
	}
} else {
	echo "<tr bgcolor=\"#EEEEEE\" class=\"main\">";
	echo "<td colspan=\"3\"><div align=\"center\">No descriptions in database</div></td>";
	echo "</tr>";
}           
?>
</table>
