<?php
switch($step){
	case "1":									// index
		include("phplib/descriptions/idx.php");
		break;
	case "2":									// add/edit
		include("phplib/descriptions/edit.php");
		break;
	case "3":									// done
		include("phplib/descriptions/done.php");
		break;
	default:									// index
		include("phplib/descriptions/idx.php");
		break;
}
?>