<?php

if ($act == "edit") { 

$result = mysql_query ("SELECT * FROM `descriptions` WHERE `description_id` = '$_GET[id]'");
if (!$result) {	echo("error performing query: " . mysql_error() . ""); exit(); }

$row = mysql_fetch_assoc($result);

?>

<form method="post" action="index.php" name="form">
<input type="hidden" name="idx" value="descriptions">
<input type="hidden" name="step" value="3">
<input type="hidden" name="act" value="edit">
<input type="hidden" name="id" value="<?php echo $row['description_id']; ?>">

<?php } else { ?>

<form method="post" action="index.php" name="form">
<input type="hidden" name="idx" value="descriptions">
<input type="hidden" name="step" value="3">
<input type="hidden" name="act" value="add">
	
<?php } ?>

	
	<table width="100%" border="0" cellspacing="1" cellpadding="2">
      <tr>
        <td colspan="2" class="header">Descriptions Editor</td>
      </tr>
      <tr>
        <td colspan="2"><hr size="1" noshade></td>
      </tr>
      <tr>
        <td width="150">Description</td>
        <td><input name="description" type="text" class="form" id="description" size="60" maxlength="100" <? if ($act == "edit") { print "value=\"$row[description]\""; } ?>></td>
      </tr>
      <tr>
        <td colspan="2"><hr size="1" noshade></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td align="right"><input name="Submit" type="image" src="images/button_ok.gif" class="form" value="Submit">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="index.php?idx=<?=$idx?>"><img src="images/button_cancel.gif" border="0"></a></td>
      </tr>
</table>
