<table width="100%"  border="0" cellspacing="2" cellpadding="2">
  <tr>
    <td class="header">Settings</td>
  </tr>
  <tr>
    <td class="submenu">&nbsp;</td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="2" cellpadding="2">
  <tr class="tableheader">
    <td width="15">&nbsp;</td>
    <td>Setting</td>
	<td>Value</td>
  </tr>
  <?php

$result = mysql_query ("SELECT * FROM `settings` ORDER BY `key` ASC");
if (!$result) {	echo("error performing query: " . mysql_error() . ""); exit(); }

$rowcount = "0";

if(mysql_num_rows($result)) {
	while($row = mysql_fetch_assoc($result)) {
		extract ($row);
	
		if ($rowcount == "1") { $bgclass = "class=\"tablealt\""; $rowcount = "0"; } else { $bgclass = "class=\"table\""; $rowcount++; }
		print "<tr $bgclass>";
		print "<td width=\"15\" align=\"center\"><a href=\"index.php?idx=settings&step=2&act=edit&key=$key\"><img src=\"images/_edit.gif\" border=\"0\" alt=\"Edit $key\"></a></td>";
		print "<td>$key</td>";
		print "<td>$value</td>";
		print "</tr>";
		
	}
}          
?>
</table>