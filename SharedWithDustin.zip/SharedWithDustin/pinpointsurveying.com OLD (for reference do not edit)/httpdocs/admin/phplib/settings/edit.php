<?php if ($act == "edit") { 

$result = mysql_query ("SELECT * FROM `settings` WHERE `key`='$key'");
if (!$result) {	echo("error performing query: " . mysql_error() . ""); exit(); }

$row = mysql_fetch_assoc($result);
extract ($row);

?>

<form method="post" action="<?=$PHP_SELF?>" >
<input type="hidden" name="idx" value="settings">
<input type="hidden" name="step" value="3">
<input type="hidden" name="act" value="edit">
<input type="hidden" name="key" value="<?=$key?>">

<?php } ?>

<table width="100%" border="0" cellspacing="1" cellpadding="2">
  <tr>
    <td colspan="2" class="header">Settings Editor</td>
      </tr>
      <tr>
        <td colspan="2" class="mainlight"><hr size="1" noshade></td>
      </tr>
      <tr>
        <td width="150" class="mainlight"><?=$key?></td>
        <td><input name="value" type="text" class="form" id="value" size="50" maxlength="50" <?php if ($act == "edit") { print "value=\"$value\""; } ?>></td>
      </tr>
      <tr>
        <td colspan="2" class="mainlight"><hr size="1" noshade></td>
      </tr>
      <tr>
        <td class="mainlight">&nbsp;</td>
        <td align="right"><input name="Submit" type="image" src="images/button_ok.gif" class="form" value="Submit">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="index.php?idx=<?php=$idx?>"><img src="images/button_cancel.gif" border="0"></a></td>
      </tr>
</table>