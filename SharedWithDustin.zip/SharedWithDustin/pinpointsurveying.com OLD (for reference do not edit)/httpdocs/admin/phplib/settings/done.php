<?php

if ($act == "edit" ) {				// ####################### EDIT #######################

	$sql = "UPDATE `settings` SET `value`='$value' WHERE `key`='$key'";
			
	if (@mysql_query($sql)) {
		printMessage("$key Successfully Updated");
	} else {
		printMessage("Error Updating $key: " . mysql_error() . "");
	}	
}

printMessage ("[ <a href=\"index.php?idx=$idx\">Go Back</a> ]");
?>