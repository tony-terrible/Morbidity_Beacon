<?php
switch($step){
	case "1":									// index
		include("phplib/jobs/idx.php");
		break;
	case "2":									// add/edit
		include("phplib/jobs/edit.php");
		break;
	case "3":									// done
		include("phplib/jobs/done.php");
		break;
	case "4":									// view
		include("phplib/jobs/view.php");
		break;
	default:									// index
		include("phplib/jobs/idx.php");
		break;
}
?>