<table width="100%"  border="0" cellspacing="2" cellpadding="2">
  <tr>
    <td class="header">Current Jobs</td>
  </tr>
  <tr>
    <td class="submenu">[ <a href="index.php?idx=jobs&step=2&act=add">Add Job</a> ]</td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="2" cellpadding="2">
  <tr class="tableheader">
    <td width="15">&nbsp;</td>
    <td width="15">&nbsp;</td>
	<td>id</td>
	<td>Start Date</td>
    <td>Title</td>
    <td>Number</td>
    <td>Client</td>
    <td width="15">&nbsp;</td>
  </tr>
<?php

$sql = "SELECT
			`jobs`.`job_id`,
			`jobs`.`startDate`,
			`jobs`.`title`,
			`jobs`.`number`,
			`jobs`.`client_id`,
			`clients`.`client_id`,
			`clients`.`company`
		FROM `jobs`
			LEFT JOIN `clients` ON `jobs`.`client_id` = `clients`.`client_id`
		WHERE `complete` = '0'
		ORDER BY `startDate` DESC, `number` DESC";

$result = mysql_query ($sql);
if (!$result) {	echo("error performing query: " . mysql_error() . ""); exit(); }

$rowcount = "0";

if(mysql_num_rows($result)) {
	while($row = mysql_fetch_assoc ($result)) {
		if ($rowcount == "1") { $bgclass = "class=\"tablealt\""; $rowcount = "0"; } else { $bgclass = "class=\"table\""; $rowcount++; }

		//$client = mysql_result (mysql_query ("SELECT `company` FROM `clients` WHERE `id`='$row[3]'"), 0);

		echo "<tr $bgclass>";
		echo "<td width=\"15\"><a href=\"index.php?idx=jobs&step=4&id=$row[job_id]\"><img src=\"images/_search.gif\" border=\"0\" alt=\"View\"></a></td>";
		echo "<td width=\"15\"><a href=\"index.php?idx=jobs&step=2&act=edit&id=$row[job_id]\"><img src=\"images/_edit.gif\" border=\"0\" alt=\"Edit\"></a></td>";
		echo "<td>$row[job_id]</td>";
		echo "<td>$row[startDate]</td>";
		echo "<td>$row[title]</td>";
		echo "<td>$row[number]</td>";
		echo "<td><a href=\"index.php?idx=clients&step=4&id=$row[client_id]\">$row[company]</a></td>";
		echo "<td width=\"16\"><a href=\"javascript:confirmDelete('index.php?idx=jobs&step=3&act=del&id=" . $row['job_id'] . "')\"><img src=\"images/x.gif\" border=\"0\" alt=\"Delete\"></a></td>";
		echo "</tr>";
		
	}
} else {
	echo "<tr bgcolor=\"#EEEEEE\" class=\"main\">";
	echo "<td colspan=\"7\"><div align=\"center\">No incomplete jobs in database</div></td>";
	echo "</tr>";
}           
?>
</table>
