<script language="JavaScript">
<!--
function checkForm(form) {
	if (document.form.title.value == "") 	{ alert ('Please enter a title.'); 		document.form.title.focus(); 	return false; }
	if (document.form.number.value == "") 	{ alert ('Please enter a number.'); 	document.form.number.focus(); 	return false; }
	if (document.form.startDate.value == "") 	{ alert ('Please enter a start date.'); 	document.form.startDate.focus(); 	return false; }
	else { return true; }
}
//-->
</script>
<?php

if ($act == "edit") { 

$result = mysql_query ("SELECT * FROM `jobs` WHERE `job_id` = '$_GET[id]'");
if (!$result) {	echo("error performing query: " . mysql_error() . ""); exit(); }

$row = mysql_fetch_assoc ($result);

?>

<form method="post" action="index.php" name="form">
<input type="hidden" name="idx" value="jobs">
<input type="hidden" name="step" value="3">
<input type="hidden" name="act" value="edit">
<input type="hidden" name="id" value="<?php echo $row['job_id']; ?>">

<?php } else { ?>

<form method="post" action="index.php" name="form">
<input type="hidden" name="idx" value="jobs">
<input type="hidden" name="step" value="3">
<input type="hidden" name="act" value="add">
	
<?php } ?>

	
	<table width="100%" border="0" cellspacing="1" cellpadding="2">
      <tr>
        <td colspan="2" class="header">Job Editor</td>
      </tr>
      <tr>
        <td colspan="2"><hr size="1" noshade></td>
      </tr>
      <tr>
        <td width="150">Title <span class="required">*</span></td>
        <td><input name="title" type="text" class="form" id="title" size="60" maxlength="255" <?php if ($act == "edit") { echo "value=\"$row[title]\""; } ?>></td>
      </tr>
      <tr>
        <td width="150">Number <span class="required">*</span></td>
        <td><input name="number" type="text" class="form" id="number" size="11" maxlength="8" <?php if ($act == "edit") { echo "value=\"$row[number]\""; } ?>></td>
      </tr>
      <tr>
        <td>Start Date <span class="required">*</span></td>
        <td><script>DateInput('startDate', false, 'YYYY-MM-DD', '<?php if ($act == "edit") { echo $row['startDate']; } else { echo date("Y-m-d"); } ?>')</script></td>
      </tr>
      <tr>
        <td>Client</td>
        <td><select name="client_id" id="select" class="form"><?php
		$result = mysql_query ("SELECT * FROM `clients` ORDER BY `company` ASC");
		if (!$result) {	echo("error performing query: " . mysql_error() . ""); exit(); }
		
		if(mysql_num_rows($result)) {
			while($rowClients = mysql_fetch_assoc($result)) {
				if ($act == "edit" && $row['client_id'] == $rowClients['client_id']) { $selected = "selected"; } else { $selected = ""; }
				echo "<option value=\"$rowClients[client_id]\" $selected>$rowClients[company]</option>";
			}
		}
		?></select></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td valign="top">Description</td>
        <td><textarea name="description" cols="60" rows="5" class="form" id="description"><?php if ($act == "edit") { echo "$row[description]"; } ?></textarea></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td valign="top">Billing Details</td>
        <td><textarea name="billingDetails" cols="60" rows="5" class="form" id="billingDetails"><?php if ($act == "edit") { echo "$row[billingDetails]"; } ?></textarea></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>Complete</td>
        <td><input type="checkbox" name="complete" id="complete" value="1" <?php if ($act == "edit" && $row['complete'] == "1") { echo "checked"; } ?>></td>
      </tr>
      <tr>
        <td colspan="2"><hr size="1" noshade></td>
      </tr>
      <tr valign="top">
        <td class="required">* Required Fields</td>
        <td align="right"><input name="Submit" type="image" src="images/button_ok.gif" class="form" value="Submit" onclick="return checkForm(this);">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="index.php?idx=<?php echo $idx; ?>"><img src="images/button_cancel.gif" border="0"></a></td>
      </tr>
</table>