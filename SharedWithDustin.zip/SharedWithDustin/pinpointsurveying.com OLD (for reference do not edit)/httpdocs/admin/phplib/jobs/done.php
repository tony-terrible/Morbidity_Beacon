<?php

if ($act == "add" ) {				// ####################### ADD #######################

	$sql = "INSERT INTO `jobs` (
				`title`,
				`number`,
				`client_id`,
				`description`,
				`billingDetails`,
				`complete`,
				`startDate`
			) VALUES (
				'$_POST[title]',
				'$_POST[number]',
				'$_POST[client_id]',
				'$_POST[description]',
				'$_POST[billingDetails]',
				'$_POST[complete]',
				'$_POST[startDate]'
			)";
		
	if (@mysql_query($sql)) {
		printMessage("Job Successfully Added");
	} else {
		printMessage("Error Adding Job: " . mysql_error() . "");
	}
}


if ($act == "edit" ) {				// ####################### EDIT #######################

	$sql = "UPDATE `jobs` SET 
				`title` = '$_POST[title]',
				`number` = '$_POST[number]',
				`client_id` = '$_POST[client_id]',
				`description` = '$_POST[description]',
				`billingDetails` = '$_POST[billingDetails]',
				`complete` = '$_POST[complete]',
				`startDate` = '$_POST[startDate]'
			WHERE `job_id` = '$_POST[id]'";
		
	if (@mysql_query($sql)) {
		printMessage("Job Successfully Updated");
	} else {
		printMessage("Error Updating Job: " . mysql_error() . "");
	}	
}


if ($act == "del" ) {				// ####################### DEL #######################

	$checktimerecords = mysql_fetch_row (mysql_query ("SELECT * FROM `timerecords` WHERE `job_id` = '$_GET[id]' LIMIT 0,1"));
	if ($checktimerecords != "") { printMessage ("<b>Error</b>:  You cannot delete a job with time records.");	exit(); }

	$sql = "DELETE FROM `jobs` WHERE `job_id`='$_GET[id]'";

	if (@mysql_query($sql)) { 
		printMessage("Job Successfully Deleted");
	} else {
		printMessage("Error Deleting Job: " . mysql_error() . "");
	}
}

printMessage ("[ <a href=\"index.php?idx=$idx\">Go Back</a> ]");
?>