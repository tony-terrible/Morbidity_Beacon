<?php

$id = $_GET['id'];


$sql = "SELECT * 
		FROM `jobs`
			LEFT JOIN `clients` ON `jobs`.`client_id` = `clients`.`client_id`
		WHERE `job_id` = '$id'";

$result = mysql_query ($sql);
if (!$result) {	echo("error performing query: " . mysql_error() . ""); exit(); }

$row = mysql_fetch_assoc ($result);

if ($row['complete'] == "0") { $complete = "No"; } else if ($row['complete'] == "1") { $complete = "Yes"; }

$totalFieldTime = mysql_result (mysql_query ("SELECT SUM(`totaltime`) FROM `timerecords` WHERE `job_id`='$row[job_id]' && `type`='Field'"), 0);
$totalFieldGPSTime = mysql_result (mysql_query ("SELECT SUM(`totaltime`) FROM `timerecords` WHERE `job_id`='$row[job_id]' && `type`='Field GPS'"), 0);
$totalTravelTime = mysql_result (mysql_query ("SELECT SUM(`totaltime`) FROM `timerecords` WHERE `job_id`='$row[job_id]' && `type`='Travel'"), 0);
$totalOfficeTime = mysql_result (mysql_query ("SELECT SUM(`totaltime`) FROM `timerecords` WHERE `job_id`='$row[job_id]' && `type`='Office'"), 0);
$totalTime = mysql_result (mysql_query ("SELECT SUM(`totaltime`) FROM `timerecords` WHERE `job_id`='$row[job_id]'"), 0);

?>
<table width="100%" border="0" cellspacing="1" cellpadding="2">
      <tr>
        <td colspan="4" class="header">Job: <?php echo $row['title']; ?></td>
      </tr>
      <tr>
        <td colspan="4"><hr size="1" noshade></td>
      </tr>
      <tr>
        <td width="150" class="bodybold">Number</td>
        <td><?php echo $row['number']; ?></td>
        <td colspan="2" rowspan="6" align="right" valign="top" class="bodybold"><table width="200"  border="0" align="right" cellpadding="2" cellspacing="2">
            <tr>
              <td><span class="bodybold">Total Field Time</span></td>
              <td><div align="right"><?php echo $totalFieldTime; ?></div></td>
            </tr>
            <tr>
              <td><span class="bodybold">Total Field Time</span></td>
              <td><div align="right"><?php echo $totalFieldGPSTime; ?></div></td>
            </tr>            
            <tr>
              <td><span class="bodybold">Total Travel Time </span></td>
              <td><div align="right"><?php echo $totalTravelTime; ?></div></td>
            </tr>
            <tr>
              <td><span class="bodybold">Total Office Time </span></td>
              <td><div align="right"><?php echo $totalOfficeTime; ?></div></td>
            </tr>
            <tr>
              <td colspan="2"><hr size="1" noshade></td>
            </tr>
            <tr>
              <td><span class="bodybold">Total Time </span></td>
              <td><div align="right"><?php echo $totalTime; ?></div></td>
              
            </tr>
         </table>
	    </td>
      </tr>
      <tr>
        <td width="150" class="bodybold">Client</td>
        <td><a href="index.php?idx=clients&step=4&id=<?php echo $row['client_id']; ?>"><?php echo $row['company']; ?></a></td>
      </tr>
      <tr>
        <td width="150" class="bodybold">Description</td>
        <td><?php echo $row['description']; ?></td>
      </tr>
      <tr>
        <td width="150" class="bodybold">Billing Details</td>
        <td><?php echo $row['billingDetails']; ?></td>
      </tr>
      <tr>
        <td class="bodybold">Start Date </td>
        <td><?php echo $row['startDate']; ?></td>
      </tr>
      <tr>
        <td width="150" class="bodybold">Complete</td>
        <td><?php echo $complete; ?></td>
      </tr>
      <tr>
        <td colspan="4"><hr size="1" noshade></td>
      </tr>
	  <tr>
        <td colspan="4" class="subheader">Time Records</td>
      </tr>
      <tr>
        <td colspan="4">
		<table width="100%"  border="0" cellpadding="2" cellspacing="2" class="tableborder">
		<tr class="tableheader">
		    <td width="15">&nbsp;</td>
			<td>Date</td>
			<td>Type</td>
			<td align="center">Time In</td>
			<td align="center">Time Out</td>
			<td align="center">Total Hours</td>
			<td>Description</td>
			<td>Employee</td>
			<td>Invoice</td>
			<td>Timesheet</td>
			<td width="15">&nbsp;</td>
		</tr>
<?php

$sql = "SELECT *
		FROM `timerecords`
			LEFT JOIN `descriptions` 	ON `timerecords`.`description_id` 	= `descriptions`.`description_id`
			LEFT JOIN `users` 			ON `timerecords`.`user_id`			= `users`.`id`
			LEFT JOIN `invoices` 		ON `timerecords`.`invoice_id` 		= `invoices`.`invoice_id`
		WHERE `timerecords`.`job_id` = '$row[job_id]'
		ORDER BY `timerecords`.`timerecord_date`,`timerecords`.`timeIn` ASC";

$resultRecords = mysql_query ($sql);
if (!$resultRecords) {	echo("error performing query: " . mysql_error() . ""); exit(); }

if(mysql_num_rows($resultRecords)) {
	while($rowRecords = mysql_fetch_assoc($resultRecords)) {
	
		if ($rowcount == "1") { $bgclass = "class=\"tablealt\""; $rowcount = "0"; } else { $bgclass = "class=\"table\""; $rowcount++; }
		
		if ($rowRecords['userType'] == "0") {
			$userType = "Crewchief";
		} else if ($rowRecords['userType'] == "1") {
			$userType = "Rodman";
		}			
			
		//$description = mysql_result (mysql_query ("SELECT `description` FROM `descriptions` WHERE `id`='$rowRecords[9]'"), 0);
		//$employee = mysql_result (mysql_query ("SELECT `name` FROM `users` WHERE `id`='$rowRecords[2]'"), 0);
		
		echo "<tr $bgclass>";
		
		if ($rowRecords['invoice_id'] == 0) {
			echo "<td width=\"15\">";
			echo "<a href=\"index.php?idx=timerecords&step=2&act=edit&id=$rowRecords[timerecord_id]\">";
			echo "<img src=\"images/_edit.gif\" border=\"0\" alt=\"Edit\"></a></td>";
		} else {
			echo "<td width=\"15\">&nbsp;</td>";
		}
		
		echo "<td>$rowRecords[timerecord_date]</td>";
		echo "<td>$rowRecords[type]</td>";
		echo "<td align=\"center\" width=\"75\">$rowRecords[timeIn]</td>";
		echo "<td align=\"center\" width=\"75\">$rowRecords[timeOut]</td>";
		echo "<td align=\"center\" width=\"75\">$rowRecords[totalTime]</td>";
		echo "<td>$rowRecords[description] $rowRecords[extDescription]</td>";
		echo "<td>$rowRecords[username] ($userType)</td>";
		
		if ($rowRecords['invoice_id'] == 0) {
			echo "<td>Not Invoiced</td>";
		} else {
			//$invoiceNum = mysql_result (mysql_query ("SELECT `invoiceNum` FROM `invoices` WHERE `id`='$rowRecords[12]'"), 0);
			echo "<td><a href=\"#\" onClick=\"javascript:viewInvoice('phplib/invoices/viewinvoice.php?id=$rowRecords[invoice_id]')\">#$rowRecords[invoiceNum]</a></td>";
		}
		
		echo "<td><a href=\"index.php?idx=timesheets&step=5&id=$rowRecords[timesheet_id]\">$rowRecords[timesheet_id]</a></td>";
		
		if ($rowRecords['invoice_id'] == 0) {
			echo "<td width=\"15\">";
			echo "<a href=\"index.php?idx=timerecords&step=3&act=del&id=$rowRecords[timerecord_id]\">";
			echo "<img src=\"images/x.gif\" border=\"0\" alt=\"Delete\"></a></td>";
		} else {
			echo "<td width=\"15\">&nbsp;</td>";
		}
		
		echo "</tr>";
	}
} else {
	echo "<tr class=\"table\">";
	echo "<td colspan=\"10\">No time records</td>";
	echo "</tr>";
}

?>
</table>
		</td>
      </tr>
	  </table>
