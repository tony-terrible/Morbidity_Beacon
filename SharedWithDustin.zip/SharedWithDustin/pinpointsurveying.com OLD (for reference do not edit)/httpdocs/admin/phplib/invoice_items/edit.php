<?php
if ($act == "edit") { 

$result = mysql_query ("SELECT * FROM `invoice_items` WHERE `invoice_item_id` = $_GET[id]");
if (!$result) {	echo("error performing query: " . mysql_error() . ""); exit(); }

$row = mysql_fetch_assoc ($result);

?>

<form method="post" action="index.php" >
<input type="hidden" name="idx" value="invoice_items">
<input type="hidden" name="step" value="3">
<input type="hidden" name="act" value="edit">
<input type="hidden" name="invoice_item_id" value="<?php echo $row['invoice_item_id']?>">

<?php } else { ?>

<form method="post" action="index.php">
<input type="hidden" name="idx" value="invoice_items">
<input type="hidden" name="step" value="3">
<input type="hidden" name="act" value="add">
	
<?php } ?>

	
	<table width="100%" border="0" cellspacing="1" cellpadding="2">
      <tr>
        <td colspan="3" class="header">Item Editor</td>
      </tr>
      <tr>
        <td colspan="3"><hr size="1" noshade></td>
      </tr>
      <tr>
        <td width="150" colspan="2">Name</td>
        <td><input name="name" type="text" class="form" id="name" size="25" maxlength="25" <?php if ($act == "edit") { echo "value=\"$row[name]\""; } ?>></td>
      </tr>
      <tr>
        <td width="74">Price</td>
        <td width="75"><div align="right">$</div></td>
        <td><input name="price" type="text" class="form" id="price" size="15" maxlength="15" <?php if ($act == "edit") { echo "value=\"$row[price]\""; } ?>> 
          (xxx.xx) </td>
      </tr>	  
      <tr>
        <td colspan="3"><hr size="1" noshade></td>
      </tr>
      <tr>
        <td colspan="2">&nbsp;</td>
        <td align="right"><input name="Submit" type="image" src="images/button_ok.gif" class="form" value="Submit">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="index.php?idx=<?php=$idx?>"><img src="images/button_cancel.gif" border="0"></a></td>
      </tr>
</table>
