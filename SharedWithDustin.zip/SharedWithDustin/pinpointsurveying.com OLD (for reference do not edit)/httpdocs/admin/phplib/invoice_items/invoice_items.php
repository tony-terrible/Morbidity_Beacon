<?php
switch($step){
	case "1":									// index
		include("phplib/invoice_items/idx.php");
		break;
	case "2":									// add/edit
		include("phplib/invoice_items/edit.php");
		break;
	case "3":									// done
		include("phplib/invoice_items/done.php");
		break;
	default:									// index
		include("phplib/invoice_items/idx.php");
		break;
}
?>