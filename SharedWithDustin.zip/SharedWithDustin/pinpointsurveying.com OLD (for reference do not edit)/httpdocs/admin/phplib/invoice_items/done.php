<?php

if ($act == "add" ) {				// ####################### ADD #######################

	$sql = "INSERT INTO `invoice_items` (
				`name`,
				`price`
			) VALUES (
				'$_POST[name]',
				'$_POST[price]'
			)";
		
	if (@mysql_query($sql)) {
		printMessage("Invoice Item Successfully Added");
	} else {
		printMessage("Error Adding Invoice Item: " . mysql_error() . "");
	}
}

if ($act == "edit" ) {				// ####################### EDIT #######################

	$sql = "UPDATE `invoice_items` SET
				`name` = '$_POST[name]',
				`price` = '$_POST[price]'
			WHERE `invoice_item_id`='$_POST[id]'";
			
	if (@mysql_query($sql)) {
		printMessage("Invoice Item Successfully Updated");
	} else {
		printMessage("Error Updating Invoice Item: " . mysql_error() . "");
	}	
}

if ($act == "del" ) {				// ####################### DEL #######################

	$sql = "DELETE FROM `invoice_items` WHERE `invoice_item_id`='$_GET[id]'";
	
	if (@mysql_query($sql)) { 
		printMessage("Invoice Item Successfully Deleted");
	} else {
		printMessage("Error Deleting Invoice Item: " . mysql_error() . "");
	}
}

printMessage ("[ <a href=\"index.php?idx=$idx\">Go Back</a> ]");
?>