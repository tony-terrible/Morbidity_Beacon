<table width="100%"  border="0" cellspacing="2" cellpadding="2">
  <tr>
    <td class="header">Invoice Items</td>
  </tr>
  <tr>
    <td class="submenu">[ <a href="index.php?idx=invoice_items&step=2&act=add">Add Item</a> ] </td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="2" cellpadding="2">
  <tr class="tableheader">
    <td width="15">&nbsp;</td>
    <td>Name</td>
	<td>Price</td>
    <td width="15">&nbsp;</td>
  </tr>
<?php

$result = mysql_query ("SELECT * FROM `invoice_items` ORDER BY `name` ASC");
if (!$result) {	echo("error performing query: " . mysql_error() . ""); exit(); }

$rowcount = "0";

if(mysql_num_rows($result)) {
	while($row = mysql_fetch_assoc ($result)) {
		if ($rowcount == "1") { $bgclass = "class=\"tablealt\""; $rowcount = "0"; } else { $bgclass = "class=\"table\""; $rowcount++; }
		echo "<tr $bgclass>";
		echo "<td width=\"15\"><a href=\"index.php?idx=invoice_items&step=2&act=edit&id=$row[invoice_item_id]\"><img src=\"images/_edit.gif\" border=\"0\" alt=\"Edit\"></a></td>";
		echo "<td>$row[name]</td>";
		echo "<td>$$row[price]</td>";
		echo "<td width=\"16\"><a href=\"javascript:confirmDelete('index.php?idx=invoice_items&step=3&act=del&id=" . $row['invoice_item_id'] . "')\"><img src=\"images/x.gif\" border=\"0\" alt=\"Delete\"></a></td>";
		echo "</tr>";
		
	}
} else {
	echo "<tr bgcolor=\"#EEEEEE\" class=\"main\">";
	echo "<td colspan=\"4\"><div align=\"center\">No items in database</div></td>";
	echo "</tr>";
}           
?>
</table>
