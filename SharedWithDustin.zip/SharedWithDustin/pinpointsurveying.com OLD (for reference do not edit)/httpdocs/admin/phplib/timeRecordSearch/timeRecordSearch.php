<?php
switch($step){
	case "1":									// index
		include("phplib/timeRecordSearch/idx.php");
		break;
	case "2":									// view
		include("phplib/timeRecordSearch/view.php");
		break;
	default:									// index
		include("phplib/timeRecordSearch/idx.php");
		break;
}
?>