<?php

### Init AJAX
sajax_init();
$sajax_debug_mode = 0;
sajax_export("change_client");
sajax_handle_client_request();	
### End Init AJAXA

?>

<script language="JavaScript">
<!--

<?php
sajax_show_javascript();
?>

function nothing () { }

function update_job_list_cb (result) {
	document.getElementById('job_list').innerHTML = result;
}

function update_job_list () {
	var client_id = document.getElementById("client_id").value;

	x_change_client (client_id,update_job_list_cb);
	
}



function checkForm(form) {
	if (document.form.userId.value == "") 								{ alert ('Please select a user.'); 									document.form.userId.focus(); 			return false; }
	else { return true; }
}
//-->
</script>

<form method="post" action="index.php" name="form">
<input type="hidden" name="idx" value="timeRecordSearch">
<input type="hidden" name="step" value="2">

<table width="100%"  border="0" cellspacing="2" cellpadding="2">
  <tr>
    <td class="header">Time Record Search</td>
  </tr>
  <tr>
    <td class="submenu">&nbsp;</td>
  </tr>
</table>

<table width="100%" border="0" cellspacing="2" cellpadding="2">
  <tr>
    <td colspan="2"><hr size="1" noshade></td>
  </tr>
  <tr>
    <td width="150">User <span class="required">*</span></td>
    <td>
	<select name="user_id" id="user_id" class="form">
		<option value=""></option>
        <?php
		$result = mysql_query ("SELECT * FROM `users` ORDER BY `name` ASC");
		if (!$result) { echo("error performing query: " . mysql_error() . ""); exit(); }
		
		if(mysql_num_rows($result)) {
			while($row = mysql_fetch_assoc($result)) {
				echo "<option value=\"$row[id]\">$row[name]</option>";
			}
		}
		?>
    </select>	
	</td>
  </tr>
  <tr>
    <td>Start Date <span class="required">*</span></td>
    <td><script>DateInput('startDate', false, 'YYYY-MM-DD', '<?php echo date ("Y-m-d"); ?>')</script></td>
  </tr>
  <tr>
    <td>End Date <span class="required">*</span></td>
    <td><script>DateInput('endDate', false, 'YYYY-MM-DD', '<?php echo date ("Y-m-d"); ?>')</script></td>
  </tr>
  <tr>
    <td width="150">Client</td>
    <td>
	<select name="client_id" id="client_id" class="form" onchange="update_job_list()">
		<option value="">All Clients</option>
        <?php
		$result = mysql_query ("SELECT * FROM `clients` ORDER BY `company` ASC");
		if (!$result) { echo("error performing query: " . mysql_error() . ""); exit(); }
		
		if (mysql_num_rows($result)) {
			while ($row = mysql_fetch_assoc($result)) {
				echo "<option value=\"$row[client_id]\">$row[company]</option>\n";
			}
		}
		?>
    </select>	
	</td>
  </tr>  
  <tr>
    <td width="150">Job</td>
    <td><div id="job_list">No client selected</div></td>
  </tr>    
  <tr>
	<td colspan="2"><hr size="1" noshade></td>
  </tr>
  <tr>
    <td><span class="required">* Required</span></td>  
	<td align="right">
	<input name="Submit" type="image" src="images/button_ok.gif" class="form" value="Submit" onClick="return checkForm(this);">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<a href="index.php?idx=<?php echo $idx; ?>"><img src="images/button_cancel.gif" border="0"></a></td>
  </tr>
</table>
