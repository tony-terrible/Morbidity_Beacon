<table width="100%"  border="0" cellspacing="2" cellpadding="2">
  <tr>
    <td class="header">Time Record Search Results </td>
  </tr>
  <tr>
    <td class="submenu">&nbsp;</td>
  </tr>
</table>

<table width="100%" border="0" cellspacing="2" cellpadding="2">
  <tr>
    <td colspan="10"><hr size="1" noshade></td>
  </tr>
  
  <tr>
	<td class="tableheader">Date</td>
	<td class="tableheader">Type</td>
	<td class="tableheader">Time In</td>
	<td class="tableheader">Time Out</td>
	<td class="tableheader">Total Hours</td>
	<td class="tableheader">Description</td>
	<td class="tableheader">Employee</td>
	<td class="tableheader">Invoice #</td>
	<td class="tableheader">Job #</td>
  </tr>
  
<?php

$user_types = array ("0" => "Crewchief", "1" => "Rodman");

$sql = "SELECT
			`timerecords`.*,
			`descriptions`.`description`,
			`users`.`username`,
			`jobs`.`number` AS 'job_number',
			`invoices`.`invoiceNum` AS 'invoice_number'
			
		FROM `timerecords`
			LEFT JOIN `descriptions` 	ON `timerecords`.`description_id` 	= `descriptions`.`description_id`
			LEFT JOIN `users` 			ON `timerecords`.`user_id` 			= `users`.`id`
			LEFT JOIN `jobs` 			ON `timerecords`.`job_id` 			= `jobs`.`job_id`
			LEFT JOIN `invoices` 		ON `timerecords`.`invoice_id` 		= `invoices`.`invoice_id`				
		WHERE `timerecords`.`user_id` = '$_POST[user_id]'
		AND `timerecords`.`timerecord_date` > '$_POST[startDate]'
		AND `timerecords`.`timerecord_date` < '$_POST[endDate]' ";

if (!empty ($_POST['job_id']) && is_numeric($_POST['job_id'])) {				// Searching Jobs & Clients
						
	$client_id = $_POST['client_id'];
	$job_id = $_POST['job_id'];		
	
	$sql .= "AND `jobs`.`client_id` = '$client_id' 
			 AND `jobs`.`job_id` = '$job_id'";
			
} else if (!empty ($_POST['client_id']) && is_numeric($_POST['client_id'])) {	// Searching Jobs

	$client_id = $_POST['client_id'];
	$sql .= "AND `jobs`.`client_id` = '$client_id'"; 		

}

$sql .= " ORDER BY `timerecords`.`timerecord_id` ASC";

//echo $sql;

$result = mysql_query ($sql);
if (!$result) { echo("<br><br><br>error performing query: " . mysql_error() . "<br><br><br>"); }

if (mysql_num_rows ($result)) {
	while($rowRecords = mysql_fetch_assoc ($result)) {
	
		if ($bgclass == "table") { $bgclass = "tablealt"; } else { $bgclass = "table"; }
	
		$user_type = $rowRecords['userType'];
		$user_type = $user_types["$user_type"];
		
		$description = wordwrap ($rowRecords['description'] . $rowRecords['extDescription'], 60, "<br />", 1);
		
		echo "<tr class=\"$bgclass\">";
		
		echo "<td valign=\"top\">$rowRecords[timerecord_date]</td>";
		echo "<td valign=\"top\">$rowRecords[type]</td>";
		echo "<td valign=\"top\" align=\"center\" width=\"75\">$rowRecords[timeIn]</td>";
		echo "<td valign=\"top\" align=\"center\" width=\"75\">$rowRecords[timeOut]</td>";
		echo "<td valign=\"top\" align=\"center\" width=\"75\">$rowRecords[totalTime]</td>";
		echo "<td valign=\"top\">$description</td>";
		echo "<td valign=\"top\">$rowRecords[username] ($user_type)</td>";
		
		if ($rowRecords['invoice_id'] == "0") {
			echo "<td valign=\"top\">Not Invoiced</td>";
		} else {
			echo "<td valign=\"top\"><a href=\"#\" onClick=\"viewInvoice('phplib/invoices/viewinvoice.php?id=$rowRecords[invoice_id]')\">$rowRecords[invoice_number]</a></td>";
		}
		
		echo "<td valign=\"top\"><a href=\"index.php?idx=jobs&step=4&id=$rowRecords[job_id]\">$rowRecords[job_number]</a></td>";

		echo "</tr>";
	}
} else {
	echo "<tr>";
	echo "<td>No results found</td>";
	echo "</tr>";
}

?>  
 
  <tr>
	<td colspan="10"><hr size="1" noshade></td>
  </tr>
</table>

<pre>
<?php // print_r ($_POST); ?>
</pre>