<table width="100%"  border="0" cellspacing="2" cellpadding="2">
  <tr>
    <td class="header">Time Records</td>
  </tr>
  <tr>
    <td class="submenu">&nbsp;</td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="2" cellpadding="2">
  <tr class="tableheader">
    <td width="15">&nbsp;</td>
    <td>timesheetId</td>
    <td>userId</td>
	<td>date</td>
	<td>jobId</td>
	<td>type</td>
    <td width="15">&nbsp;</td>
  </tr>
  <?php

$result = mysql_query ("SELECT * FROM `timerecords` ORDER BY `id` ASC");
if (!$result) {	echo("error performing query: " . mysql_error() . ""); exit(); }

$rowcount = "0";

if(mysql_num_rows($result)) {
	while($row = mysql_fetch_row($result)) {
		if ($rowcount == "1") { $bgclass = "class=\"tablealt\""; $rowcount = "0"; } else { $bgclass = "class=\"table\""; $rowcount++; }
		print "<tr $bgclass>";
		print "<td width=\"15\" align=\"center\"><a href=\"index.php?idx=timerecords&step=2&act=edit&id=$row[0]\"><img src=\"images/_edit.gif\" border=\"0\" alt=\"Edit $row[4]\"></a></td>";
		print "<td>$row[1]</td>";
		print "<td>$row[2]</td>";
		print "<td>$row[3]</td>";
		print "<td>$row[4]</td>";
		print "<td>$row[5]</td>";
		echo "<td width=\"16\"><a href=\"javascript:confirmDelete('index.php?idx=timerecords&step=3&act=del&id=" . $row[0] . "')\"><img src=\"images/x.gif\" border=\"0\" alt=\"Delete\"></a></td>";
		print "</tr>";
		
	}
} else {
	print "<tr bgcolor=\"#EEEEEE\" class=\"main\">";
	print "<td colspan=\"7\"><div align=\"center\">No time records in database</div></td>";
	print "</tr>";
}           
?>
</table>
