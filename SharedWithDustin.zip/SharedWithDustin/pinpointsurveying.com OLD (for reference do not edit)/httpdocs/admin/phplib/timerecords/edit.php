<script language="JavaScript">
<!--
function checkForm(form) {
	if (document.form.date.value == "") { alert ('Please enter a date.'); document.form.date.focus(); return false; }
	if (document.form.user_id.value == "") { alert ('Please select a user.'); document.form.user_id.focus(); return false; }
	if (document.form.userType.value == "") { alert ('Please select a user type.'); document.form.userType.focus(); return false; }
	if (document.form.job_id.value == "") { alert ('Please select a job.'); document.form.job_id.focus(); return false; }
	if (document.form.type.value == "") { alert ('Please select a type.'); document.form.type.focus(); return false; }
	if (document.form.timeIn.value == "") { alert ('Please enter your time in.'); document.form.timeIn.focus(); return false; }
	if (document.form.timeOut.value == "") { alert ('Please enter your time out.'); document.form.timeOut.focus(); return false; }
	if (document.form.totalTime.value == "") { alert ('Please enter your total time.'); document.form.totalTime.focus(); return false; }
	if (document.form.description_id.value == "") { alert ('Please select a description.'); document.form.description_id.focus(); return false; }
	else { return true; }
}
//-->
</script>
<?php

if ($act == "edit") { 

$result = mysql_query ("SELECT * FROM `timerecords` WHERE `timerecord_id` = '$_GET[id]'");
if (!$result) {	echo("error performing query: " . mysql_error() . ""); exit(); }

$row = mysql_fetch_assoc($result);

$timesheet_id = $row['timesheet_id'];

?>

<form method="post" action="index.php" name="form">
<input type="hidden" name="idx" value="timerecords">
<input type="hidden" name="step" value="3">
<input type="hidden" name="act" value="edit">
<input type="hidden" name="id" value="<?php echo $row['timerecord_id']; ?>">

<?php } else { ?>

<form method="post" action="index.php" name="form">
<input type="hidden" name="idx" value="timerecords">
<input type="hidden" name="step" value="3">
<input type="hidden" name="act" value="add">
<input type="hidden" name="timesheet_id" value="<?php echo $timesheet_id; ?>">
	
<?php } ?>

	
	<table width="100%" border="0" cellspacing="1" cellpadding="2">
      <tr>
        <td colspan="4" class="header">Time Record Editor</td>
      </tr>
      <tr>
        <td colspan="4"><hr size="1" noshade></td>
      </tr>
      <tr>
        <td width="150">Timesheet ID</td>
        <td><?php echo $timesheet_id; ?></td>
        <td>User <span class="required">*</span></td>
        <td><select name="user_id" id="user_id" class="form">
		<option value=""></option>
		<?php
		$resultUserId = mysql_query ("SELECT * FROM `users` ORDER BY `name` ASC");
		if (!$resultUserId) { echo("error performing query: " . mysql_error() . ""); exit(); }
		
		if(mysql_num_rows($resultUserId)) {
			while($rowUserId = mysql_fetch_assoc($resultUserId)) {
				if ($row['user_id'] == $rowUserId['id']) { $selected = "selected"; } else { $selected = ""; }
				echo "<option value=\"$rowUserId[id]\" $selected>$rowUserId[name]</option>\n";
			}
		}
		?>
		</select> as 
		<select name="userType" id="userType" class="form">
		<option value=""></option>
		<option value="0" <? if (($act == "edit") && ($row['userType'] == "0")) { echo "selected"; }?>>Crewchief</option>
		<option value="1" <? if (($act == "edit") && ($row['userType'] == "1")) { echo "selected"; }?>>Rodman</option>
		</select>
		</td>
      </tr>
      <tr>
        <td>Date <span class="required">*</span></td>
        <td><script>DateInput('timerecord_date', false, 'YYYY-MM-DD', '<?php if ($act == "edit") { echo $row['timerecord_date']; } else { echo date ("Y-m-d"); } ?>')</script></td>
			
        <td width="150">Job <span class="required">*</span></td>
        <td><select name="job_id" id="job_id" class="form">
		<option value=""></option>
          <?php
		$resultjobId = mysql_query ("SELECT * FROM `jobs` ORDER BY `number` DESC");
		if (!$resultjobId) { echo("error performing query: " . mysql_error() . ""); exit(); }
		
		if(mysql_num_rows($resultjobId)) {
			while($rowjobId = mysql_fetch_assoc($resultjobId)) {
				if ($row['job_id'] == $rowjobId['job_id']) { $selected = "selected"; } else { $selected = ""; }
				echo "<option value=\"$rowjobId[job_id]\" $selected>$rowjobId[number] - $rowjobId[title]</option>\n";
			}
		}
		?>
        </select></td>
      </tr>
      <tr>
        <td>Time In <span class="required">*</span></td>
        <td><input name="timeIn" type="text" id="timeIn" size="5" maxlength="14" class="form" value="<?php echo $row['timeIn']; ?>"> 
        (HH:MM:SS - 24 Hour Time) </td>
        <td width="150">Type <span class="required">*</span></td>
        <td><select name="type" id="type" class="form">
		  <option value=""></option>
          <option value="Field" <?php if (($act == "edit") && ($row['type'] == "Field")) { echo "selected"; }?>>Field</option>
          <option value="Field GPS" <?php if (($act == "edit") && ($row['type'] == "Field GPS")) { echo "selected"; }?>>Field GPS</option>
          <option value="Travel" <?php if (($act == "edit") && ($row['type'] == "Travel")) { echo "selected"; }?>>Travel</option>
          <option value="Office" <?php if (($act == "edit") && ($row['type'] == "Office")) { echo "selected"; }?>>Office</option>
        </select></td>
      </tr>
      <tr>
        <td>Time Out <span class="required">*</span></td>
        <td><input name="timeOut" type="text" id="timeOut" size="5" maxlength="14" class="form" value="<?php echo $row['timeOut']; ?>"> (HH:MM:SS - 24 Hour Time)</td>
        <td width="150">Total Time <span class="required">*</span></td>
        <td><input name="totalTime" type="text" id="totalTime" size="5" maxlength="14" class="form" value="<?php echo $row['totalTime']; ?>"> Hours</td>
      </tr>
      <tr>
        <td>Description <span class="required">*</span></td>
        <td><select name="description_id" id="description_id" class="form">
		<option value=""></option>
          <?php
		$resultdescriptionId = mysql_query ("SELECT * FROM `descriptions` ORDER BY `description` ASC");
		if (!$resultdescriptionId) { echo("error performing query: " . mysql_error() . ""); exit(); }
		
		if(mysql_num_rows($resultdescriptionId)) {
			while($rowdescriptionId = mysql_fetch_assoc ($resultdescriptionId)) {
				if ($row['description_id'] == $rowdescriptionId['description_id']) { $selected = "selected"; } else { $selected = ""; }
				echo "<option value=\"$rowdescriptionId[description_id]\" $selected>$rowdescriptionId[description]</option>\n";
			}
		}
		?>
        </select></td>
        <td width="150">Extended Description </td>
        <td><input name="extDescription" type="text" id="extDescription" size="40" maxlength="250" class="form" value="<?php echo $row['extDescription']; ?>"></td>
      </tr>
      <tr>
        <td colspan="4"><hr size="1" noshade></td>
      </tr>
      <tr valign="top">
        <td class="required">* Required Fields</td>
        <td align="right" colspan="3"><input name="Submit" type="image" src="images/button_ok.gif" class="form" value="Submit" onClick="return checkForm(this);">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="index.php?idx=<?=$idx?>"><img src="images/button_cancel.gif" border="0"></a></td>
      </tr>
</table>
</form>