<?php

if ($act == "add" ) {				// ####################### EDIT #######################

	$sql = "INSERT INTO `timerecords` (
			`timesheet_id`,
			`user_id`,
			`timerecord_date`,
			`job_id`,
			`type`,
			`timeIn`,
			`timeOut`,
			`totalTime`,
			`description_id`,
			`extDescription`,
			`userType`
		) VALUES (
			'$_POST[timesheet_id]',
			'$_POST[user_id]',
			'$_POST[timerecord_date]',
			'$_POST[job_id]',
			'$_POST[type]',
			'$_POST[timeIn]',
			'$_POST[timeOut]',
			'$_POST[totalTime]',
			'$_POST[description_id]',
			'$_POST[extDescription]',
			'$_POST[userType]'
		)";

	if (@mysql_query($sql)) {
		printMessage("Time Record Successfully Added");
	} else {
		printMessage("Error Adding Time Record: " . mysql_error() . "");
	}	
}

if ($act == "edit" ) {				// ####################### EDIT #######################

	$sql = "UPDATE `timerecords` SET 
				`user_id` 			= '$_POST[user_id]',
				`timerecord_date` 	= '$_POST[timerecord_date]',
				`job_id` 			= '$_POST[job_id]',
				`type` 				= '$_POST[type]',
				`timeIn` 			= '$_POST[timeIn]',
				`timeOut` 			= '$_POST[timeOut]',
				`totalTime` 		= '$_POST[totalTime]',
				`description_id` 	= '$_POST[description_id]',
				`extDescription` 	= '$_POST[extDescription]',
				`userType` 			= '$_POST[userType]'
			WHERE `timerecord_id` 	= '$_POST[id]'";
			
	if (@mysql_query($sql)) {
		printMessage("Time Record Successfully Updated");
	} else {
		printMessage("Error Updating Time Record: " . mysql_error() . "");
	}	
}

if ($act == "del" ) {				// ####################### DEL #######################

	if ($_SESSION["$site_session_prefix"]['session_user_level'] == "0") {	

		$sql = "DELETE FROM `timerecords` WHERE `timerecord_id` = '$_GET[id]'";
	
		if (@mysql_query($sql)) { 
			printMessage("Time Record Successfully Deleted");
		} else {
			printMessage("Error Deleting Time Record: " . mysql_error() . "");
		}
	} else {
		printMessage ("Access Denied");
	}
}
?>