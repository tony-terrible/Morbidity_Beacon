<?php
switch($step){
	case "1":									// index
		include("phplib/timerecords/idx.php");
		break;
	case "2":									// add/edit
		include("phplib/timerecords/edit.php");
		break;
	case "3":									// done
		include("phplib/timerecords/done.php");
		break;
	default:									// index
		include("phplib/timerecords/idx.php");
		break;
}
?>