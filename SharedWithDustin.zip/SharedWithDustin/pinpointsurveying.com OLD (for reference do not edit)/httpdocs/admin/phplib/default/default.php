<?php
printMessage("Welcome to your custom Catch 22 Administration tool!");
printMessage("Please choose from the menu above to get started.");
?>