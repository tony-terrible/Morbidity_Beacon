<?php
$sql = "SELECT *
		FROM `timesheets`
		LEFT JOIN `users` 			ON `timesheets`.`user_id` 		= `users`.`id`
		WHERE `timesheet_id`  ='$_GET[id]'";

$result = mysql_query ($sql);
if (!$result) {	echo("error performing query: " . mysql_error() . ""); exit(); }

$row = mysql_fetch_assoc ($result);

if ($row['complete'] == "0") { $complete = "No"; } else if ($row['complete'] == "1") { $complete = "Yes"; }

$totalFieldTime	 = mysql_result (mysql_query ("SELECT SUM(`totaltime`) FROM `timerecords` WHERE `timesheet_id`='$row[timesheet_id]' && `type`='Field'"), 0);
$totalFieldGPSTime = mysql_result (mysql_query ("SELECT SUM(`totaltime`) FROM `timerecords` WHERE `timesheet_id`='$row[timesheet_id]' && `type`='Field GPS'"), 0);
$totalTravelTime = mysql_result (mysql_query ("SELECT SUM(`totaltime`) FROM `timerecords` WHERE `timesheet_id`='$row[timesheet_id]' && `type`='Travel'"), 0);
$totalOfficeTime = mysql_result (mysql_query ("SELECT SUM(`totaltime`) FROM `timerecords` WHERE `timesheet_id`='$row[timesheet_id]' && `type`='Office'"), 0);


$totalTime = mysql_result (mysql_query ("SELECT SUM(`totaltime`) FROM `timerecords` WHERE `timesheet_id`='$row[timesheet_id]'"), 0);
//$createdby = mysql_result (mysql_query ("SELECT `name` FROM `users` WHERE `id`='$row[2]'"), 0);

?>
<table width="100%" border="0" cellspacing="1" cellpadding="2">
      <tr>
        <td colspan="4" class="header">Timesheet Viewer</td>
      </tr>
	  <tr>
		<td class="submenu" colspan="4">[ <a href="index.php?idx=timerecords&step=2&act=add&timesheet_id=<? echo $row['timesheet_id']; ?>">Add Time Record</a> ]</td>
	  </tr>
      <tr>
        <td width="150">Date</td>
        <td><? echo $row['date']; ?></td>
        <td colspan="2" rowspan="4" align="right" valign="middle"><table width="200"  border="0" cellspacing="2" cellpadding="2">
          <tr>
            <td><span class="bodybold">Total Field Time</span></td>
            <td><div align="right">
                <?php echo $totalFieldTime; ?>
            </div></td>
          </tr>
          <tr>
            <td><span class="bodybold">Total Field GPS Time</span></td>
            <td><div align="right">
                <?php echo $totalFieldGPSTime; ?>
            </div></td>
          </tr>          
          <tr>
            <td><span class="bodybold">Total Travel Time </span></td>
            <td><div align="right">
                <?php echo $totalTravelTime; ?>
            </div></td>
          </tr>
          <tr>
            <td><span class="bodybold">Total Office Time </span></td>
            <td><div align="right">
                <?php echo $totalOfficeTime; ?>
            </div></td>
          </tr>
          <tr>
            <td colspan="2"><hr size="1" noshade></td>
          </tr>
          <tr>
            <td><span class="bodybold">Total Time </span></td>
            <td><div align="right">
                <?php echo $totalTime; ?>
            </div></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td width="150">Created By</td>
        <td><?php echo $row['name']; ?></td>
      </tr>
      <tr>
        <td valign="top">Complete</td>
        <td valign="top"><?php echo $complete; ?></td>
      </tr>
      <tr>
        <td width="150" height="100%" valign="top">&nbsp;</td>
        <td height="100%" valign="top">&nbsp;</td>
      </tr>
      <tr>
        <td colspan="4"><hr size="1" noshade></td>
      </tr>
      <tr>
        <td colspan="4">
		<table width="100%"  border="0" cellpadding="2" cellspacing="2" class="tableborder">
		<tr class="tableheader">
		    <td width="15">&nbsp;</td>
			<td>Date</td>
			<td>Type</td>
			<td align="center">Time In</td>
			<td align="center">Time Out</td>
			<td align="center">Total Hours</td>
			<td>Description</td>
			<td>Employee</td>
			<td>Invoice</td>
			<td>Job #</td>
			<td width="15">&nbsp;</td>
		</tr>
<?php

$user_types = array ("0" => "Crewchief", "1" => "Rodman");

$sql = "SELECT
			`timerecords`.*,
			
			`descriptions`.`description`,
			`users`.`username`,
			`jobs`.`number` AS 'job_number',
			`invoices`.`invoiceNum` AS 'invoice_number'
			
		FROM `timerecords`
			LEFT JOIN `descriptions` 	ON `timerecords`.`description_id` 	= `descriptions`.`description_id`
			LEFT JOIN `users` 			ON `timerecords`.`user_id` 			= `users`.`id`
			LEFT JOIN `jobs` 			ON `timerecords`.`job_id` 			= `jobs`.`job_id`
			LEFT JOIN `invoices` 		ON `timerecords`.`invoice_id` 		= `invoices`.`invoice_id`
			
		WHERE `timesheet_id` = '$_GET[id]'
		ORDER BY `timerecord_date`,`timeIn` ASC";

$resultRecords = mysql_query ($sql);
if (!$resultRecords) {	echo("error performing query: " . mysql_error() . ""); exit(); }

if(mysql_num_rows($resultRecords)) {
	while($rowRecords = mysql_fetch_assoc ($resultRecords)) {
	
		if ($bgclass == "table") { $bgclass = "tablealt"; } else { $bgclass = "table"; }
	
		$user_type = $rowRecords['userType'];
		$user_type = $user_types["$user_type"];
		
		echo "<tr class=\"$bgclass\">";
		
		if (($rowRecords['invoice_id'] == 0) && ($row['user_id'] == $_SESSION["$site_session_prefix"]['session_userId']) || ($_SESSION["$site_session_prefix"]['session_user_level'] == "0")) {
			echo "<td width=\"16\">";
			echo "<a href=\"index.php?idx=timerecords&step=2&act=edit&id=$rowRecords[timerecord_id]\"><img src=\"images/_edit.gif\" border=\"0\" alt=\"Edit\"></a>";
			echo "</td>";
		} else {
			echo "<td width=\"16\">&nbsp;</td>";
		}
		
		echo "<td>$rowRecords[timerecord_date]</td>";
		echo "<td>$rowRecords[type]</td>";
		echo "<td align=\"center\" width=\"75\">$rowRecords[timeIn]</td>";
		echo "<td align=\"center\" width=\"75\">$rowRecords[timeOut]</td>";
		echo "<td align=\"center\" width=\"75\">$rowRecords[totalTime]</td>";
		echo "<td>$rowRecords[description] $rowRecords[extDescription]</td>";
		echo "<td>$rowRecords[username] ($user_type)</td>";
		
		if ($rowRecords['invoice_id'] == "0") {
			echo "<td>Not Invoiced</td>";
		} else {
			echo "<td><a href=\"#\" onClick=\"viewInvoice('phplib/invoices/viewinvoice.php?id=$rowRecords[invoice_id]')\">#$rowRecords[invoice_number]</a></td>";
		}
		
		echo "<td><a href=\"index.php?idx=jobs&step=4&id=$rowRecords[job_id]\">$rowRecords[job_number]</a></td>";

		if ($rowRecords['invoice_id'] == "0") {
			echo "<td width=\"16\">";
			echo "<a href=\"index.php?idx=timerecords&step=3&act=del&id=$rowRecords[timerecord_id]\" onclick=\"return confirmDelete();\">";
			echo "<img src=\"images/x.gif\" border=\"0\" alt=\"Delete\"></a>";
			echo "</td>";
		} else {
			echo "<td width=\"16\">&nbsp;</td>";
		}
		
		echo "</tr>";
	}
} else {
	echo "<tr class=\"table\">";
	echo "<td colspan=\"11\">No time records</td>";
	echo "</tr>";
}

?>
</table>

    	</td>
    </tr>
    <tr>
        <td colspan="4"><hr size="1" noshade></td>
    </tr>
</table>
