<script language="javascript">
<!--
function calctime() {

	timeInHH = document.form.timeInHH.value;
	timeInMM = document.form.timeInMM.value
	timeOutHH = document.form.timeOutHH.value
	timeOutMM = document.form.timeOutMM.value
	
	totalTime = (timeOutHH-timeInHH) + ((timeOutMM-timeInMM)/60);

	document.form.totalTime.value = totalTime;
	
	return false;
}

function checkForm() {
	if (document.form.job_id.value != "" ||
		document.form.type.value != "" ||
		document.form.timeInHH.value != "" ||
		document.form.timeOutHH.value != "" ||
		document.form.description_id.value != "" ||
		document.form.crewchief.checked ||
		document.form.rodman.checked) {
		alert ('Please finish adding your time record, or clear the form to continue.');
		return false;
	}
	if (!document.form.complete) { alert ('You cannot submit an empty timesheet.'); return false; }
	if (!document.form.complete.checked) { alert ('You must check complete to submit.'); return false; }

	else { return true; }
}

function checkAddFor () {
	if (document.form.job_id.value == "") { alert ('Please select a job.'); document.form.job_id.focus(); return false; }
	if (document.form.type.value == "") { alert ('Please select a type.'); document.form.type.focus(); return false; }
	if (document.form.timeInHH.value == "") { alert ('Please select your time in.'); document.form.timeInHH.focus(); return false; }
	if (document.form.timeOutHH.value == "") { alert ('Please select your time out.'); document.form.timeOutHH.focus(); return false; }
	if (document.form.description_id.value == "") { alert ('Please select a description.'); document.form.description_id.focus(); return false; }
	if (!document.form.crewchief.checked && !document.form.rodman.checked) {
		alert ('You must select either Crewchief, Rodman or both.');
		return false;
	}
	if (document.form.rodman.checked && document.form.rodman_id.value == "") {
		alert ('Please select a Rodman.');
		return false;
	}
	else { return true; }
}
//-->
</script>
<?php
if (isset ($_POST['complete']) && $_POST['complete'] == "yes") {															// if complete is checked, process timesheet and end page

	$sql = "UPDATE `timesheets` SET `complete`='1' WHERE `timesheet_id` = '$_POST[timesheet_id]'";
		
	if (@mysql_query($sql)) {
		printMessage("Timesheet Successfully Added");
	} else {
		printMessage("Error Adding Timesheet: " . mysql_error() . "");
	}

	printMessage ("[ <a href=\"index.php?idx=$idx\">Go Back</a> ]");
	
} else {

if (isset ($_POST['addtimesheet']) && $_POST['addtimesheet'] == "yes") {														// from previous page - adds timesheet to database and continues

	$sql = "INSERT INTO `timesheets` (`date`,`user_id`) VALUES ('$_POST[date]','$_POST[user_id]')";
		
	if (@mysql_query($sql)) {
	} else {
		printMessage("Error Adding Timesheet: " . mysql_error() . "");
		exit();
	}

	$timesheet_id = mysql_insert_id();
}

	
if (isset ($_POST['timeInHH'])) { $timeInHH = $_POST['timeInHH']; } else { $timeInHH = ''; }
if (isset ($_POST['timeInMM'])) { $timeInMM = $_POST['timeInMM']; } else { $timeInMM = ''; }
if (isset ($_POST['timeOutHH'])) { $timeOutHH = $_POST['timeOutHH']; } else { $timeOutHH = ''; }
if (isset ($_POST['timeOutMM'])) { $timeOutMM = $_POST['timeOutMM']; } else { $timeOutMM = ''; }

if (isset($_POST['addtimerecord'])) {																// adds time record to database and continues 

	$timeIn = $_POST['timeInHH'] .":". $_POST['timeInMM'] .":00";
	$timeOut = $_POST['timeOutHH'] .":". $_POST['timeOutMM'] .":00";
	
	if ($crewchief == "yes") {
		$user_id = $_SESSION["$site_session_prefix"]['session_userId'];
		
		$sql = "INSERT INTO `timerecords` (
					`timesheet_id`,
					`user_id`,
					`timerecord_date`,
					`job_id`,
					`type`,
					`timeIn`,
					`timeOut`,
					`totalTime`,
					`description_id`,
					`extDescription`,
					`userType`
				) VALUES (
					'$_POST[timesheet_id]',
					'$user_id',
					'$_POST[date]',
					'$_POST[job_id]',
					'$_POST[type]',
					'$timeIn',
					'$timeOut',
					'$_POST[totalTime]',
					'$_POST[description_id]',
					'$_POST[extDescription]',
					'0'
				)";
			
		if (@mysql_query($sql)) { } else { printMessage("Error Adding Time Record: " . mysql_error() . "");	}
	}
	if ($rodman == "yes") {
		$user_id = $_POST['rodman_id'];
		
		$sql = "INSERT INTO `timerecords` (
					`timesheet_id`,
					`user_id`,
					`timerecord_date`,
					`job_id`,
					`type`,
					`timeIn`,
					`timeOut`,
					`totalTime`,
					`description_id`,
					`extDescription`,
					`userType`
				) VALUES (
					'$_POST[timesheet_id]',
					'$user_id',
					'$_POST[date]',
					'$_POST[job_id]',
					'$_POST[type]',
					'$timeIn',
					'$timeOut',
					'$_POST[totalTime]',
					'$_POST[description_id]',
					'$_POST[extDescription]',
					'1'
				)";		
			
		if (!@mysql_query($sql)) { printMessage("Error Adding Time Record: " . mysql_error() . "");	}
	}
}

$result = mysql_query ("SELECT * FROM `timesheets` WHERE `timesheet_id` = '$timesheet_id'");
if (!$result) {	echo("Error Performing Query (line 104 - continue.php): " . mysql_error() . ""); exit(); }

$row = mysql_fetch_assoc($result);

?>
<form method="post" action="index.php" name="form">
<input type="hidden" name="idx" value="timesheets">
<input type="hidden" name="step" value="3">
<input type="hidden" name="timesheet_id" value="<?php echo $row['timesheet_id']; ?>">
<input type="hidden" name="user_id" value="<?php echo $row['user_id']; ?>">
<input type="hidden" name="date" value="<?php echo $row['date']; ?>">

	<table width="100%" border="0" cellspacing="1" cellpadding="2">
      <tr>
        <td colspan="2" class="header">Timesheet Editor</td>
      </tr>
      <tr>
        <td colspan="2"><hr size="1" noshade></td>
      </tr>
      <tr>
        <td width="150">Date</td>
        <td><?php echo $row['date']; ?></td>
      </tr>
      <tr>
        <td width="150">Created By</td>
        <td><?php echo $_SESSION["$site_session_prefix"]['session_name']; ?> (<?php echo $_SESSION["$site_session_prefix"]['session_userId']; ?>)</td>
      </tr>
      <tr>
        <td colspan="2"><hr size="1" noshade></td>
      </tr>
      <tr>
        <td colspan="2">
		<table width="100%"  border="0" cellpadding="2" cellspacing="2" class="tableborder">
		<tr class="tableheader">
			<td>Job #</td>
			<td>Type</td>
			<td align="center">Time In</td>
			<td align="center">Time Out</td>
			<td align="center">Total Hours</td>
			<td>Description</td>
			<td>Employee</td>
		</tr>
<?php


$user_types = array ("0" => "Crewchief", "1" => "Rodman");

$sql = "SELECT
			`timerecords`.*,
			`descriptions`.`description`,
			`users`.`username`,
			`jobs`.`number` AS 'job_number',
			`invoices`.`invoiceNum` AS 'invoice_number'
			
		FROM `timerecords`
			LEFT JOIN `descriptions` 	ON `timerecords`.`description_id` 	= `descriptions`.`description_id`
			LEFT JOIN `users` 			ON `timerecords`.`user_id` 			= `users`.`id`
			LEFT JOIN `jobs` 			ON `timerecords`.`job_id` 			= `jobs`.`job_id`
			LEFT JOIN `invoices` 		ON `timerecords`.`invoice_id` 		= `invoices`.`invoice_id`
			
		WHERE `timesheet_id` = '$timesheet_id'
		ORDER BY `timerecord_date`,`timeIn` ASC";

//$resultRecords = mysql_query ("SELECT * FROM `timerecords` WHERE `timesheet_id`='$timesheetId' ORDER BY `timerecord_date`,`timeIn` ASC");
$resultRecords = mysql_query ($sql);
if (!$resultRecords) {	echo("error performing query (line 151 - continue.php): " . mysql_error() . ""); exit(); }

if(mysql_num_rows($resultRecords)) {
	while($rowRecords = mysql_fetch_assoc ($resultRecords)) {
	
		if (!isset ($rowcount) || $rowcount == "1") { $bgclass = "class=\"tablealt\""; $rowcount = "0"; } else { $bgclass = "class=\"table\""; $rowcount++; }
		
		$user_type = $rowRecords['userType'];
		$user_type = $user_types["$user_type"];
	
		echo "<tr $bgclass>";
		echo "<td>$rowRecords[job_number]</td>";
		echo "<td>$rowRecords[type]</td>";
		echo "<td align=\"center\" width=\"75\">$rowRecords[timeIn]</td>";
		echo "<td align=\"center\" width=\"75\">$rowRecords[timeOut]</td>";
		echo "<td align=\"center\" width=\"75\">$rowRecords[totalTime]</td>";
		echo "<td>$rowRecords[description] $rowRecords[extDescription]</td>";
		echo "<td>$rowRecords[username] ($user_type)</td>";
		echo "</tr>";
	}
	echo "<tr class=\"tableheader\"><td colspan=\"7\">";
	echo "<input name=\"complete\" type=\"checkbox\" id=\"complete\" value=\"yes\" class=\"form\"> Complete";
	echo "</td></tr>";
} else {
	echo "<tr class=\"table\">";
	echo "<td colspan=\"11\">No time records</td>";
	echo "</tr>";
}

?>
</table>
		</td>
      </tr>
      <tr>
        <td colspan="2"><hr size="1" noshade></td>
      </tr>
      <tr>
        <td colspan="2" class="subheader">Add Time Record</td>
      </tr>
      <tr>
        <td colspan="2">
	  
		  <table width="100%"  border="0" cellspacing="2" cellpadding="2">
            <tr>
              <td>Date</td>
              <td><?php echo $row['date']; ?></td>
              <td width="150">Job Number <span class="required">*</span></td>
              <td><select name="job_id" id="job_id" class="form">
			  <option value=""></option>
                <?php
		$resultJobs = mysql_query ("SELECT * FROM `jobs` WHERE `complete`='0' ORDER BY `number` DESC");
		if (!$resultJobs) { echo("error performing query: " . mysql_error() . ""); exit(); }
		
		if(mysql_num_rows($resultJobs)) {
			while($rowJobs = mysql_fetch_assoc($resultJobs)) {
				echo "<option value=\"$rowJobs[job_id]\">$rowJobs[number] - $rowJobs[title]</option>";
			}
		}
		?>
              </select></td>
            </tr>
            <tr>
              <td width="150">Time In <span class="required">*</span></td>
              <td><select name="timeInHH" id="timeInHH" class="form" onchange="calctime(this);">
			  	<option value=""></option>
					<?php if ($timeOutHH <= "00") { ?><option value="00">12 am</option><?php } ?>
					<?php if ($timeOutHH <= "01") { ?><option value="01">1 am</option><?php } ?>
					<?php if ($timeOutHH <= "02") { ?><option value="02">2 am</option><?php } ?>
					<?php if ($timeOutHH <= "03") { ?><option value="03">3 am</option><?php } ?>
					<?php if ($timeOutHH <= "04") { ?><option value="04">4 am</option><?php } ?>
					<?php if ($timeOutHH <= "05") { ?><option value="05">5 am</option><?php } ?>
					<?php if ($timeOutHH <= "06") { ?><option value="06">6 am</option><?php } ?>
					<?php if ($timeOutHH <= "07") { ?><option value="07">7 am</option><?php } ?>
					<?php if ($timeOutHH <= "08") { ?><option value="08">8 am</option><?php } ?>
					<?php if ($timeOutHH <= "09") { ?><option value="09">9 am</option><?php } ?>
					<?php if ($timeOutHH <= "10") { ?><option value="10">10 am</option><?php } ?>
					<?php if ($timeOutHH <= "11") { ?><option value="11">11 am</option><?php } ?>
					<?php if ($timeOutHH <= "12") { ?><option value="12">12 pm</option><?php } ?>
					<?php if ($timeOutHH <= "13") { ?><option value="13">1 pm</option><?php } ?>
					<?php if ($timeOutHH <= "14") { ?><option value="14">2 pm</option><?php } ?>
					<?php if ($timeOutHH <= "15") { ?><option value="15">3 pm</option><?php } ?>
					<?php if ($timeOutHH <= "16") { ?><option value="16">4 pm</option><?php } ?>
					<?php if ($timeOutHH <= "17") { ?><option value="17">5 pm</option><?php } ?>
					<?php if ($timeOutHH <= "18") { ?><option value="18">6 pm</option><?php } ?>
					<?php if ($timeOutHH <= "19") { ?><option value="19">7 pm</option><?php } ?>
					<?php if ($timeOutHH <= "20") { ?><option value="20">8 pm</option><?php } ?>
					<?php if ($timeOutHH <= "21") { ?><option value="21">9 pm</option><?php } ?>
					<?php if ($timeOutHH <= "22") { ?><option value="22">10 pm</option><?php } ?>
					<?php if ($timeOutHH <= "23") { ?><option value="23">11 pm</option><?php } ?>
              </select>
              : 
              <input name="timeInMM" type="text" class="form" id="timeInMM" size="2" maxlength="2" value="<?php if ($timeOutMM == "") { echo "00"; } else { echo "$timeOutMM"; } ?>" onblur="calctime(this);"> 
              </td>
              <td width="150">Type <span class="required">*</span></td>
              <td><select name="type" id="type" class="form">
			  <option value=""></option>
                <option value="Field">Field Time</option>
                <option value="Field GPS">Field GPS Time</option>
                <option value="Travel">Travel Time</option>
                <option value="Office">Office Time</option>
              </select></td>
            </tr>
            <tr>
              <td>Time Out <span class="required">*</span></td>
              <td><select name="timeOutHH" id="timeOutHH" class="form" onchange="calctime(this);">
			  <option value=""></option>
					<?php if ($timeOutHH <= "00") { ?><option value="00">12 am</option><?php } ?>
					<?php if ($timeOutHH <= "01") { ?><option value="01">1 am</option><?php } ?>
					<?php if ($timeOutHH <= "02") { ?><option value="02">2 am</option><?php } ?>
					<?php if ($timeOutHH <= "03") { ?><option value="03">3 am</option><?php } ?>
					<?php if ($timeOutHH <= "04") { ?><option value="04">4 am</option><?php } ?>
					<?php if ($timeOutHH <= "05") { ?><option value="05">5 am</option><?php } ?>
					<?php if ($timeOutHH <= "06") { ?><option value="06">6 am</option><?php } ?>
					<?php if ($timeOutHH <= "07") { ?><option value="07">7 am</option><?php } ?>
					<?php if ($timeOutHH <= "08") { ?><option value="08">8 am</option><?php } ?>
					<?php if ($timeOutHH <= "09") { ?><option value="09">9 am</option><?php } ?>
					<?php if ($timeOutHH <= "10") { ?><option value="10">10 am</option><?php } ?>
					<?php if ($timeOutHH <= "11") { ?><option value="11">11 am</option><?php } ?>
					<?php if ($timeOutHH <= "12") { ?><option value="12">12 pm</option><?php } ?>
					<?php if ($timeOutHH <= "13") { ?><option value="13">1 pm</option><?php } ?>
					<?php if ($timeOutHH <= "14") { ?><option value="14">2 pm</option><?php } ?>
					<?php if ($timeOutHH <= "15") { ?><option value="15">3 pm</option><?php } ?>
					<?php if ($timeOutHH <= "16") { ?><option value="16">4 pm</option><?php } ?>
					<?php if ($timeOutHH <= "17") { ?><option value="17">5 pm</option><?php } ?>
					<?php if ($timeOutHH <= "18") { ?><option value="18">6 pm</option><?php } ?>
					<?php if ($timeOutHH <= "19") { ?><option value="19">7 pm</option><?php } ?>
					<?php if ($timeOutHH <= "20") { ?><option value="20">8 pm</option><?php } ?>
					<?php if ($timeOutHH <= "21") { ?><option value="21">9 pm</option><?php } ?>
					<?php if ($timeOutHH <= "22") { ?><option value="22">10 pm</option><?php } ?>
					<?php if ($timeOutHH <= "23") { ?><option value="23">11 pm</option><?php } ?>
              </select> 
                : 
              <input name="timeOutMM" type="text" class="form" id="timeOutMM" onblur="calctime(this);" value="00" size="2" maxlength="2"> 
              </td>
              <td width="150">Total Time</td>
              <td><input name="totalTime" type="text" id="totalTime" size="5" maxlength="14" class="form" readonly> 
              Hours</td>
            </tr>
            <tr>
              <td width="150">Description <span class="required">*</span></td>
              <td><select name="description_id" id="description_id" class="form">
			  <option value=""></option>
        <?php
		$resultDesc = mysql_query ("SELECT * FROM `descriptions` ORDER BY `description` ASC");
		if (!$resultDesc) { echo("error performing query: " . mysql_error() . ""); exit(); }
		
		if(mysql_num_rows($resultDesc)) {
			while($rowDesc = mysql_fetch_assoc ($resultDesc)) {
				echo "<option value=\"$rowDesc[description_id]\">$rowDesc[description]</option>";
			}
		}
		?>
              </select></td>
              <td>Extended Description </td>
              <td><input name="extDescription" type="text" id="extDescription" size="40" maxlength="250" class="form"></td>
            </tr>
            <tr>
              <td width="150">Crewchief</td>
              <td><?php echo $_SESSION["$site_session_prefix"]['session_name']; ?></td>
              <td>Rodman</td>
              <td><select name="rodman_id" id="rodman_id" class="form">
			  <option value=""></option>
                <?php
				$resultrodman = mysql_query ("SELECT * FROM `users`  WHERE `id` <> '{$_SESSION["$site_session_prefix"]['session_userId']}' AND `active` = '1' AND `rodman` = '1' ORDER BY `name` ASC");
				if (!$resultrodman) { echo("error performing query: " . mysql_error() . ""); exit(); }
				
				if (mysql_num_rows($resultrodman)) {
					while ($rowrodman = mysql_fetch_assoc($resultrodman)) {
						echo "<option value=\"$rowrodman[id]\">$rowrodman[name]</option>";
					}
				}
				?>
              </select></td>
            </tr>
            <tr>
              <td width="150">Add For <span class="required">*</span></td>
              <td colspan="3"><input name="crewchief" type="checkbox" class="form" id="crewchief" value="yes" checked>
Crewchief
  <input name="rodman" type="checkbox" class="form" id="rodman" value="yes" checked>
Rodman</td>
            </tr>
            <tr>
              <td width="150">&nbsp;</td>
              <td colspan="3"><input type="submit" name="addtimerecord" value="   Add   " class="form" id="addtimerecord" onclick="return checkAddFor(this);"></td>
            </tr>
          </table>
		  </td>
      </tr>
      <tr>
        <td colspan="2"><hr size="1" noshade></td>
      </tr>
      <tr valign="top">
        <td class="required">* Required Fields</td>
        <td align="right"><input type="image" name="Submit" value="Submit" class="form" src="images/button_ok.gif" onclick="return checkForm(this);">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="index.php?idx=<?php echo $idx; ?>"><img src="images/button_cancel.gif" border="0"></a></td>
      </tr>
</table>
</form>

<?php
}

?>
