<?php
$oldestTimesheetYear = oldestYear("timesheets","date","");

$currentYear = date("Y");

if (!isset($timesheetsYear) || !isset($timesheetsMonth)) {
	$timesheetsMonth = date("m");
	$timesheetsYear = date("Y");
}
?>

<table width="100%"  border="0" cellspacing="2" cellpadding="2">
  <tr>
    <td class="header">Timesheets</td>
<form method="post" action="index.php" name="timesheetsDate">
<td class="main" align="right">
<input type="hidden" name="idx" value="timesheets">
<select name="timesheetsMonth" id="timesheetsMonth" class="form">
  <option value="%" <?php if ($timesheetsMonth == "%") { echo "selected"; } ?>>All Months</option>
  <option value="01" <?php if ($timesheetsMonth == "01") { echo "selected"; } ?>>January</option>
  <option value="02" <?php if ($timesheetsMonth == "02") { echo "selected"; } ?>>February</option>
  <option value="03" <?php if ($timesheetsMonth == "03") { echo "selected"; } ?>>March</option>
  <option value="04" <?php if ($timesheetsMonth == "04") { echo "selected"; } ?>>April</option>
  <option value="05" <?php if ($timesheetsMonth == "05") { echo "selected"; } ?>>May</option>
  <option value="06" <?php if ($timesheetsMonth == "06") { echo "selected"; } ?>>June</option>
  <option value="07" <?php if ($timesheetsMonth == "07") { echo "selected"; } ?>>July</option>
  <option value="08" <?php if ($timesheetsMonth == "08") { echo "selected"; } ?>>August</option>
  <option value="09" <?php if ($timesheetsMonth == "09") { echo "selected"; } ?>>September</option>
  <option value="10" <?php if ($timesheetsMonth == "10") { echo "selected"; } ?>>October</option>
  <option value="11" <?php if ($timesheetsMonth == "11") { echo "selected"; } ?>>November</option>
  <option value="12" <?php if ($timesheetsMonth == "12") { echo "selected"; } ?>>December</option>
</select>
<select name="timesheetsYear" id="timesheetsYear" class="form">
<?php
for ($i = $currentYear; $i >= $oldestTimesheetYear; $i--) {
	if ($timesheetsYear == $i) { $selected = "selected"; } else { $selected = ""; }
	echo "<option value=\"$i\" $selected>$i</option>";
}
?>
</select>
<input type="submit" name="Submit" value="Go" class="form"></td></form>
  </tr>
  <tr>
    <td class="submenu" colspan="2">[ <a href="index.php?idx=timesheets&step=2&act=add">Add Timesheet</a> ]</td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="2" cellpadding="2">
  <tr class="tableheader">
    <td width="15">&nbsp;</td>
    <td>id</td>
    <td>Date</td>
    <td>Created By</td>
    <td>Complete?</td>
	<td>Time Records</td>
    <td width="15">&nbsp;</td>
  </tr>

<?php
$sql = "SELECT
			`timesheets`.`timesheet_id`,
			`timesheets`.`date`,
			`timesheets`.`complete`,
			`users`.`username`,
			COUNT(`timerecords`.`timesheet_id`) AS 'time_records'
		FROM `timesheets`
			LEFT JOIN `users` ON `timesheets`.`user_id` = `users`.`id`
			LEFT JOIN `timerecords` ON `timesheets`.`timesheet_id` = `timerecords`.`timesheet_id`	
		WHERE `date` LIKE '$timesheetsYear-$timesheetsMonth-%'
		GROUP BY `timesheets`.`timesheet_id`
		ORDER BY `timesheets`.`timesheet_id` DESC";

$result = mysql_query ($sql);
if (!$result) {	echo("error performing query: " . mysql_error() . ""); exit(); }

$rowcount = "0";

if(mysql_num_rows($result)) {
	while($row = mysql_fetch_assoc($result)) {
	
		if ($rowcount == "1") { $bgclass = "class=\"tablealt\""; $rowcount = "0"; } else { $bgclass = "class=\"table\""; $rowcount++; }
		
		if ($row['complete'] == "0") {
			$complete = "No (<a href=\"index.php?idx=timesheets&step=3&timesheet_id=$row[timesheet_id]\">Continue</a>)";
		} else if ($row['complete'] == "1") {
			$complete = "Yes";
			
		}
		//$createdby = mysql_result (mysql_query ("SELECT `name` FROM `users` WHERE `id`='$row[2]'"), 0);
		//$timerecords = mysql_num_rows (mysql_query ("SELECT * FROM `timerecords` WHERE `timesheet_id`='$row[timesheet_id]'"));
		
		echo "<tr $bgclass>";
		echo "<td width=\"15\"><a href=\"index.php?idx=timesheets&step=5&id=$row[timesheet_id]\"><img src=\"images/_search.gif\" border=\"0\" alt=\"View\"></a></td>";
		echo "<td>$row[timesheet_id]</td>";
		echo "<td>$row[date]</td>";
		echo "<td>$row[username]</td>";
		echo "<td>$complete</td>";
		echo "<td>$row[time_records]</td>";
		echo "<td width=\"16\"><a href=\"javascript:confirmDelete('index.php?idx=timesheets&step=4&act=del&id=" . $row['timesheet_id'] . "')\"><img src=\"images/x.gif\" border=\"0\" alt=\"Delete\"></a></td>";
		echo "</tr>";
		
	}
} else {
	echo "<tr bgcolor=\"#EEEEEE\" class=\"main\">";
	echo "<td colspan=\"7\"><div align=\"center\">No timesheets</div></td>";
	echo "</tr>";
}           
?>
</table>
