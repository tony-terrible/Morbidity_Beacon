<?php
switch($step){
	case "1":									// index
		include("phplib/timesheets/idx.php");
		break;
	case "2":									// add/edit
		include("phplib/timesheets/edit.php");
		break;
	case "3":									// continue
		include("phplib/timesheets/continue.php");
		break;
	case "4":									// done
		include("phplib/timesheets/done.php");
		break;
	case "5":									// view
		include("phplib/timesheets/view.php");
		break;
	default:									// index
		include("phplib/timesheets/idx.php");
		break;
}
?>