<?php

if ($act == "add" ) {				// ####################### ADD #######################

	$sql = "UPDATE `timesheets` SET `complete`='1' WHERE `id`='$id'";
		
	if (@mysql_query($sql)) {
		printMessage("Timesheet Successfully Added");
	} else {
		printMessage("Error Adding Timesheet: " . mysql_error() . "");
	}	
}


if ($act == "del" ) {				// ####################### DEL #######################

	if ($_SESSION["$site_session_prefix"]['session_user_level'] == "0") {	
	
		// Check for billed time records
		$resultCheckBilled = mysql_query ("SELECT * FROM `timerecords` WHERE ((`timesheet_id`='$id') && (`invoice_id` != '0')) LIMIT 0,1");
		if (!$resultCheckBilled) {	echo("error performing query: " . mysql_error() . ""); exit(); }
		
		if (mysql_num_rows($resultCheckBilled)) {
			while($rowCheckBilled = mysql_fetch_row($resultCheckBilled)) {
				printMessage ("<b>Error</b>: You cannot delete a timesheet with billed time records.");
			}
		} else {
		
			// if no billed time records found, delete time records and time sheet
			$timerecordsql = "DELETE FROM `timerecords` WHERE `timesheet_id` = '$id'";
			if (@mysql_query($timerecordsql)) { 
				printMessage("Timesheet Records Successfully Deleted");
				$sql = "DELETE FROM `timesheets` WHERE `timesheet_id` = '$id'";
		
				if (@mysql_query($sql)) { 
					printMessage("Timesheet Successfully Deleted");
				} else {
					printMessage("Error Deleting Timesheet: " . mysql_error() . "");
				}
			} else {
				printMessage("Error Deleting Timesheet Records: " . mysql_error() . "");
			}
		}
		
	} else {
		printMessage ("Access Denied");
	}
}

printMessage ("[ <a href=\"index.php?idx=$idx\">Go Back</a> ]");
?>