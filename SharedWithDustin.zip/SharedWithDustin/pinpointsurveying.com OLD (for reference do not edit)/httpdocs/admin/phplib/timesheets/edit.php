<?php
$checkJobs = mysql_fetch_row (mysql_query ("SELECT * FROM `jobs` LIMIT 0,1"));
if ($checkJobs == "") { printMessage ("<b>Error</b>:  You cannot add a timesheet without a job, please add one.");	exit(); }

$checkDescriptions = mysql_fetch_row (mysql_query ("SELECT * FROM `descriptions` LIMIT 0,1"));
if ($checkDescriptions == "") {	printMessage ("<b>Error</b>:  You cannot add a timesheet without a description, please add one.");	exit(); }
?>

<script language="JavaScript" src="calendar1.js"></script>
<script language="JavaScript">
<!--
function checkForm(form) {
	if (document.form.date.value == "") 	{ alert ('Please enter a date.'); 		document.form.date.focus(); 	return false; }
	else { return true; }
}
//-->
</script>

<form method="post" action="index.php" name="form">
<input type="hidden" name="idx" value="timesheets">
<input type="hidden" name="step" value="3">
<input type="hidden" name="user_id" value="<?php echo $_SESSION["$site_session_prefix"]['session_userId']; ?>">
<input type="hidden" name="addtimesheet" value="yes">

	<table width="100%" border="0" cellspacing="1" cellpadding="2">
      <tr>
        <td colspan="2" class="header">Timesheet Editor</td>
      </tr>
      <tr>
        <td colspan="2"><hr size="1" noshade></td>
      </tr>
      <tr>
        <td width="150">Date <span class="required">*</span></td>
        <td><script>DateInput('date', false, 'YYYY-MM-DD', '<?php echo date ("Y-m-d"); ?>')</script></td>
      </tr>
      <tr>
        <td width="150">Created By</td>
        <td>[<?php echo $_SESSION["$site_session_prefix"]['session_userId']; ?>] <?php echo $_SESSION["$site_session_prefix"]['session_name']; ?></td>
      </tr>
      <tr>
        <td colspan="2"><hr size="1" noshade></td>
      </tr>
      <tr valign="top">
        <td class="required">* Required Fields</td>
        <td align="right"><input name="Submit" type="image" src="images/button_ok.gif" class="form" value="Submit" onclick="return checkForm(this);">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="index.php?idx=<?php=$idx?>"><img src="images/button_cancel.gif" border="0"></a></td>
      </tr>
</table>
