<?php
switch($step){
	case "1":									// index
		include("phplib/userReports/idx.php");
		break;
	case "2":									// view
		include("phplib/userReports/view.php");
		break;
	default:									// index
		include("phplib/userReports/idx.php");
		break;
}
?>