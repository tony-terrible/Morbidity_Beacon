<form method="post" action="index.php" name="form">
<input type="hidden" name="idx" value="userReports">
<input type="hidden" name="step" value="2">
<table width="100%"  border="0" cellspacing="2" cellpadding="2">
  <tr>
    <td class="header">User Reports</td>
  </tr>
  <tr>
    <td class="submenu">&nbsp;</td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="2" cellpadding="2">
  <tr>
    <td colspan="2"><hr size="1" noshade></td>
  </tr>
  <tr>
    <td width="150">User:</td>
    <td><select name="userId" id="userId" class="form">
		<option value=""></option>
        <?php
		$result = mysql_query ("SELECT * FROM `users` ORDER BY `name` ASC");
		if (!$result) { echo("error performing query: " . mysql_error() . ""); exit(); }
		
		if(mysql_num_rows($result)) {
			while($row = mysql_fetch_assoc($result)) {
				echo "<option value=\"$row[id]\">$row[name]</option>";
			}
		}
		?>
        </select>
	</td>
  </tr>
  <tr>
    <td>Start Date: </td>
    <td><script>DateInput('startDate', false, 'YYYY-MM-DD', '<?php echo date ("Y-m-d"); ?>')</script></td>
  </tr>
  <tr>
    <td>End Date: </td>
    <td><script>DateInput('endDate', false, 'YYYY-MM-DD', '<?php echo date ("Y-m-d"); ?>')</script></td>
  </tr>
  <tr>
    <td colspan="2"><b><font color="#FF0000"><br>* Remember: Overtime hours will be calculated on the ENTIRE time period you select</font></b></td>
  </tr>
      <tr>
        <td colspan="2" class="mainlight"><hr size="1" noshade></td>
      </tr>
      <tr>
        <td align="right" colspan="2"><input name="Submit" type="image" src="images/button_ok.gif" class="form" value="Submit" onClick="return checkForm(this);">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="index.php?idx=<?=$idx?>"><img src="images/button_cancel.gif" border="0"></a></td>
      </tr>
</table>