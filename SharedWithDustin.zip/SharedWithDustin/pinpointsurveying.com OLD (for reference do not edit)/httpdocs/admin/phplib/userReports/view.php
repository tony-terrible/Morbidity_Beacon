<?php

$result = mysql_query ("SELECT * FROM `users` WHERE `id`='$userId'");
if (!$result) {	echo("error performing query: " . mysql_error() . ""); exit(); }

$row = mysql_fetch_assoc($result);
extract ($row);

$overtimeWage = sprintf("%01.2f", ($hourlyWage * 1.5)); ;

$resultHours = mysql_query ("SELECT * FROM `timerecords` WHERE ((`user_id`='$userId') && ((`timerecord_date` >= '$startDate') && (`timerecord_date` <= '$endDate')))");
if (!$resultHours) { echo("error performing query: " . mysql_error() . ""); exit(); }

if (mysql_num_rows($resultHours)) {
	while($rowHours = mysql_fetch_row($resultHours)) {
		$regularHours = $regularHours + $rowHours[8];
	}
	if ($regularHours > "40") {
		$overtimeHours = $regularHours - "40";
		$regularHours = "40";
		
		$regularPay = sprintf("%01.2f", $regularHours * $hourlyWage);
		$overtimePay = sprintf("%01.2f", $overtimeHours * $overtimeWage);
	} else {
		$overtimeHours = "0";
		$regularPay = sprintf("%01.2f", $regularHours * $hourlyWage);
		$overtimePay = sprintf("%01.2f", $overtimeHours * $overtimeWage);
	}
}

$vacationPay = sprintf("%01.2f", (($regularPay + $overtimePay) * $vacationRate));
$totalPay = sprintf("%01.2f", $regularPay + $overtimePay + $vacationPay);

list($startYear,$startMonth,$startDay) = split("-",$startDate);
$startDateFormatted = date("l, F jS, Y", mktime(0,0,0,$startMonth,$startDay,$startYear));

list($endYear,$endMonth,$endDay) = split("-",$endDate);
$endDateFormatted = date("l, F jS, Y", mktime(0,0,0,$endMonth,$endDay,$endYear));

?>

<table width="100%"  border="0" cellspacing="2" cellpadding="2">
  <tr>
    <td class="header"><?=$name?></td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="2" cellpadding="2">
  <tr>
    <td colspan="2"><hr size="1" noshade></td>
  </tr>
  <tr>
    <td width="50%" valign="top"><table width="100%" border="0" cellpadding="2" cellspacing="2" class="tableborder">
      <tr class="tableheader">
        <td colspan="2">For Period</td>
        </tr>
      <tr class="table">
        <td>Starting:</td>
        <td><b>
          <?=$startDateFormatted?>
        </b></td>
      </tr>
      <tr class="table">
        <td>Ending:</td>
        <td><b>
          <?=$endDateFormatted?>
        </b></td>
      </tr>
    </table>
      <br>
      <table width="100%" border="0" cellpadding="2" cellspacing="2" class="tableborder">
      <tr class="tableheader">
        <td colspan="2">Salary Information </td>
        </tr>
      <tr class="table">
        <td width="200">Hourly Wage:</td>
        <td width="50"><div align="right">$
              <?=$hourlyWage?>
        </div></td>
      </tr>
      <tr class="table">
        <td width="200">Overtime Wage: </td>
        <td width="50"><div align="right">$
              <?=$overtimeWage?>
        </div></td>
      </tr>
      <tr class="table">
        <td width="200">Vacation Rate: </td>
        <td width="50"><div align="right"><?=$vacationRate?>%
          </div></td>
      </tr>
      <tr>
        <td width="200">&nbsp;</td>
        <td width="50"><div align="right"></div></td>
      </tr>
      <tr class="table">
        <td width="200">Regular Hours:</td>
        <td width="50"><div align="right"><?=$regularHours?>
          </div></td>
      </tr>
      <tr class="table">
        <td width="200">Overtime Hours:</td>
        <td width="50"><div align="right"><?=$overtimeHours?>
          </div></td>
      </tr>
      <tr>
        <td width="200">&nbsp;</td>
        <td width="50"><div align="right"></div></td>
      </tr>
      <tr class="table">
        <td width="200">Regular Pay: </td>
        <td width="50"><div align="right">$
              <?=$regularPay?>
        </div></td>
      </tr>
      <tr class="table">
        <td width="200">Overtime Pay:</td>
        <td width="50"><div align="right">$
              <?=$overtimePay?>
        </div></td>
      </tr>
      <tr class="table">
        <td width="200">Vacation Pay: </td>
        <td width="50"><div align="right">$
              <?=$vacationPay?>
        </div></td>
      </tr>
      <tr class="table">
        <td width="200"><strong>Total Pay:</strong></td>
        <td width="50"><div align="right"><strong>$
              <?=$totalPay?>
        </strong></div></td>
      </tr>
      <tr>
        <td colspan="2"><b><font color="#FF0000"><br>* This DOES NOT include ANY deductions: CPP, EI, Taxes, etc<br>
		* Overtime is calculated after 40 hours in the selected time period</font></b></td>
        </tr>
    </table></td><td width="50%" valign="top">
<table width="100%"  border="0" cellpadding="2" cellspacing="2" class="tableborder">
              <tr class="tableheader">
				<td>Date (YYYY-MM-DD)</td>
				<td>Day of the Week</td>
                <td align="right">Hours</td>
              </tr>
<?php
# if you can't figure this one out you better get a new job
$totalDays = array(0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);

# make sure user didn't enter the start date as being LATER than the end date, otherwise we have an infinite loop
if ($startYear > $endYear || $startYear == $endYear && $startMonth > $endMonth  || $startYear == $endYear && $startMonth == $endMonth && $startDay > $endDay) {
	print "you're an idiot!!!";
	exit;
}


while(1) { # while(1) creates an infinite loop that can only stop using 'break' which we will do once the the dates are all at the end date

	$startMonth2=$startMonth*1;

	// if leap year, modify $totaldays array appropriately
	if (date("L", mktime(0,0,0,$startMonth,1,$startYear))){
		$totalDays[2] = 29;	
	}

	### Display HTML output
	$resultHW = mysql_query ("SELECT * FROM `timerecords` WHERE ((`user_id`='$userId') && (`timerecord_date`='$startYear-$startMonth-$startDay'))");
	if (!$resultHW) { echo("error performing query: " . mysql_error() . ""); exit(); }
	
	$HWday = "0";
	
	if(mysql_num_rows($resultHW)) {
		while($rowHW = mysql_fetch_row($resultHW)) {
			$HWday = sprintf("%01.2f", ($HWday + $rowHW[8]));
		}
	} else {
	 $HWday = "0.00";
	}
	
	$totalHours = sprintf("%01.2f", ($totalHours + $HWday));

	$displayDate = date("Y-m-d", mktime(0,0,0,$startMonth,$startDay,$startYear));
	$displayDay = date("l", mktime(0,0,0,$startMonth,$startDay,$startYear));
	if ($rowcount == "1") { $bgclass = "class=\"tablealt\""; $rowcount = "0"; } else { $bgclass = "class=\"table\""; $rowcount++; }
	print "<tr $bgclass>";
	print "<td class=\"main\">$displayDate</td>";
	print "<td class=\"main\">$displayDay</td>";
	if ($HWday != "0.00") {
		print "<td class=\"main\" align=\"right\"><b>$HWday</b></td>";
	} else {
		print "<td class=\"main\" align=\"right\">$HWday</td>";
	}
	print "</tr>";
	### End HTML output
	
	# increment the day, then check for month/year ends and do the appropriate action
	$startDay++;
	# check if we are at the ending date, if so, break the loop.
	if (($startYear == $endYear) && ($startMonth == $endMonth) && ($startDay == ($endDay+1))) { # add 1 to the end day to keep the loop going until the last day, otherwise it exits on the last day prior
		break;
	}

	if (($totalDays[$startMonth2]+1) == $startDay) {
		$startMonth++;
		$startDay=1;
		if ($startMonth==13) {
			$startMonth=1;
			$startYear++;
		}
	}
	
	# test to see if the day for some reason gets out of hand and hits 50 in which case the loop will break, removeable if you choose.
	if ($startDay==50) { break; }
}
echo "<tr><td align=\"right\" colspan=\"2\"><b>Total:</b></td><td align=\"right\"><b>$totalHours</b></td></tr>";

?>
      </table>
	</td>
  </tr>
      <tr>
        <td colspan="2" class="mainlight"><hr size="1" noshade></td>
      </tr>
</table>
