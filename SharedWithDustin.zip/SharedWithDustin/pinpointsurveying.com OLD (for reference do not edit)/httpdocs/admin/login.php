<?php

session_start();

include ("includes/db.php");
include ("includes/functions.php");
include ("includes/config.php");

removeBans();

$user_ip_address = $_SERVER['REMOTE_ADDR'];

################################################################
### Check current users IP against the banned IPs
################################################################

$result = mysql_query ("SELECT * FROM `user_bans` WHERE `banned_ip_address` = '$user_ip_address'");
if (!$result) {	echo("error performing query: " . mysql_error() . ""); exit(); }

if (mysql_num_rows($result)) {

	echo "Internal Error.  Please contact the site administrator.";

} else {

	if (isset($_POST['Login'])) {
	
		################################################################
		### Login form has been submitted, check credentials
		################################################################

		// Check that login_email and login_password have values
		if (!empty($_POST['login_email']) && !empty($_POST['login_password'])) {
	
			// Check login_email is valid
			if (checkEmail($_POST['login_email'])) {
				
				$login_email = $_POST['login_email'];
				$login_password = md5($_POST['login_password']);
			
				// Email address & password are supplied - check email address against ban database
				$result = mysql_query ("SELECT * FROM `user_bans` WHERE `banned_email_address` = '$login_email'");
				if (!$result) {	echo("error performing query: " . mysql_error() . ""); exit(); }
				
				if (!mysql_num_rows($result)) {
				
					// Email address is not banned, so check the email address and password are correct
					$result = mysql_query ("SELECT * FROM `users` WHERE `email` = '$login_email' && `password` = '$login_password'");
					if (!$result) {	echo("error performing query: " . mysql_error() . ""); exit(); }
					
					if (mysql_num_rows($result)) {
						
						$row = mysql_fetch_assoc ($result);
					
						################################################################
						### Login is correct - start session and pass to index.php
						################################################################
				
						$_SESSION["$site_session_prefix"]['session_name'] = $row['username'];
						$_SESSION["$site_session_prefix"]['session_user_level'] = $row['userlevel'];
						$_SESSION["$site_session_prefix"]['session_userId'] = $row['id'];
						$_SESSION["$site_session_prefix"]['user_email'] = $login_email;
						$_SESSION["$site_session_prefix"]['user_password'] = $login_password;
						
						update_login_history ("$login_email", "Success");
						
						header ("Location: index.php");	
				
					} else {
						$login_error_message = "Email address and/or password error";
						update_login_history ("$_POST[login_email]", "Password incorrect");
					}
				} else {
					$login_error_message = "Your account has been temporary suspended,<br>please try again in five minutes.";
					update_login_history ("$_POST[login_email]", "Banned email address");
				}
			} else {
				$login_error_message = "Invalid email address format";
				update_login_history ("$_POST[login_email]", "Invalid email address format");		
			}
		} else {
			$login_error_message = "You must provide both an email address and password";
			update_login_history ("$_POST[login_email]", "Incomplete Login");
		}
	} // end if (isset($_POST['Login_x']))
	
	if (isset($_POST['Forgot'])) {
	
		################################################################
		### Forgot password
		################################################################
		
		if (!empty($_POST['login_email'])) {
		
					
			
				$user_email_address = $_POST['login_email'];
				$new_password = randomPassword();
				$new_password_md5 = md5($new_password);
						
				mysql_query ("UPDATE `users` SET `password` = '$new_password_md5' WHERE `email` = '$user_email_address'");
				
				if (mysql_affected_rows() > 0) {

					$headers = "From: PinPoint Surveying <no-reply@pinpoint.com>\n";
					$headers .= "Reply-To: PinPoint Surveying <no-reply@pinpoint.com>\n";
					$headers .= "Return-Path: PinPoint Surveying <no-reply@pinpoint.com>\n";
					$headers .= "X-Mailer: PHP v" . phpversion() . "\n";
					$headers .= "Content-Type: text/plain; charset=iso-8859-1\n";
					$headers .= "Content-Transfer-Encoding: 8bit";
					
					$message = "PinPoint Surveying \r";
					$message .= "----------------------------------------------- \r";
					$message .= " - Your Email Address: $user_email_address \r";
					$message .= " - Generated Password: $new_password \r";
					$message .= "----------------------------------------------- \r";
					$message .= "http://www.pinpointsurveying.com/admin/ \r";
					$message .= "----------------------------------------------- \r";					
					$message .= "IP: $_SERVER[REMOTE_ADDR]";
					
					mail ("$user_email_address", "New Password", "$message", "$headers");
					
					$login_error_message = "Your new password has been sent!";
					}
								
			
			} else {
			$login_error_message = "You must provide an email address";}
		
	
	}
	
	?>
	<html>
	<head>
	<title><?php echo $sitename; ?></title>
	<link href="styles.css" rel="stylesheet" type="text/css">
	</head>
	<body>
	
	<table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
	  <tr>
		<td width="100%" height="100%" align="center" valign="middle">
			
		<form action="login.php" method="POST">
		<table width="400" border="0" cellspacing="2" cellpadding="2">
			<tr> 
				<td colspan="2"><div align="center">
				<img src="<?php echo $sitelogo; ?>" width="<?php echo $sitelogowidth; ?>" height="<?php echo $sitelogoheight;?>">
				</div></td>
			</tr>
			<tr> 
			  <td colspan="2"><hr size="1"></td>
			</tr>
			<tr> 
			  <td width="120"><div align="right">Email Address:</div></td>
			  <td><input name="login_email" type="text" class="form" size="30" maxlength="60" <?php if (isset($_POST['login_email'])) { echo "value=\"".$_POST['login_email']."\"";} ?>></td>
			</tr>
			<tr> 
			  <td width="120"><div align="right">Password:</div></td>
			  <td><input name="login_password" type="password" class="form" size="30" maxlength="20"></td>
			</tr>
			<?php if (isset($login_error_message)) { ?>
			<tr>
			  <td width="120" valign="top"><div align="right">Please Note:</div></td>
			  <td><b><?php echo $login_error_message; ?></b></td>
			</tr>
			<?php } ?>			
			<tr>
			  <td width="120">&nbsp;</td>
			  <td><input name="Login" type="submit" value=" &nbsp; Login &nbsp; " class="form"> &nbsp; 
			  <input name="Forgot" type="submit" value=" &nbsp; Forgot &nbsp; " class="form"></td>
			</tr>
			<tr> 
			  <td colspan="2"><hr size="1"></td>
		  </tr>
		  </table>
		  </form>
		  </td>
	  </tr>
	</table>
	</body>
	</html>
	<?php
}
####################################################
//Old login
/*
?>



<?
session_start();
if(!isset($session_username) | !isset($session_password)) {
?>
<html>
<head>
<title><?=$sitename?></title>
<link href="styles.css" rel="stylesheet" type="text/css">
</head>
<body>

<table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="100%" height="100%" align="center" valign="middle">
		
	<form action="<?=$PHP_SELF?><? if($QUERY_STRING){ echo"?". $QUERY_STRONG;} ?>" method="POST">
	<table width="400" border="0" cellspacing="2" cellpadding="2">
        <tr> 
            <td colspan="2"><div align="center"><img src="<?=$sitelogo?>" width="<?=$sitelogowidth?>" height="<?=$sitelogoheight?>"></div></td>
        </tr>
        <tr> 
          <td colspan="2"><hr size="1"></td>
        </tr>
        <tr> 
          <td width="151" class="mainlight"><div align="right">Username:</div></td>
          <td width="235"><input name="session_username" type="text" class="form" size="20" maxlength="20"></td>
        </tr>
        <tr> 
          <td class="mainlight"><div align="right">Password:</div></td>
          <td><input name="session_password" type="password" class="form" size="20" maxlength="20"></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td><input name="Submit" type="image" src="images/button_login.gif" class="form" value="Login"></td>
        </tr>
        <tr> 
          <td colspan="2"><hr size="1"></td>
          </tr>
      </table>
	  </form>
	  
	  </td>
  </tr>
</table>
</body>
</html>

<?
exit();
}

// if all is well so far

session_register("session_username");
session_register("session_password"); // register username and password as session variables

$sql = mysql_query("SELECT * FROM `users` WHERE `username` = '$session_username'");
$fetch = mysql_fetch_array($sql);
$numrows = mysql_num_rows($sql);

if($numrows != "0" & $session_password == $fetch["password"]) {
	$valid_user = 1;
	} else {
	$valid_user = 0;
	}
	
if(!($valid_user)) {
session_unset();
session_destroy();
?>
<html>
<head>
<title><?=$sitename?></title>
<link href="styles.css" rel="stylesheet" type="text/css">
</head>
<body>

<table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="100%" height="100%" align="center" valign="middle">
		
	<form action="<?=$PHP_SELF?><? if($QUERY_STRING){ echo"?". $QUERY_STRONG;} ?>" method="POST">
	<table width="400" border="0" cellspacing="2" cellpadding="2">
        <tr> 
            <td colspan="2"><div align="center"><img src="<?=$sitelogo?>" width="<?=$sitelogowidth?>" height="<?=$sitelogoheight?>"></div></td>
        </tr>
        <tr> 
          <td colspan="2"><hr size="1"></td>
        </tr>
        <tr> 
          <td width="151" class="mainlight"><div align="right">Username:</div></td>
          <td width="235"><input name="session_username" type="text" class="form" size="20" maxlength="20"></td>
        </tr>
        <tr> 
          <td class="mainlight"><div align="right">Password:</div></td>
          <td><input name="session_password" type="password" class="form" size="20" maxlength="20"></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td><input name="Submit" type="image" src="images/button_login.gif" class="form" value="Login"></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td class="main_color">Invalid Username or Password</td>
        </tr>
        <tr> 
          <td colspan="2"><hr size="1"></td>
          </tr>
      </table>
	  </form>
	  
	  </td>
  </tr>
</table>
</body>
</html>

<?php
exit();
}

$session_name = $fetch["name"];
session_register("session_name");

$session_userlevel = $fetch["userlevel"];
session_register("session_userlevel");

$session_userId = $fetch["id"];
session_register("session_userId");
*/
?>