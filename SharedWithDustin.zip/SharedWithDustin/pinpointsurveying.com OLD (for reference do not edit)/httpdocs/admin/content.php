<?php

##Moved from index.php to content.php for a cleaner index.php
if (isset($_POST['idx'])){
	$idx = $_POST['idx'];
} else if (isset ($_GET['idx'])) {
	$idx = $_GET['idx'];
} else {
	$idx = "";
}

if (isset($_POST['step'])){
	$step = $_POST['step'];
} else if (isset ($_GET['step'])) {
	$step = $_GET['step'];
} else {
	$step = "";
}

if (isset($_POST['act'])){
	$act = $_POST['act'];
} else if (isset ($_GET['act'])) {
	$act = $_GET['act'];
} else {
	$act = "";
}
		
switch($idx){
	case "timesheets":
		include ("phplib/timesheets/timesheets.php");
		break;
	case "clients":
		if ($_SESSION["$site_session_prefix"]['session_user_level'] == "0") {	
			include ("phplib/clients/clients.php");
		} else {
			printMessage ("Access Denied");
		}
		break;
	case "timerecords":
		include ("phplib/timerecords/timerecords.php");
		break;
	case "jobs":
		if ($_SESSION["$site_session_prefix"]['session_user_level'] == "0") {	
			include ("phplib/jobs/jobs.php");
		} else {
			printMessage ("Access Denied");
		}
		break;
	case "invoices":
		if ($_SESSION["$site_session_prefix"]['session_user_level'] == "0") {	
			include ("phplib/invoices/invoices.php");
		} else {
			printMessage ("Access Denied");
		}
		break;

	case "invoice_items":
		if ($_SESSION["$site_session_prefix"]['session_user_level'] == "0") {
			include ("phplib/invoice_items/invoice_items.php");
		} else {
			printMessage ("Access Denied");
		}
		break;	


	case "descriptions":
		if ($_SESSION["$site_session_prefix"]['session_user_level'] == "0") {
			include ("phplib/descriptions/descriptions.php");
		} else {
			printMessage ("Access Denied");
		}
		break;
	case "settings":
		if ($_SESSION["$site_session_prefix"]['session_user_level'] == "0") {
			include ("phplib/settings/settings.php");
		} else {
			printMessage ("Access Denied");
		}
		break;		
	case "userReports":
		if ($_SESSION["$site_session_prefix"]['session_user_level'] == "0") {
			include ("phplib/userReports/userReports.php");
		} else {
			printMessage ("Access Denied");
		}
		break;

	case "timeRecordSearch":
		if ($_SESSION["$site_session_prefix"]['session_user_level'] == "0") {
			include ("phplib/timeRecordSearch/timeRecordSearch.php");
		} else {
			printMessage ("Access Denied");
		}
		break;
				
	case "site_images":
		if ($_SESSION["$site_session_prefix"]['session_user_level'] == "0") {
			include ("phplib/site_images/site_images.php");
		} else {
			printMessage ("Access Denied");
		}
		break;		
	case "users":
		if ($_SESSION["$site_session_prefix"]['session_user_level'] == "0") {
			include ("phplib/users/users.php");
		} else {
			printMessage ("Access Denied");
		}
		break;
	default:
		if ($_SESSION["$site_session_prefix"]['session_user_level'] == "0") {
			include ("phplib/clients/clients.php");
		} else {
			include ("phplib/timesheets/timesheets.php");
		}
		break;
	}
?>