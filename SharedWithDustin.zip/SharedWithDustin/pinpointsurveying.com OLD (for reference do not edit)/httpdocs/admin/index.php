<?php
session_start();

date_default_timezone_set('America/Vancouver');

//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);

include_once ('includes/db.php');
include_once ('includes/config.php');
include_once ("includes/check_login.php");

include_once ("includes/validate.php");
include_once ('includes/functions.php');

include_once ("includes/ajax_functions.php");
include_once ("includes/sajax.php");

if (!isset($_GET['sajaxcall'])) {
	include_once ("includes/header.php");
}

include_once ("content.php");

if (!isset($_GET['sajaxcall'])) {
	include_once ("includes/footer.php");
}

?>